"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var paymentController_exports = {};
__export(paymentController_exports, {
  paymentController: () => paymentController
});
module.exports = __toCommonJS(paymentController_exports);
var import_paymentService = require("../services/paymentService");
const paymentController = {
  async create(req, res) {
    try {
      const userId = req.user?.id;
      const payment = await import_paymentService.paymentService.create({
        ...req.body,
        createdById: userId
      });
      res.status(201).json({
        success: true,
        data: payment,
        message: "Payment created successfully"
      });
    } catch (error) {
      console.error("Error creating payment:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to create payment"
      });
    }
  },
  async getAll(req, res) {
    try {
      const filters = {
        supplierId: req.query.supplierId,
        category: req.query.category,
        paymentMethod: req.query.paymentMethod,
        status: req.query.status,
        startDate: req.query.startDate ? new Date(req.query.startDate) : void 0,
        endDate: req.query.endDate ? new Date(req.query.endDate) : void 0,
        minAmount: req.query.minAmount ? parseFloat(req.query.minAmount) : void 0,
        maxAmount: req.query.maxAmount ? parseFloat(req.query.maxAmount) : void 0
      };
      const payments = await import_paymentService.paymentService.getAll(filters);
      res.json({
        success: true,
        data: payments,
        count: payments.length
      });
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to fetch payments"
      });
    }
  },
  async getById(req, res) {
    try {
      const { id } = req.params;
      const payment = await import_paymentService.paymentService.getById(id);
      res.json({
        success: true,
        data: payment
      });
    } catch (error) {
      console.error("Error fetching payment:", error);
      res.status(error.message === "Payment not found" ? 404 : 500).json({
        success: false,
        message: error.message || "Failed to fetch payment"
      });
    }
  },
  async update(req, res) {
    try {
      const { id } = req.params;
      const payment = await import_paymentService.paymentService.update(id, req.body);
      res.json({
        success: true,
        data: payment,
        message: "Payment updated successfully"
      });
    } catch (error) {
      console.error("Error updating payment:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to update payment"
      });
    }
  },
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await import_paymentService.paymentService.delete(id);
      res.json({
        success: true,
        message: result.message
      });
    } catch (error) {
      console.error("Error deleting payment:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to delete payment"
      });
    }
  },
  async generateNumber(req, res) {
    try {
      const paymentNumber = await import_paymentService.paymentService.generatePaymentNumber();
      res.json({
        success: true,
        data: { paymentNumber }
      });
    } catch (error) {
      console.error("Error generating payment number:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to generate payment number"
      });
    }
  },
  async getStatistics(req, res) {
    try {
      const filters = {
        supplierId: req.query.supplierId,
        category: req.query.category,
        paymentMethod: req.query.paymentMethod,
        status: req.query.status,
        startDate: req.query.startDate ? new Date(req.query.startDate) : void 0,
        endDate: req.query.endDate ? new Date(req.query.endDate) : void 0
      };
      const statistics = await import_paymentService.paymentService.getStatistics(filters);
      res.json({
        success: true,
        data: statistics
      });
    } catch (error) {
      console.error("Error fetching payment statistics:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to fetch payment statistics"
      });
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  paymentController
});
