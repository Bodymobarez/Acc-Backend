"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var accountController_exports = {};
__export(accountController_exports, {
  AccountController: () => AccountController,
  accountController: () => accountController
});
module.exports = __toCommonJS(accountController_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
class AccountController {
  /**
   * Get all accounts (with optional filter by code)
   */
  async getAll(req, res) {
    try {
      const { code } = req.query;
      const whereClause = {};
      if (code) {
        whereClause.code = code;
      }
      const accounts = await import_prisma.prisma.accounts.findMany({
        where: whereClause,
        include: {
          accounts: true,
          other_accounts: true
        },
        orderBy: {
          code: "asc"
        }
      });
      res.json({
        success: true,
        data: accounts
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get account by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const account = await import_prisma.prisma.accounts.findUnique({
        where: { id },
        include: {
          accounts: true,
          other_accounts: true
        }
      });
      if (!account) {
        res.status(404).json({
          success: false,
          error: "Account not found"
        });
        return;
      }
      res.json({
        success: true,
        data: account
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Create account
   */
  async create(req, res) {
    try {
      const account = await import_prisma.prisma.accounts.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          ...req.body,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.status(201).json({
        success: true,
        data: account
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update account
   */
  async update(req, res) {
    try {
      const { id } = req.params;
      const account = await import_prisma.prisma.accounts.update({
        where: { id },
        data: {
          ...req.body,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.json({
        success: true,
        data: account
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Delete account
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const children = await import_prisma.prisma.accounts.findMany({
        where: { parentId: id }
      });
      if (children.length > 0) {
        res.status(400).json({
          success: false,
          error: "Cannot delete account with sub-accounts"
        });
        return;
      }
      await import_prisma.prisma.accounts.delete({
        where: { id }
      });
      res.json({
        success: true,
        message: "Account deleted successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
}
const accountController = new AccountController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AccountController,
  accountController
});
