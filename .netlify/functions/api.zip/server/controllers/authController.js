"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var authController_exports = {};
__export(authController_exports, {
  AuthController: () => AuthController,
  authController: () => authController
});
module.exports = __toCommonJS(authController_exports);
var import_authService = require("../services/authService");
class AuthController {
  /**
   * Login
   */
  async login(req, res) {
    try {
      const { username, password } = req.body;
      console.log("\u{1F510} Login attempt for username:", username);
      const result = await import_authService.authService.login({ username, password });
      console.log("\u2705 Login successful for:", username);
      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error("\u274C Login error:", error.message);
      console.error("Stack:", error.stack);
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Register
   */
  async register(req, res) {
    try {
      const { username, email, password, firstName, lastName, role } = req.body;
      const result = await import_authService.authService.register({
        username,
        email,
        password,
        firstName,
        lastName,
        role
      });
      res.status(201).json({
        success: true,
        data: result
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get profile
   */
  async getProfile(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const user = await import_authService.authService.getProfile(req.user.id);
      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update profile
   */
  async updateProfile(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const { firstName, lastName } = req.body;
      const user = await import_authService.authService.updateProfile(req.user.id, {
        firstName,
        lastName
      });
      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Change password
   */
  async changePassword(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const { oldPassword, newPassword } = req.body;
      await import_authService.authService.changePassword(req.user.id, oldPassword, newPassword);
      res.json({
        success: true,
        message: "Password changed successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
}
const authController = new AuthController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuthController,
  authController
});
