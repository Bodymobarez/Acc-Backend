"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var userController_exports = {};
__export(userController_exports, {
  userController: () => userController
});
module.exports = __toCommonJS(userController_exports);
var import_userService = require("../services/userService");
class UserController {
  async getAllUsers(req, res) {
    try {
      const users = await import_userService.userService.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
  async getUserById(req, res) {
    try {
      const { id } = req.params;
      const user = await import_userService.userService.getUserById(id);
      res.json(user);
    } catch (error) {
      if (error.message === "User not found") {
        res.status(404).json({ error: error.message });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
  async createUser(req, res) {
    try {
      const user = await import_userService.userService.createUser(req.body);
      res.status(201).json(user);
    } catch (error) {
      if (error.message === "Username or email already exists") {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
  async updateUser(req, res) {
    try {
      const { id } = req.params;
      const user = await import_userService.userService.updateUser(id, req.body);
      res.json(user);
    } catch (error) {
      if (error.message === "User not found") {
        res.status(404).json({ error: error.message });
      } else if (error.message === "Username or email already exists") {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
  async deleteUser(req, res) {
    try {
      const { id } = req.params;
      const result = await import_userService.userService.deleteUser(id);
      res.json(result);
    } catch (error) {
      if (error.message === "User not found") {
        res.status(404).json({ error: error.message });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
  async toggleUserStatus(req, res) {
    try {
      const { id } = req.params;
      const user = await import_userService.userService.toggleUserStatus(id);
      res.json(user);
    } catch (error) {
      if (error.message === "User not found") {
        res.status(404).json({ error: error.message });
      } else {
        res.status(500).json({ error: error.message });
      }
    }
  }
  async getUserStats(req, res) {
    try {
      const stats = await import_userService.userService.getUserStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}
const userController = new UserController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  userController
});
