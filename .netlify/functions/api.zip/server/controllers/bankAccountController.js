"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bankAccountController_exports = {};
__export(bankAccountController_exports, {
  bankAccountController: () => bankAccountController
});
module.exports = __toCommonJS(bankAccountController_exports);
var import_bankAccountService = require("../services/bankAccountService");
const bankAccountController = {
  async create(req, res) {
    try {
      const bankAccount = await import_bankAccountService.bankAccountService.create(req.body);
      res.status(201).json({
        success: true,
        data: bankAccount,
        message: "Bank account created successfully"
      });
    } catch (error) {
      console.error("Error creating bank account:", error);
      res.status(error.message === "Account number already exists" ? 400 : 500).json({
        success: false,
        message: error.message || "Failed to create bank account"
      });
    }
  },
  async getAll(req, res) {
    try {
      const filters = {
        bankName: req.query.bankName,
        currency: req.query.currency,
        accountType: req.query.accountType,
        isActive: req.query.isActive === "true" ? true : req.query.isActive === "false" ? false : void 0
      };
      const bankAccounts = await import_bankAccountService.bankAccountService.getAll(filters);
      res.json({
        success: true,
        data: bankAccounts,
        count: bankAccounts.length
      });
    } catch (error) {
      console.error("Error fetching bank accounts:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to fetch bank accounts"
      });
    }
  },
  async getById(req, res) {
    try {
      const { id } = req.params;
      const bankAccount = await import_bankAccountService.bankAccountService.getById(id);
      res.json({
        success: true,
        data: bankAccount
      });
    } catch (error) {
      console.error("Error fetching bank account:", error);
      res.status(error.message === "Bank account not found" ? 404 : 500).json({
        success: false,
        message: error.message || "Failed to fetch bank account"
      });
    }
  },
  async update(req, res) {
    try {
      const { id } = req.params;
      const bankAccount = await import_bankAccountService.bankAccountService.update(id, req.body);
      res.json({
        success: true,
        data: bankAccount,
        message: "Bank account updated successfully"
      });
    } catch (error) {
      console.error("Error updating bank account:", error);
      res.status(error.message.includes("already exists") ? 400 : 500).json({
        success: false,
        message: error.message || "Failed to update bank account"
      });
    }
  },
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await import_bankAccountService.bankAccountService.delete(id);
      res.json({
        success: true,
        message: result.message
      });
    } catch (error) {
      console.error("Error deleting bank account:", error);
      res.status(error.message.includes("existing payments") ? 400 : 500).json({
        success: false,
        message: error.message || "Failed to delete bank account"
      });
    }
  },
  async updateBalance(req, res) {
    try {
      const { id } = req.params;
      const { amount, operation } = req.body;
      if (!amount || !operation) {
        return res.status(400).json({
          success: false,
          message: "Amount and operation are required"
        });
      }
      if (operation !== "add" && operation !== "subtract") {
        return res.status(400).json({
          success: false,
          message: 'Operation must be either "add" or "subtract"'
        });
      }
      const bankAccount = await import_bankAccountService.bankAccountService.updateBalance(id, amount, operation);
      res.json({
        success: true,
        data: bankAccount,
        message: "Bank account balance updated successfully"
      });
    } catch (error) {
      console.error("Error updating bank account balance:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to update bank account balance"
      });
    }
  },
  async getStatistics(req, res) {
    try {
      const filters = {
        bankName: req.query.bankName,
        currency: req.query.currency,
        accountType: req.query.accountType,
        isActive: req.query.isActive === "true" ? true : req.query.isActive === "false" ? false : void 0
      };
      const statistics = await import_bankAccountService.bankAccountService.getStatistics(filters);
      res.json({
        success: true,
        data: statistics
      });
    } catch (error) {
      console.error("Error fetching bank account statistics:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to fetch bank account statistics"
      });
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  bankAccountController
});
