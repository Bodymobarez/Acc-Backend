"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bookingController_exports = {};
__export(bookingController_exports, {
  BookingController: () => BookingController,
  bookingController: () => bookingController
});
module.exports = __toCommonJS(bookingController_exports);
var import_bookingService = require("../services/bookingService");
var import_cancellationService = require("../services/cancellationService");
class BookingController {
  /**
   * Create booking
   */
  async create(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      console.log("\u{1F4E6} Creating booking with data:", {
        serviceType: req.body.serviceType,
        customerId: req.body.customerId,
        supplierId: req.body.supplierId,
        userId: req.user.id
      });
      const booking = await import_bookingService.bookingService.createBooking({
        ...req.body,
        createdById: req.user.id
      });
      console.log("\u2705 Booking created successfully:", booking.id);
      res.status(201).json({
        success: true,
        data: booking
      });
    } catch (error) {
      console.error("\u274C Booking creation failed:", {
        message: error.message,
        stack: error.stack,
        body: req.body
      });
      res.status(400).json({
        success: false,
        error: error.message,
        details: process.env.NODE_ENV === "development" ? error.stack : void 0
      });
    }
  }
  /**
   * Get all bookings (with RBAC filtering)
   */
  async getAll(req, res) {
    try {
      const rbacFilter = req.bookingFilter;
      const filters = {
        status: req.query.status,
        serviceType: req.query.serviceType,
        customerId: req.query.customerId,
        supplierId: req.query.supplierId,
        startDate: req.query.startDate ? new Date(req.query.startDate) : void 0,
        endDate: req.query.endDate ? new Date(req.query.endDate) : void 0
      };
      if (filters.startDate) {
        filters.startDate.setHours(0, 0, 0, 0);
      }
      if (filters.endDate) {
        filters.endDate.setHours(23, 59, 59, 999);
      }
      const bookings = await import_bookingService.bookingService.getBookings(filters, rbacFilter);
      res.json({
        success: true,
        data: bookings
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get booking by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const booking = await import_bookingService.bookingService.getBookingById(id);
      if (!booking) {
        res.status(404).json({
          success: false,
          error: "Booking not found"
        });
        return;
      }
      res.json({
        success: true,
        data: booking
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update booking
   */
  async update(req, res) {
    try {
      const { id } = req.params;
      const booking = await import_bookingService.bookingService.updateBooking(id, req.body);
      res.json({
        success: true,
        data: booking
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update commissions
   */
  async updateCommissions(req, res) {
    try {
      const { id } = req.params;
      const { agentCommissionRate, csCommissionRate } = req.body;
      const booking = await import_bookingService.bookingService.updateCommissions(id, {
        agentCommissionRate,
        csCommissionRate
      });
      res.json({
        success: true,
        data: booking
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Approve booking
   */
  async approve(req, res) {
    try {
      const { id } = req.params;
      const booking = await import_bookingService.bookingService.approveBooking(id);
      res.json({
        success: true,
        data: booking
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Delete booking
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      await import_bookingService.bookingService.deleteBooking(id);
      res.json({
        success: true,
        message: "Booking deleted successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Cancel booking with refund
   * - Creates refund booking with negative amounts
   * - Cancels invoice if exists
   * - Adds credit note info if invoice was paid
   * - Sets original booking status to CANCELLED
   */
  async cancelWithRefund(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const { id } = req.params;
      const result = await import_cancellationService.cancellationService.cancelBookingWithRefund(id, req.user.id);
      res.json({
        success: true,
        data: result,
        message: "Booking cancelled successfully with refund"
      });
    } catch (error) {
      console.error("Error cancelling booking:", error);
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Add supplier to booking
   */
  async addSupplier(req, res) {
    try {
      const { id } = req.params;
      const { supplierId, serviceType, costAmount, costCurrency, description } = req.body;
      const bookingSupplier = await import_bookingService.bookingService.addBookingSupplier(
        id,
        supplierId,
        serviceType,
        costAmount,
        costCurrency,
        description
      );
      res.status(201).json({
        success: true,
        data: bookingSupplier
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get booking suppliers
   */
  async getSuppliers(req, res) {
    try {
      const { id } = req.params;
      const suppliers = await import_bookingService.bookingService.getBookingSuppliers(id);
      res.json({
        success: true,
        data: suppliers
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Remove supplier from booking
   */
  async removeSupplier(req, res) {
    try {
      const { supplierId } = req.params;
      await import_bookingService.bookingService.removeBookingSupplier(supplierId);
      res.json({
        success: true,
        message: "Supplier removed successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
}
const bookingController = new BookingController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BookingController,
  bookingController
});
