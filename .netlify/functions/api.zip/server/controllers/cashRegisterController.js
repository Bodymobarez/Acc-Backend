"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cashRegisterController_exports = {};
__export(cashRegisterController_exports, {
  cashRegisterController: () => cashRegisterController
});
module.exports = __toCommonJS(cashRegisterController_exports);
var import_cashRegisterService = require("../services/cashRegisterService");
const cashRegisterController = {
  async create(req, res) {
    try {
      const cashRegister = await import_cashRegisterService.cashRegisterService.create(req.body);
      res.status(201).json({
        success: true,
        data: cashRegister,
        message: "Cash register created successfully"
      });
    } catch (error) {
      console.error("Error creating cash register:", error);
      res.status(error.message.includes("already exists") ? 400 : 500).json({
        success: false,
        message: error.message || "Failed to create cash register"
      });
    }
  },
  async getAll(req, res) {
    try {
      const filters = {
        currency: req.query.currency,
        isActive: req.query.isActive === "true" ? true : req.query.isActive === "false" ? false : void 0
      };
      const cashRegisters = await import_cashRegisterService.cashRegisterService.getAll(filters);
      res.json({
        success: true,
        data: cashRegisters,
        count: cashRegisters.length
      });
    } catch (error) {
      console.error("Error fetching cash registers:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to fetch cash registers"
      });
    }
  },
  async getById(req, res) {
    try {
      const { id } = req.params;
      const cashRegister = await import_cashRegisterService.cashRegisterService.getById(id);
      res.json({
        success: true,
        data: cashRegister
      });
    } catch (error) {
      console.error("Error fetching cash register:", error);
      res.status(error.message === "Cash register not found" ? 404 : 500).json({
        success: false,
        message: error.message || "Failed to fetch cash register"
      });
    }
  },
  async update(req, res) {
    try {
      const { id } = req.params;
      const cashRegister = await import_cashRegisterService.cashRegisterService.update(id, req.body);
      res.json({
        success: true,
        data: cashRegister,
        message: "Cash register updated successfully"
      });
    } catch (error) {
      console.error("Error updating cash register:", error);
      res.status(error.message.includes("already exists") ? 400 : 500).json({
        success: false,
        message: error.message || "Failed to update cash register"
      });
    }
  },
  async delete(req, res) {
    try {
      const { id } = req.params;
      const result = await import_cashRegisterService.cashRegisterService.delete(id);
      res.json({
        success: true,
        message: result.message
      });
    } catch (error) {
      console.error("Error deleting cash register:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to delete cash register"
      });
    }
  },
  async updateBalance(req, res) {
    try {
      const { id } = req.params;
      const { amount, operation } = req.body;
      if (!amount || !operation) {
        return res.status(400).json({
          success: false,
          message: "Amount and operation are required"
        });
      }
      if (operation !== "add" && operation !== "subtract") {
        return res.status(400).json({
          success: false,
          message: 'Operation must be either "add" or "subtract"'
        });
      }
      const cashRegister = await import_cashRegisterService.cashRegisterService.updateBalance(id, amount, operation);
      res.json({
        success: true,
        data: cashRegister,
        message: "Cash register balance updated successfully"
      });
    } catch (error) {
      console.error("Error updating cash register balance:", error);
      res.status(500).json({
        success: false,
        message: error.message || "Failed to update cash register balance"
      });
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cashRegisterController
});
