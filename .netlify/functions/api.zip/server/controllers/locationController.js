"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var locationController_exports = {};
__export(locationController_exports, {
  createHotel: () => createHotel,
  getAllCountries: () => getAllCountries,
  getCitiesByCountry: () => getCitiesByCountry,
  getHotelsByCity: () => getHotelsByCity,
  initializeLocations: () => initializeLocations
});
module.exports = __toCommonJS(locationController_exports);
var import_locationService = require("../services/locationService");
const getAllCountries = async (req, res) => {
  try {
    const countries = await import_locationService.locationService.getAllCountries();
    res.json({ success: true, data: countries });
  } catch (error) {
    console.error("Error fetching countries:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};
const getCitiesByCountry = async (req, res) => {
  try {
    const { countryId } = req.params;
    const cities = await import_locationService.locationService.getCitiesByCountry(countryId);
    res.json({ success: true, data: cities });
  } catch (error) {
    console.error("Error fetching cities:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};
const getHotelsByCity = async (req, res) => {
  try {
    const { cityId } = req.params;
    const hotels = await import_locationService.locationService.getHotelsByCity(cityId);
    res.json({ success: true, data: hotels });
  } catch (error) {
    console.error("Error fetching hotels:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};
const createHotel = async (req, res) => {
  try {
    const { name, cityId, address, phone, email, rating } = req.body;
    if (!name || !cityId) {
      return res.status(400).json({
        success: false,
        error: "Hotel name and city are required"
      });
    }
    const hotel = await import_locationService.locationService.upsertHotel(
      name,
      cityId,
      address,
      phone,
      email,
      rating
    );
    res.json({ success: true, data: hotel });
  } catch (error) {
    console.error("Error creating hotel:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};
const initializeLocations = async (req, res) => {
  try {
    await import_locationService.locationService.initializeLocations();
    res.json({ success: true, message: "Locations initialized successfully" });
  } catch (error) {
    console.error("Error initializing locations:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHotel,
  getAllCountries,
  getCitiesByCountry,
  getHotelsByCity,
  initializeLocations
});
