"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var notificationController_exports = {};
__export(notificationController_exports, {
  default: () => notificationController_default
});
module.exports = __toCommonJS(notificationController_exports);
class NotificationController {
  /**
   * Get user notifications
   */
  async getNotifications(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({
        notifications: [],
        total: 0,
        limit: 50,
        offset: 0
      });
    } catch (error) {
      console.error("Get notifications error:", error);
      res.status(500).json({ error: "Failed to get notifications" });
    }
  }
  /**
   * Get unread count
   */
  async getUnreadCount(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({ count: 0 });
    } catch (error) {
      console.error("Error getting unread count:", error);
      res.status(500).json({ error: "Failed to get unread count" });
    }
  }
  /**
   * Mark notification as read
   */
  async markAsRead(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Mark as read error:", error);
      res.status(500).json({ error: "Failed to mark as read" });
    }
  }
  /**
   * Mark all as read
   */
  async markAllAsRead(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Mark all as read error:", error);
      res.status(500).json({ error: "Failed to mark all as read" });
    }
  }
  /**
   * Delete notification
   */
  async deleteNotification(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete notification error:", error);
      res.status(500).json({ error: "Failed to delete notification" });
    }
  }
  /**
   * Delete all read notifications
   */
  async deleteAllRead(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete all read error:", error);
      res.status(500).json({ error: "Failed to delete all read notifications" });
    }
  }
  /**
   * Get activity logs (admin only)
   */
  async getActivityLogs(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      if (!["ADMIN", "SUPER_ADMIN", "ACCOUNTING"].includes(req.user.role)) {
        return res.status(403).json({ error: "Forbidden" });
      }
      res.json({
        logs: [],
        total: 0,
        limit: 100,
        offset: 0
      });
    } catch (error) {
      console.error("Get activity logs error:", error);
      res.status(500).json({ error: "Failed to get activity logs" });
    }
  }
  /**
   * Get activity statistics (admin only)
   */
  async getActivityStats(req, res) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      if (!["ADMIN", "SUPER_ADMIN", "ACCOUNTING"].includes(req.user.role)) {
        return res.status(403).json({ error: "Forbidden" });
      }
      res.json({
        stats: {
          totalActivities: 0,
          byType: {},
          byEntityType: {},
          byUser: [],
          recentActivities: []
        }
      });
    } catch (error) {
      console.error("Get activity stats error:", error);
      res.status(500).json({ error: "Failed to get activity stats" });
    }
  }
}
var notificationController_default = new NotificationController();
