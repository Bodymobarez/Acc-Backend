"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var airlineController_exports = {};
__export(airlineController_exports, {
  airlineController: () => airlineController
});
module.exports = __toCommonJS(airlineController_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
const airlineController = {
  // Get all airlines
  async getAll(req, res) {
    try {
      const airlines = await import_prisma.prisma.airlines.findMany({
        where: { isActive: true },
        orderBy: { name: "asc" }
      });
      res.json({ success: true, data: airlines });
    } catch (error) {
      console.error("Error fetching airlines:", error);
      res.status(500).json({
        success: false,
        error: "Failed to fetch airlines",
        details: error.message
      });
    }
  },
  // Create new airline
  async create(req, res) {
    try {
      const { name, code, country } = req.body;
      const existing = await import_prisma.prisma.airlines.findUnique({
        where: { name }
      });
      if (existing) {
        return res.status(400).json({
          success: false,
          error: "Airline already exists"
        });
      }
      const airline = await import_prisma.prisma.airlines.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          name,
          code: code || null,
          country: country || null,
          isActive: true,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.status(201).json({ success: true, data: airline });
    } catch (error) {
      console.error("Error creating airline:", error);
      res.status(500).json({
        success: false,
        error: "Failed to create airline",
        details: error.message
      });
    }
  },
  // Get or create airline (used when saving booking)
  async getOrCreate(req, res) {
    try {
      const { name } = req.body;
      if (!name || typeof name !== "string" || name.trim() === "") {
        return res.status(400).json({
          success: false,
          error: "Airline name is required"
        });
      }
      let airline = await import_prisma.prisma.airlines.findUnique({
        where: { name: name.trim() }
      });
      if (!airline) {
        airline = await import_prisma.prisma.airlines.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            name: name.trim(),
            isActive: true,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
      }
      res.json({ success: true, data: airline });
    } catch (error) {
      console.error("Error in getOrCreate airline:", error);
      res.status(500).json({
        success: false,
        error: "Failed to process airline",
        details: error.message
      });
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  airlineController
});
