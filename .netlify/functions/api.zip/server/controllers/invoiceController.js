"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var invoiceController_exports = {};
__export(invoiceController_exports, {
  InvoiceController: () => InvoiceController,
  invoiceController: () => invoiceController
});
module.exports = __toCommonJS(invoiceController_exports);
var import_invoiceService = require("../services/invoiceService");
var import_pdfGenerator = require("../utils/pdfGenerator");
var import_path = __toESM(require("path"));
var import_prisma = require("../lib/prisma");
class InvoiceController {
  /**
   * Create invoice
   */
  async create(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const invoice = await import_invoiceService.invoiceService.createInvoice({
        ...req.body,
        createdById: req.user.id
      });
      res.status(201).json({
        success: true,
        data: invoice
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get all invoices
   */
  async getAll(req, res) {
    try {
      const filters = {
        status: req.query.status,
        customerId: req.query.customerId,
        startDate: req.query.startDate ? new Date(req.query.startDate) : void 0,
        endDate: req.query.endDate ? new Date(req.query.endDate) : void 0
      };
      const invoices = await import_invoiceService.invoiceService.getInvoices(filters);
      res.json({
        success: true,
        data: invoices
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get invoice by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const invoice = await import_invoiceService.invoiceService.getInvoiceById(id);
      if (!invoice) {
        res.status(404).json({
          success: false,
          error: "Invoice not found"
        });
        return;
      }
      res.json({
        success: true,
        data: invoice
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get invoice by booking ID
   */
  async getByBooking(req, res) {
    try {
      const { bookingId } = req.params;
      const invoice = await import_invoiceService.invoiceService.getInvoiceByBooking(bookingId);
      if (!invoice) {
        res.status(404).json({
          success: false,
          error: "Invoice not found for this booking"
        });
        return;
      }
      res.json({
        success: true,
        data: invoice
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update invoice status
   */
  async updateStatus(req, res) {
    try {
      const { id } = req.params;
      const { status, paidDate } = req.body;
      const invoice = await import_invoiceService.invoiceService.updateInvoiceStatus(
        id,
        status,
        paidDate ? new Date(paidDate) : void 0
      );
      res.json({
        success: true,
        data: invoice
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update invoice (generic)
   */
  async update(req, res) {
    try {
      const { id } = req.params;
      const updateData = req.body;
      const existingInvoice = await import_prisma.prisma.invoices.findUnique({
        where: { id },
        select: { status: true }
      });
      if (!existingInvoice) {
        res.status(404).json({
          success: false,
          error: "Invoice not found"
        });
        return;
      }
      if ((existingInvoice.status === "PAID" || existingInvoice.status === "PARTIALLY_PAID") && !(Object.keys(updateData).length === 1 && "status" in updateData)) {
        res.status(400).json({
          success: false,
          error: "Cannot modify this invoice. It has matched payments. Please unmatch the receipts first."
        });
        return;
      }
      if (Object.keys(updateData).length === 1 && "status" in updateData) {
        const invoice2 = await import_invoiceService.invoiceService.updateInvoiceStatus(
          id,
          updateData.status,
          updateData.status === "PAID" ? /* @__PURE__ */ new Date() : void 0
        );
        res.json({
          success: true,
          data: invoice2
        });
        return;
      }
      const invoice = await import_prisma.prisma.invoices.update({
        where: { id },
        data: updateData,
        include: {
          bookings: {
            include: {
              customers: true
            }
          }
        }
      });
      res.json({
        success: true,
        data: invoice
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Generate PDF
   */
  async generatePDF(req, res) {
    try {
      const { id } = req.params;
      const invoice = await import_invoiceService.invoiceService.getInvoiceById(id);
      if (!invoice) {
        res.status(404).json({
          success: false,
          error: "Invoice not found"
        });
        return;
      }
      const companySettings = await import_prisma.prisma.company_settings.findFirst();
      if (!companySettings) {
        res.status(400).json({
          success: false,
          error: "Company settings not found"
        });
        return;
      }
      (0, import_pdfGenerator.ensureUploadDir)();
      const uploadDir = process.env.UPLOAD_DIR || "./uploads";
      const filename = `invoice-${invoice.invoiceNumber}.pdf`;
      const outputPath = import_path.default.join(uploadDir, "pdfs", filename);
      await (0, import_pdfGenerator.generateInvoicePDF)(invoice, companySettings, outputPath);
      await import_prisma.prisma.invoices.update({
        where: { id },
        data: { pdfPath: outputPath }
      });
      res.json({
        success: true,
        data: {
          pdfPath: outputPath,
          downloadUrl: `/api/invoices/${id}/download`
        }
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Download PDF
   */
  async downloadPDF(req, res) {
    try {
      const { id } = req.params;
      const invoice = await import_invoiceService.invoiceService.getInvoiceById(id);
      if (!invoice || !invoice.pdfPath) {
        res.status(404).json({
          success: false,
          error: "PDF not found"
        });
        return;
      }
      res.download(invoice.pdfPath, `invoice-${invoice.invoiceNumber}.pdf`);
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Delete invoice
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id },
        select: { status: true }
      });
      if (!invoice) {
        res.status(404).json({
          success: false,
          error: "Invoice not found"
        });
        return;
      }
      if (invoice.status === "PAID" || invoice.status === "PARTIALLY_PAID") {
        res.status(400).json({
          success: false,
          error: "Cannot delete this invoice. It has matched payments. Please unmatch the receipts first."
        });
        return;
      }
      await import_invoiceService.invoiceService.deleteInvoice(id);
      res.json({
        success: true,
        message: "Invoice deleted successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
}
const invoiceController = new InvoiceController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  InvoiceController,
  invoiceController
});
