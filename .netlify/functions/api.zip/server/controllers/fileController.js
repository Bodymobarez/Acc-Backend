"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fileController_exports = {};
__export(fileController_exports, {
  FileController: () => FileController,
  fileController: () => fileController
});
module.exports = __toCommonJS(fileController_exports);
var import_fileService = require("../services/fileService");
var import_pdfGenerator = require("../utils/pdfGenerator");
var import_path = __toESM(require("path"));
var import_prisma = require("../lib/prisma");
class FileController {
  /**
   * Create file
   */
  async create(req, res) {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const file = await import_fileService.fileService.createFile({
        ...req.body,
        createdById: req.user.id
      });
      res.status(201).json({
        success: true,
        data: file
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get all files
   */
  async getAll(req, res) {
    try {
      const filters = {
        status: req.query.status,
        customerId: req.query.customerId,
        serviceType: req.query.serviceType,
        startDate: req.query.startDate ? new Date(req.query.startDate) : void 0,
        endDate: req.query.endDate ? new Date(req.query.endDate) : void 0
      };
      const files = await import_fileService.fileService.getFiles(filters);
      res.json({
        success: true,
        data: files
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Get file by ID
   */
  async getById(req, res) {
    try {
      const { id } = req.params;
      const file = await import_fileService.fileService.getFileById(id);
      if (!file) {
        res.status(404).json({
          success: false,
          error: "File not found"
        });
        return;
      }
      res.json({
        success: true,
        data: file
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Update file status
   */
  async updateStatus(req, res) {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const file = await import_fileService.fileService.updateFileStatus(id, status);
      res.json({
        success: true,
        data: file
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Generate PDF
   */
  async generatePDF(req, res) {
    try {
      const { id } = req.params;
      const file = await import_fileService.fileService.getFileById(id);
      if (!file) {
        res.status(404).json({
          success: false,
          error: "File not found"
        });
        return;
      }
      const companySettings = await import_prisma.prisma.company_settings.findFirst();
      if (!companySettings) {
        res.status(400).json({
          success: false,
          error: "Company settings not found"
        });
        return;
      }
      (0, import_pdfGenerator.ensureUploadDir)();
      const uploadDir = process.env.UPLOAD_DIR || "./uploads";
      const filename = `file-${file.fileNumber}.pdf`;
      const outputPath = import_path.default.join(uploadDir, "pdfs", filename);
      await (0, import_pdfGenerator.generateFilePDF)(file, companySettings, outputPath);
      await import_prisma.prisma.files.update({
        where: { id },
        data: { pdfPath: outputPath }
      });
      res.json({
        success: true,
        data: {
          pdfPath: outputPath,
          downloadUrl: `/api/files/${id}/download`
        }
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Download PDF
   */
  async downloadPDF(req, res) {
    try {
      const { id } = req.params;
      const file = await import_fileService.fileService.getFileById(id);
      if (!file || !file.pdfPath) {
        res.status(404).json({
          success: false,
          error: "PDF not found"
        });
        return;
      }
      res.download(file.pdfPath, `file-${file.fileNumber}.pdf`);
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
  /**
   * Delete file
   */
  async delete(req, res) {
    try {
      const { id } = req.params;
      await import_fileService.fileService.deleteFile(id);
      res.json({
        success: true,
        message: "File deleted successfully"
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        error: error.message
      });
    }
  }
}
const fileController = new FileController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FileController,
  fileController
});
