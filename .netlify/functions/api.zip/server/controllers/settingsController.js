"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settingsController_exports = {};
__export(settingsController_exports, {
  settingsController: () => settingsController
});
module.exports = __toCommonJS(settingsController_exports);
var import_settingsService = require("../services/settingsService");
class SettingsController {
  // Company Settings
  async getCompanySettings(req, res) {
    try {
      const settings = await import_settingsService.settingsService.getCompanySettings();
      res.json(settings);
    } catch (error) {
      console.error("Error getting company settings:", error);
      res.status(500).json({ error: error.message || "Failed to fetch company settings" });
    }
  }
  async updateCompanySettings(req, res) {
    try {
      const { id } = req.params;
      const settings = await import_settingsService.settingsService.updateCompanySettings(id, req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating company settings:", error);
      res.status(500).json({ error: error.message || "Failed to update company settings" });
    }
  }
  // System Settings
  async getAllSystemSettings(req, res) {
    try {
      const settings = await import_settingsService.settingsService.getAllSystemSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error getting system settings:", error);
      res.status(500).json({ error: error.message || "Failed to fetch system settings" });
    }
  }
  async getSystemSetting(req, res) {
    try {
      const { key } = req.params;
      const setting = await import_settingsService.settingsService.getSystemSetting(key);
      if (!setting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error getting system setting:", error);
      res.status(500).json({ error: error.message || "Failed to fetch system setting" });
    }
  }
  async upsertSystemSetting(req, res) {
    try {
      const setting = await import_settingsService.settingsService.upsertSystemSetting(req.body);
      res.json(setting);
    } catch (error) {
      console.error("Error upserting system setting:", error);
      res.status(500).json({ error: error.message || "Failed to save system setting" });
    }
  }
  async deleteSystemSetting(req, res) {
    try {
      const { key } = req.params;
      await import_settingsService.settingsService.deleteSystemSetting(key);
      res.json({ message: "Setting deleted successfully" });
    } catch (error) {
      console.error("Error deleting system setting:", error);
      res.status(500).json({ error: error.message || "Failed to delete system setting" });
    }
  }
  // Print Settings
  async getPrintSettings(req, res) {
    try {
      const settings = await import_settingsService.settingsService.getPrintSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error getting print settings:", error);
      res.status(500).json({ error: error.message || "Failed to fetch print settings" });
    }
  }
  async updatePrintSettings(req, res) {
    try {
      const settings = await import_settingsService.settingsService.updatePrintSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating print settings:", error);
      res.status(500).json({ error: error.message || "Failed to update print settings" });
    }
  }
}
const settingsController = new SettingsController();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  settingsController
});
