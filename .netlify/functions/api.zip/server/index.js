"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var index_exports = {};
__export(index_exports, {
  app: () => app,
  default: () => index_default,
  prisma: () => import_prisma.prisma
});
module.exports = __toCommonJS(index_exports);
var import_express = __toESM(require("express"));
var import_cors = __toESM(require("cors"));
var import_dotenv = __toESM(require("dotenv"));
var import_path = __toESM(require("path"));
var import_prisma = require("./lib/prisma");
var import_currencyUpdateCron = require("./jobs/currencyUpdateCron");
var import_authRoutes = __toESM(require("./routes/authRoutes"));
var import_bookingRoutes = __toESM(require("./routes/bookingRoutes"));
var import_invoiceRoutes = __toESM(require("./routes/invoiceRoutes"));
var import_fileRoutes = __toESM(require("./routes/fileRoutes"));
var import_userRoutes = __toESM(require("./routes/userRoutes"));
var import_settingsRoutes = __toESM(require("./routes/settingsRoutes"));
var import_customerRoutes = __toESM(require("./routes/customerRoutes"));
var import_supplierRoutes = __toESM(require("./routes/supplierRoutes"));
var import_accountRoutes = __toESM(require("./routes/accountRoutes"));
var import_assignmentRoutes = __toESM(require("./routes/assignmentRoutes"));
var import_employeeRoutes = __toESM(require("./routes/employeeRoutes"));
var import_placesRoutes = __toESM(require("./routes/placesRoutes"));
var import_receiptRoutes = __toESM(require("./routes/receiptRoutes"));
var import_currencyRoutes = __toESM(require("./routes/currencyRoutes"));
var import_journalRoutes = __toESM(require("./routes/journalRoutes"));
var import_systemSettingsRoutes = __toESM(require("./routes/systemSettingsRoutes"));
var import_relationshipRoutes = __toESM(require("./routes/relationshipRoutes"));
var import_commissionRoutes = __toESM(require("./routes/commissionRoutes"));
var import_customerAssignmentRoutes = __toESM(require("./routes/customerAssignmentRoutes"));
var import_locationRoutes = __toESM(require("./routes/locationRoutes"));
var import_airlineRoutes = __toESM(require("./routes/airlineRoutes"));
var import_migrationRoutes = __toESM(require("./routes/migrationRoutes"));
var import_reportRoutes = __toESM(require("./routes/reportRoutes"));
var import_advancedReportRoutes = __toESM(require("./routes/advancedReportRoutes"));
var import_notifications = __toESM(require("./routes/notifications"));
var import_employeeCommissionRoutes = __toESM(require("./routes/employeeCommissionRoutes"));
var import_generalLedgerRoutes = __toESM(require("./routes/generalLedgerRoutes"));
var import_paymentRoutes = __toESM(require("./routes/paymentRoutes"));
var import_bankAccountRoutes = __toESM(require("./routes/bankAccountRoutes"));
var import_cashRegisterRoutes = __toESM(require("./routes/cashRegisterRoutes"));
const getDirectoryPath = () => {
  if (typeof __dirname !== "undefined") {
    return __dirname;
  }
  return process.cwd();
};
const dirPath = getDirectoryPath();
import_dotenv.default.config({ path: import_path.default.join(dirPath, "../.env") });
const app = (0, import_express.default)();
const port = parseInt(process.env.PORT || "3001", 10);
const corsOptions = {
  origin: true,
  // Allow all origins
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
  exposedHeaders: ["Content-Range", "X-Content-Range"],
  maxAge: 600
  // 10 minutes
};
app.use((0, import_cors.default)(corsOptions));
app.use(import_express.default.json());
app.use(import_express.default.urlencoded({ extended: true }));
app.use((req, res, next) => {
  if (process.env.NODE_ENV === "production" && req.headers["x-forwarded-proto"] !== "https") {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self' https:; script-src 'self' 'unsafe-eval' 'unsafe-inline' https:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: https:; font-src 'self' data: https:; connect-src 'self' https: http://localhost:* ws://localhost:*; upgrade-insecure-requests;"
  );
  next();
});
app.use((req, res, next) => {
  console.log(`${(/* @__PURE__ */ new Date()).toISOString()} - ${req.method} ${req.path}`);
  if (req.method === "POST" || req.method === "PUT") {
    console.log("Body:", JSON.stringify(req.body));
  }
  next();
});
app.use((req, res, next) => {
  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }
  next();
});
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    environment: process.env.NODE_ENV || "development"
  });
});
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    environment: process.env.NODE_ENV || "development"
  });
});
app.get("/api/health/db", async (req, res) => {
  try {
    const start = Date.now();
    await import_prisma.prisma.$queryRaw`SELECT 1`;
    const duration = Date.now() - start;
    res.json({
      status: "ok",
      db: "connected",
      durationMs: duration,
      prisma: {
        datasourceUrl: !!process.env.DATABASE_URL
      }
    });
  } catch (error) {
    console.error("\u274C DB health check failed:", error);
    res.status(500).json({
      status: "error",
      db: "disconnected",
      message: error?.message || "Unknown error"
    });
  }
});
app.use("/api/auth", import_authRoutes.default);
app.use("/api/bookings", import_bookingRoutes.default);
app.use("/api/invoices", import_invoiceRoutes.default);
app.use("/api/files", import_fileRoutes.default);
app.use("/api/users", import_userRoutes.default);
app.use("/api/settings", import_settingsRoutes.default);
app.use("/api/customers", import_customerRoutes.default);
app.use("/api/suppliers", import_supplierRoutes.default);
app.use("/api/accounts", import_accountRoutes.default);
app.use("/api/assignments", import_assignmentRoutes.default);
app.use("/api/employees", import_employeeRoutes.default);
app.use("/api/places", import_placesRoutes.default);
app.use("/api/receipts", import_receiptRoutes.default);
app.use("/api/currencies", import_currencyRoutes.default);
app.use("/api/journal-entries", import_journalRoutes.default);
app.use("/api/system-settings", import_systemSettingsRoutes.default);
app.use("/api/relationships", import_relationshipRoutes.default);
app.use("/api/commissions", import_commissionRoutes.default);
app.use("/api/customer-assignments", import_customerAssignmentRoutes.default);
app.use("/api/locations", import_locationRoutes.default);
app.use("/api/airlines", import_airlineRoutes.default);
app.use("/api/migration", import_migrationRoutes.default);
app.use("/api/reports/old", import_reportRoutes.default);
app.use("/api/reports/employee-commissions", import_employeeCommissionRoutes.default);
app.use("/api/reports/general-ledger", import_generalLedgerRoutes.default);
app.use("/api/reports", import_advancedReportRoutes.default);
app.use("/api/notifications", import_notifications.default);
app.use("/api/payments", import_paymentRoutes.default);
app.use("/api/bank-accounts", import_bankAccountRoutes.default);
app.use("/api/cash-registers", import_cashRegisterRoutes.default);
app.use((err, req, res, next) => {
  console.error("Error:", err);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || "Internal server error",
    ...process.env.NODE_ENV === "development" && { stack: err.stack }
  });
});
async function initialize() {
  try {
    app.listen(port, "0.0.0.0", () => {
      console.log(`\u{1F680} Server is running on port ${port}`);
      console.log(`\u{1F4CD} Environment: ${process.env.NODE_ENV || "development"}`);
      console.log(`\u{1F517} Local: http://localhost:${port}`);
      console.log(`\u{1F310} Network: http://0.0.0.0:${port}`);
      console.log(`\u2764\uFE0F  Health check: http://localhost:${port}/health`);
    });
    console.log("\u23F3 Attempting database connection...");
    let retries = 5;
    let connected = false;
    while (retries > 0 && !connected) {
      try {
        await import_prisma.prisma.$connect();
        connected = true;
        console.log("\u2705 Database connected successfully");
        (0, import_currencyUpdateCron.startCurrencyUpdateCron)();
      } catch (error) {
        retries--;
        if (retries > 0) {
          console.log(`\u26A0\uFE0F  Database connection failed, retrying... (${retries} attempts left)`);
          await new Promise((resolve) => setTimeout(resolve, 3e3));
        } else {
          console.error("\u274C Database connection failed after all retries");
          console.error("\u26A0\uFE0F  Server is running but database operations will fail");
        }
      }
    }
  } catch (error) {
    console.error("\u274C Failed to initialize application:", error);
  }
}
process.on("SIGINT", async () => {
  console.log("\n\u{1F6D1} Shutting down gracefully...");
  (0, import_currencyUpdateCron.stopCurrencyUpdateCron)();
  await import_prisma.prisma.$disconnect();
  process.exit(0);
});
process.on("SIGTERM", async () => {
  console.log("\n\u{1F6D1} Shutting down gracefully...");
  (0, import_currencyUpdateCron.stopCurrencyUpdateCron)();
  await import_prisma.prisma.$disconnect();
  process.exit(0);
});
if (!process.env.VERCEL && !process.env.NETLIFY) {
  initialize();
}
var index_default = app;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  app,
  prisma
});
