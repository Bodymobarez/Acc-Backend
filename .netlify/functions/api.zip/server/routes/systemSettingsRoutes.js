"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var systemSettingsRoutes_exports = {};
__export(systemSettingsRoutes_exports, {
  default: () => systemSettingsRoutes_default
});
module.exports = __toCommonJS(systemSettingsRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
const handleValidationErrors = (req, res, next) => {
  const errors = (0, import_express_validator.validationResult)(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};
router.get(
  "/",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewSettings"),
  async (req, res) => {
    try {
      const settings = await import_prisma.prisma.system_settings.findMany({
        orderBy: {
          key: "asc"
        }
      });
      res.json({
        success: true,
        data: settings
      });
    } catch (error) {
      console.error("Error fetching system settings:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch system settings"
      });
    }
  }
);
router.get(
  "/:key",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewSettings"),
  async (req, res) => {
    try {
      const { key } = req.params;
      const setting = await import_prisma.prisma.system_settings.findUnique({
        where: { key }
      });
      if (!setting) {
        return res.status(404).json({
          success: false,
          error: "Setting not found"
        });
      }
      res.json({
        success: true,
        data: setting
      });
    } catch (error) {
      console.error("Error fetching system setting:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch system setting"
      });
    }
  }
);
router.post(
  "/",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("editSettings"),
  [
    (0, import_express_validator.body)("key").notEmpty().withMessage("Key is required"),
    (0, import_express_validator.body)("value").notEmpty().withMessage("Value is required"),
    (0, import_express_validator.body)("description").optional().isString()
  ],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { key, value, description } = req.body;
      const existingSetting = await import_prisma.prisma.system_settings.findUnique({
        where: { key }
      });
      if (existingSetting) {
        return res.status(400).json({
          success: false,
          error: "Setting with this key already exists"
        });
      }
      const setting = await import_prisma.prisma.system_settings.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          key,
          value: typeof value === "string" ? value : JSON.stringify(value),
          description,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.status(201).json({
        success: true,
        data: setting,
        message: "System setting created successfully"
      });
    } catch (error) {
      console.error("Error creating system setting:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to create system setting"
      });
    }
  }
);
router.put(
  "/:key",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("editSettings"),
  async (req, res) => {
    try {
      const { key } = req.params;
      const { value, description } = req.body;
      const setting = await import_prisma.prisma.system_settings.update({
        where: { key },
        data: {
          ...value !== void 0 && { value: typeof value === "string" ? value : JSON.stringify(value) },
          ...description !== void 0 && { description },
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.json({
        success: true,
        data: setting,
        message: "System setting updated successfully"
      });
    } catch (error) {
      console.error("Error updating system setting:", error);
      if (error.code === "P2025") {
        return res.status(404).json({
          success: false,
          error: "Setting not found"
        });
      }
      res.status(500).json({
        success: false,
        error: error.message || "Failed to update system setting"
      });
    }
  }
);
router.delete(
  "/:key",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("editSettings"),
  async (req, res) => {
    try {
      const { key } = req.params;
      await import_prisma.prisma.system_settings.delete({
        where: { key }
      });
      res.json({
        success: true,
        message: "System setting deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting system setting:", error);
      if (error.code === "P2025") {
        return res.status(404).json({
          success: false,
          error: "Setting not found"
        });
      }
      res.status(500).json({
        success: false,
        error: error.message || "Failed to delete system setting"
      });
    }
  }
);
router.post(
  "/bulk-update",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("editSettings"),
  async (req, res) => {
    try {
      const { settings } = req.body;
      if (!Array.isArray(settings)) {
        return res.status(400).json({
          success: false,
          error: "Settings must be an array"
        });
      }
      const updatePromises = settings.map(
        (setting) => import_prisma.prisma.system_settings.upsert({
          where: { key: setting.key },
          update: {
            value: typeof setting.value === "string" ? setting.value : JSON.stringify(setting.value),
            description: setting.description,
            updatedAt: /* @__PURE__ */ new Date()
          },
          create: {
            id: (0, import_crypto.randomUUID)(),
            key: setting.key,
            value: typeof setting.value === "string" ? setting.value : JSON.stringify(setting.value),
            description: setting.description,
            updatedAt: /* @__PURE__ */ new Date()
          }
        })
      );
      const updatedSettings = await Promise.all(updatePromises);
      res.json({
        success: true,
        data: updatedSettings,
        message: `${updatedSettings.length} settings updated successfully`
      });
    } catch (error) {
      console.error("Error bulk updating system settings:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to bulk update system settings"
      });
    }
  }
);
var systemSettingsRoutes_default = router;
