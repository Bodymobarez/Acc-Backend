"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var receiptRoutes_exports = {};
__export(receiptRoutes_exports, {
  default: () => receiptRoutes_default
});
module.exports = __toCommonJS(receiptRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_receiptService = require("../services/receiptService");
var import_auth = require("../middleware/auth");
const router = (0, import_express.Router)();
const handleValidationErrors = (req, res, next) => {
  const errors = (0, import_express_validator.validationResult)(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};
router.post(
  "/",
  import_auth.authenticate,
  [
    (0, import_express_validator.body)("receiptNumber").notEmpty().withMessage("Receipt number is required"),
    (0, import_express_validator.body)("customerId").notEmpty().withMessage("Customer is required"),
    (0, import_express_validator.body)("amount").isFloat({ min: 0.01 }).withMessage("Amount must be greater than 0"),
    (0, import_express_validator.body)("paymentMethod").isIn(["CASH", "BANK", "CREDIT_CARD", "CHECK", "SUPPLIER"]).withMessage("Invalid payment method")
  ],
  handleValidationErrors,
  async (req, res) => {
    try {
      const receipt = await import_receiptService.receiptService.createReceipt({
        ...req.body,
        createdById: req.user?.id
      });
      res.json({
        success: true,
        data: receipt,
        message: "Receipt created successfully"
      });
    } catch (error) {
      console.error("Error creating receipt:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to create receipt"
      });
    }
  }
);
router.get(
  "/",
  import_auth.authenticate,
  async (req, res) => {
    try {
      const filters = {
        customerId: req.query.customerId,
        status: req.query.status,
        paymentMethod: req.query.paymentMethod,
        startDate: req.query.startDate,
        endDate: req.query.endDate
      };
      const receipts = await import_receiptService.receiptService.getAllReceipts(filters);
      res.json({
        success: true,
        data: receipts
      });
    } catch (error) {
      console.error("Error fetching receipts:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch receipts"
      });
    }
  }
);
router.get(
  "/generate-number",
  import_auth.authenticate,
  async (req, res) => {
    try {
      const receiptNumber = await import_receiptService.receiptService.generateReceiptNumber();
      res.json({
        success: true,
        data: { receiptNumber }
      });
    } catch (error) {
      console.error("Error generating receipt number:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to generate receipt number"
      });
    }
  }
);
router.get(
  "/:id",
  import_auth.authenticate,
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Receipt ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const receipt = await import_receiptService.receiptService.getReceiptById(req.params.id);
      res.json({
        success: true,
        data: receipt
      });
    } catch (error) {
      console.error("Error fetching receipt:", error);
      res.status(404).json({
        success: false,
        error: error.message || "Receipt not found"
      });
    }
  }
);
router.put(
  "/:id",
  import_auth.authenticate,
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Receipt ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const receipt = await import_receiptService.receiptService.updateReceipt(req.params.id, req.body);
      res.json({
        success: true,
        data: receipt,
        message: "Receipt updated successfully"
      });
    } catch (error) {
      console.error("Error updating receipt:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to update receipt"
      });
    }
  }
);
router.delete(
  "/:id",
  import_auth.authenticate,
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Receipt ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const result = await import_receiptService.receiptService.deleteReceipt(req.params.id);
      res.json({
        success: true,
        ...result
      });
    } catch (error) {
      console.error("Error deleting receipt:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to delete receipt"
      });
    }
  }
);
router.get(
  "/customer/:customerId",
  import_auth.authenticate,
  [(0, import_express_validator.param)("customerId").notEmpty().withMessage("Customer ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const receipts = await import_receiptService.receiptService.getReceiptsByCustomer(req.params.customerId);
      res.json({
        success: true,
        data: receipts
      });
    } catch (error) {
      console.error("Error fetching customer receipts:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch customer receipts"
      });
    }
  }
);
router.get(
  "/invoice/:invoiceId",
  import_auth.authenticate,
  [(0, import_express_validator.param)("invoiceId").notEmpty().withMessage("Invoice ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const receipts = await import_receiptService.receiptService.getReceiptsByInvoice(req.params.invoiceId);
      res.json({
        success: true,
        data: receipts
      });
    } catch (error) {
      console.error("Error fetching invoice receipts:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch invoice receipts"
      });
    }
  }
);
var receiptRoutes_default = router;
