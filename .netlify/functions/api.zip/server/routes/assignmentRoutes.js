"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var assignmentRoutes_exports = {};
__export(assignmentRoutes_exports, {
  default: () => assignmentRoutes_default
});
module.exports = __toCommonJS(assignmentRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_validation = require("../middleware/validation");
var import_rbac = require("../middleware/rbac");
var import__ = require("../index");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get(
  "/",
  async (req, res) => {
    try {
      const assignments = await import__.prisma.customer_assignments.findMany({
        where: {
          isActive: true
        },
        include: {
          customers: {
            select: {
              id: true,
              customerCode: true,
              firstName: true,
              lastName: true,
              companyName: true,
              email: true,
              phone: true
            }
          },
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        },
        orderBy: {
          assignedDate: "desc"
        }
      });
      const transformedAssignments = assignments.map((assignment) => ({
        ...assignment,
        customer: assignment.customers,
        user: assignment.users
      }));
      res.json({
        success: true,
        data: transformedAssignments
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.get(
  "/customers",
  (0, import_auth.requirePermission)("manageUsers"),
  async (req, res) => {
    try {
      const assignments = await import__.prisma.customer_assignments.findMany({
        where: {
          isActive: true
        },
        include: {
          customers: {
            select: {
              id: true,
              customerCode: true,
              companyName: true,
              email: true,
              phone: true
            }
          },
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        },
        orderBy: {
          assignedDate: "desc"
        }
      });
      res.json({
        success: true,
        data: assignments
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.get(
  "/users/:userId/customers",
  async (req, res) => {
    try {
      const { userId } = req.params;
      if (req.user?.role !== "ADMIN" && req.user?.id !== userId) {
        res.status(403).json({
          success: false,
          error: "Access denied"
        });
        return;
      }
      const info = await (0, import_rbac.getUserAssignmentInfo)(userId);
      res.json({
        success: true,
        data: info
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.get(
  "/my-assignments",
  async (req, res) => {
    try {
      if (!req.user) {
        res.status(401).json({ error: "Unauthorized" });
        return;
      }
      const info = await (0, import_rbac.getUserAssignmentInfo)(req.user.id);
      res.json({
        success: true,
        data: info
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.post(
  "/",
  (0, import_auth.requirePermission)("createCustomer"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("customerId").notEmpty().withMessage("Customer ID is required"),
    (0, import_express_validator.body)("userId").notEmpty().withMessage("User ID is required"),
    (0, import_express_validator.body)("assignedRole").optional().isString(),
    (0, import_express_validator.body)("commissionRate").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("flightCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("hotelCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("visaCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("transferCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("cruiseCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("rentalCarCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("trainCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("activityCommission").optional().isFloat({ min: 0, max: 100 })
  ]),
  async (req, res) => {
    try {
      const {
        customerId,
        userId,
        assignedRole = "SALES",
        commissionRate,
        flightCommission,
        hotelCommission,
        visaCommission,
        transferCommission,
        cruiseCommission,
        rentalCarCommission,
        trainCommission,
        activityCommission
      } = req.body;
      if (!customerId || !userId) {
        res.status(400).json({
          success: false,
          error: "Customer ID and User ID are required"
        });
        return;
      }
      const existing = await import__.prisma.customer_assignments.findFirst({
        where: {
          customerId,
          userId,
          assignedRole,
          isActive: true
        }
      });
      if (existing) {
        const updated = await import__.prisma.customer_assignments.update({
          where: { id: existing.id },
          data: {
            commissionRate: commissionRate || null,
            flightCommission: flightCommission || null,
            hotelCommission: hotelCommission || null,
            visaCommission: visaCommission || null,
            transferCommission: transferCommission || null,
            cruiseCommission: cruiseCommission || null,
            rentalCarCommission: rentalCarCommission || null,
            trainCommission: trainCommission || null,
            activityCommission: activityCommission || null,
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            users: true
          }
        });
        res.json({
          success: true,
          data: updated,
          message: "Customer assignment updated successfully"
        });
      } else {
        const assignment = await import__.prisma.customer_assignments.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            customerId,
            userId,
            assignedRole,
            commissionRate,
            flightCommission,
            hotelCommission,
            visaCommission,
            transferCommission,
            cruiseCommission,
            rentalCarCommission,
            trainCommission,
            activityCommission,
            isActive: true,
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            users: true
          }
        });
        res.status(201).json({
          success: true,
          data: assignment,
          message: "Customer assignment created successfully"
        });
      }
    } catch (error) {
      console.error("Error in assignment creation:", error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.delete(
  "/:assignmentId",
  async (req, res) => {
    try {
      const { assignmentId } = req.params;
      await import__.prisma.customer_assignments.delete({
        where: { id: assignmentId }
      });
      res.json({
        success: true,
        message: "Assignment deleted successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.post(
  "/assign",
  (0, import_auth.requirePermission)("manageUsers"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("customerId").notEmpty().withMessage("Customer ID is required"),
    (0, import_express_validator.body)("userId").notEmpty().withMessage("User ID is required"),
    (0, import_express_validator.body)("assignedRole").optional().isString(),
    (0, import_express_validator.body)("commissionRate").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("flightCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("hotelCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("visaCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("transferCommission").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("cruiseCommission").optional().isFloat({ min: 0, max: 100 })
  ]),
  async (req, res) => {
    try {
      const {
        customerId,
        userId,
        assignedRole = "SALES",
        ...commissionRates
      } = req.body;
      const assignment = await (0, import_rbac.assignCustomerToUser)(
        customerId,
        userId,
        assignedRole,
        commissionRates
      );
      res.status(201).json({
        success: true,
        data: assignment,
        message: "Customer assigned successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.put(
  "/:assignmentId",
  (0, import_auth.requirePermission)("manageUsers"),
  async (req, res) => {
    try {
      const { assignmentId } = req.params;
      const updateData = req.body;
      const assignment = await import__.prisma.customer_assignments.update({
        where: { id: assignmentId },
        data: {
          ...updateData.assignedRole && { assignedRole: updateData.assignedRole },
          ...updateData.commissionRate !== void 0 && { commissionRate: updateData.commissionRate },
          ...updateData.flightCommission !== void 0 && { flightCommission: updateData.flightCommission },
          ...updateData.hotelCommission !== void 0 && { hotelCommission: updateData.hotelCommission },
          ...updateData.visaCommission !== void 0 && { visaCommission: updateData.visaCommission },
          ...updateData.transferCommission !== void 0 && { transferCommission: updateData.transferCommission },
          ...updateData.cruiseCommission !== void 0 && { cruiseCommission: updateData.cruiseCommission },
          ...updateData.notes !== void 0 && { notes: updateData.notes },
          updatedAt: /* @__PURE__ */ new Date()
        },
        include: {
          customers: true,
          users: true
        }
      });
      res.json({
        success: true,
        data: assignment,
        message: "Assignment updated successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.post(
  "/unassign",
  (0, import_auth.requirePermission)("manageUsers"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("customerId").notEmpty(),
    (0, import_express_validator.body)("userId").notEmpty(),
    (0, import_express_validator.body)("assignedRole").optional().isString()
  ]),
  async (req, res) => {
    try {
      const { customerId, userId, assignedRole = "SALES" } = req.body;
      await (0, import_rbac.unassignCustomerFromUser)(customerId, userId, assignedRole);
      res.json({
        success: true,
        message: "Customer unassigned successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.post(
  "/bulk-assign",
  (0, import_auth.requirePermission)("manageUsers"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("customerIds").isArray().notEmpty(),
    (0, import_express_validator.body)("userId").notEmpty(),
    (0, import_express_validator.body)("assignedRole").optional().isString()
  ]),
  async (req, res) => {
    try {
      const { customerIds, userId, assignedRole = "SALES" } = req.body;
      const assignments = await Promise.all(
        customerIds.map(
          (customerId) => (0, import_rbac.assignCustomerToUser)(customerId, userId, assignedRole)
        )
      );
      res.json({
        success: true,
        data: assignments,
        message: `${assignments.length} customers assigned successfully`
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.get(
  "/statistics",
  (0, import_auth.requirePermission)("manageUsers"),
  async (req, res) => {
    try {
      const [
        totalAssignments,
        activeAssignments,
        assignmentsByRole,
        topUsers
      ] = await Promise.all([
        import__.prisma.customer_assignments.count(),
        import__.prisma.customer_assignments.count({ where: { isActive: true } }),
        import__.prisma.customer_assignments.groupBy({
          by: ["assignedRole"],
          where: { isActive: true },
          _count: true
        }),
        import__.prisma.customer_assignments.groupBy({
          by: ["userId"],
          where: { isActive: true },
          _count: true,
          orderBy: {
            _count: {
              userId: "desc"
            }
          },
          take: 10
        })
      ]);
      res.json({
        success: true,
        data: {
          totalAssignments,
          activeAssignments,
          assignmentsByRole,
          topUsers
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
var assignmentRoutes_default = router;
