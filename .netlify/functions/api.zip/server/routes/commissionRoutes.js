"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var commissionRoutes_exports = {};
__export(commissionRoutes_exports, {
  default: () => commissionRoutes_default
});
module.exports = __toCommonJS(commissionRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_commissionVerificationService = require("../services/commissionVerificationService");
const router = (0, import_express.Router)();
const handleValidationErrors = (req, res, next) => {
  const errors = (0, import_express_validator.validationResult)(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};
router.get(
  "/verify/booking/:bookingId/relationships",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("bookingId").notEmpty().withMessage("Booking ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { bookingId } = req.params;
      const result = await import_commissionVerificationService.commissionVerificationService.verifyBookingUserRelationships(bookingId);
      res.json({
        success: result.valid,
        data: result
      });
    } catch (error) {
      console.error("Error verifying booking relationships:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify booking relationships"
      });
    }
  }
);
router.get(
  "/verify/booking/:bookingId/calculations",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("bookingId").notEmpty().withMessage("Booking ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { bookingId } = req.params;
      const result = await import_commissionVerificationService.commissionVerificationService.verifyCommissionCalculations(bookingId);
      res.json({
        success: result.valid,
        data: result,
        message: result.valid ? "All commission calculations are correct" : "Commission calculation errors detected"
      });
    } catch (error) {
      console.error("Error verifying commission calculations:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify commission calculations"
      });
    }
  }
);
router.get(
  "/verify/booking/:bookingId/rates",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("bookingId").notEmpty().withMessage("Booking ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { bookingId } = req.params;
      const result = await import_commissionVerificationService.commissionVerificationService.verifyCommissionRates(bookingId);
      res.json({
        success: result.valid,
        data: result,
        message: result.valid ? "Commission rates match employee defaults" : "Commission rate mismatches detected"
      });
    } catch (error) {
      console.error("Error verifying commission rates:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify commission rates"
      });
    }
  }
);
router.get(
  "/employee/:employeeId/summary",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("employeeId").notEmpty().withMessage("Employee ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      const result = await import_commissionVerificationService.commissionVerificationService.getEmployeeCommissionSummary(employeeId);
      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error("Error getting employee commission summary:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to get employee commission summary"
      });
    }
  }
);
router.get(
  "/audit/all",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("managePermissions"),
  async (req, res) => {
    try {
      const result = await import_commissionVerificationService.commissionVerificationService.findAllCommissionIssues();
      res.json({
        success: true,
        data: result,
        message: result.bookingsWithIssues === 0 ? "No commission issues found" : `Found ${result.bookingsWithIssues} booking(s) with commission issues`
      });
    } catch (error) {
      console.error("Error auditing commissions:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to audit commissions"
      });
    }
  }
);
var commissionRoutes_default = router;
