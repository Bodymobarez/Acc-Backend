"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var employeeRoutes_exports = {};
__export(employeeRoutes_exports, {
  default: () => employeeRoutes_default
});
module.exports = __toCommonJS(employeeRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_validation = require("../middleware/validation");
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get(
  "/",
  async (req, res) => {
    try {
      const employees = await import_prisma.prisma.employees.findMany({
        where: {
          isActive: true
        },
        include: {
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        },
        orderBy: {
          createdAt: "desc"
        }
      });
      res.json({
        success: true,
        data: employees
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.get(
  "/:employeeId",
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      const employee = await import_prisma.prisma.employees.findUnique({
        where: { id: employeeId },
        include: {
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        }
      });
      if (!employee) {
        res.status(404).json({
          success: false,
          error: "Employee not found"
        });
        return;
      }
      res.json({
        success: true,
        data: employee
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.put(
  "/:employeeId",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("defaultCommissionRate").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("customCommissionRates").optional().isString(),
    (0, import_express_validator.body)("department").optional().isString(),
    (0, import_express_validator.body)("isActive").optional().isBoolean()
  ]),
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      const updateData = req.body;
      const employee = await import_prisma.prisma.employees.update({
        where: { id: employeeId },
        data: {
          ...updateData.defaultCommissionRate !== void 0 && { defaultCommissionRate: updateData.defaultCommissionRate },
          ...updateData.customCommissionRates !== void 0 && { customCommissionRates: updateData.customCommissionRates },
          ...updateData.department !== void 0 && { department: updateData.department },
          ...updateData.isActive !== void 0 && { isActive: updateData.isActive }
        },
        include: {
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        }
      });
      res.json({
        success: true,
        data: employee,
        message: "Employee updated successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.post(
  "/",
  (0, import_auth.requirePermission)("manageUsers"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("userId").notEmpty().withMessage("User ID is required"),
    (0, import_express_validator.body)("employeeCode").notEmpty().withMessage("Employee code is required"),
    (0, import_express_validator.body)("department").optional().isString(),
    (0, import_express_validator.body)("defaultCommissionRate").optional().isFloat({ min: 0, max: 100 })
  ]),
  async (req, res) => {
    try {
      const {
        userId,
        employeeCode,
        department = "BOOKING",
        defaultCommissionRate = 0
      } = req.body;
      const employee = await import_prisma.prisma.employees.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          userId,
          employeeCode,
          department,
          defaultCommissionRate,
          isActive: true,
          updatedAt: /* @__PURE__ */ new Date()
        },
        include: {
          users: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
              role: true
            }
          }
        }
      });
      res.status(201).json({
        success: true,
        data: employee,
        message: "Employee profile created successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
router.delete(
  "/:employeeId",
  (0, import_auth.requirePermission)("manageUsers"),
  async (req, res) => {
    try {
      const { employeeId } = req.params;
      await import_prisma.prisma.employees.delete({
        where: { id: employeeId }
      });
      res.json({
        success: true,
        message: "Employee profile deleted successfully"
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
);
var employeeRoutes_default = router;
