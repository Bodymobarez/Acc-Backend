"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var journalRoutes_exports = {};
__export(journalRoutes_exports, {
  default: () => journalRoutes_default
});
module.exports = __toCommonJS(journalRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
const handleValidationErrors = (req, res, next) => {
  const errors = (0, import_express_validator.validationResult)(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};
router.get(
  "/",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewFinancialReports"),
  async (req, res) => {
    try {
      const {
        status,
        transactionType,
        startDate,
        endDate,
        debitAccountId,
        creditAccountId
      } = req.query;
      const where = {};
      if (status) where.status = status;
      if (transactionType) where.transactionType = transactionType;
      if (debitAccountId) where.debitAccountId = debitAccountId;
      if (creditAccountId) where.creditAccountId = creditAccountId;
      if (startDate || endDate) {
        where.date = {};
        if (startDate) where.date.gte = new Date(startDate);
        if (endDate) where.date.lte = new Date(endDate);
      }
      const entries = await import_prisma.prisma.journal_entries.findMany({
        where,
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: {
            select: {
              id: true,
              code: true,
              name: true,
              nameAr: true,
              type: true
            }
          },
          accounts_journal_entries_creditAccountIdToaccounts: {
            select: {
              id: true,
              code: true,
              name: true,
              nameAr: true,
              type: true
            }
          }
        },
        orderBy: {
          date: "desc"
        }
      });
      res.json({
        success: true,
        data: entries
      });
    } catch (error) {
      console.error("Error fetching journal entries:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch journal entries"
      });
    }
  }
);
router.get(
  "/:id",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewFinancialReports"),
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Entry ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { id } = req.params;
      const entry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id },
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: true,
          accounts_journal_entries_creditAccountIdToaccounts: true
        }
      });
      if (!entry) {
        return res.status(404).json({
          success: false,
          error: "Journal entry not found"
        });
      }
      res.json({
        success: true,
        data: entry
      });
    } catch (error) {
      console.error("Error fetching journal entry:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch journal entry"
      });
    }
  }
);
router.post(
  "/",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("managePermissions"),
  // High-level permission for accounting
  [
    (0, import_express_validator.body)("description").notEmpty().withMessage("Description is required"),
    (0, import_express_validator.body)("debitAccountId").notEmpty().withMessage("Debit account is required"),
    (0, import_express_validator.body)("creditAccountId").notEmpty().withMessage("Credit account is required"),
    (0, import_express_validator.body)("amount").isFloat({ min: 0.01 }).withMessage("Amount must be greater than 0"),
    (0, import_express_validator.body)("date").optional().isISO8601().withMessage("Invalid date format"),
    (0, import_express_validator.body)("transactionType").optional().isString(),
    (0, import_express_validator.body)("reference").optional().isString(),
    (0, import_express_validator.body)("bookingId").optional().isString(),
    (0, import_express_validator.body)("invoiceId").optional().isString()
  ],
  handleValidationErrors,
  async (req, res) => {
    try {
      const {
        description,
        debitAccountId,
        creditAccountId,
        amount,
        date,
        transactionType,
        reference,
        bookingId,
        invoiceId,
        notes
      } = req.body;
      const [debitAccount, creditAccount] = await Promise.all([
        import_prisma.prisma.accounts.findUnique({ where: { id: debitAccountId } }),
        import_prisma.prisma.accounts.findUnique({ where: { id: creditAccountId } })
      ]);
      if (!debitAccount) {
        return res.status(400).json({
          success: false,
          error: "Debit account not found"
        });
      }
      if (!creditAccount) {
        return res.status(400).json({
          success: false,
          error: "Credit account not found"
        });
      }
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) {
          nextNumber = parseInt(match[1]) + 1;
        }
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const entry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          description,
          debitAccountId,
          creditAccountId,
          amount,
          date: date ? new Date(date) : /* @__PURE__ */ new Date(),
          transactionType,
          reference,
          bookingId,
          invoiceId,
          notes,
          status: "DRAFT",
          createdBy: req.user?.id,
          updatedAt: /* @__PURE__ */ new Date()
        },
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: true,
          accounts_journal_entries_creditAccountIdToaccounts: true
        }
      });
      res.status(201).json({
        success: true,
        data: entry,
        message: "Journal entry created successfully"
      });
    } catch (error) {
      console.error("Error creating journal entry:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to create journal entry"
      });
    }
  }
);
router.put(
  "/:id",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("managePermissions"),
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Entry ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { id } = req.params;
      const updateData = req.body;
      const existingEntry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id }
      });
      if (!existingEntry) {
        return res.status(404).json({
          success: false,
          error: "Journal entry not found"
        });
      }
      if (existingEntry.status === "POSTED") {
        return res.status(400).json({
          success: false,
          error: "Cannot update posted journal entry"
        });
      }
      const entry = await import_prisma.prisma.journal_entries.update({
        where: { id },
        data: {
          ...updateData,
          updatedAt: /* @__PURE__ */ new Date()
        },
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: true,
          accounts_journal_entries_creditAccountIdToaccounts: true
        }
      });
      res.json({
        success: true,
        data: entry,
        message: "Journal entry updated successfully"
      });
    } catch (error) {
      console.error("Error updating journal entry:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to update journal entry"
      });
    }
  }
);
router.post(
  "/:id/post",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("managePermissions"),
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Entry ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { id } = req.params;
      const entry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id },
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: true,
          accounts_journal_entries_creditAccountIdToaccounts: true
        }
      });
      if (!entry) {
        return res.status(404).json({
          success: false,
          error: "Journal entry not found"
        });
      }
      if (entry.status === "POSTED") {
        return res.status(400).json({
          success: false,
          error: "Journal entry already posted"
        });
      }
      await import_prisma.prisma.$transaction([
        // Update debit account
        import_prisma.prisma.accounts.update({
          where: { id: entry.debitAccountId },
          data: {
            debitBalance: {
              increment: entry.amount
            },
            balance: {
              increment: entry.amount
            },
            updatedAt: /* @__PURE__ */ new Date()
          }
        }),
        // Update credit account
        import_prisma.prisma.accounts.update({
          where: { id: entry.creditAccountId },
          data: {
            creditBalance: {
              increment: entry.amount
            },
            balance: {
              decrement: entry.amount
            },
            updatedAt: /* @__PURE__ */ new Date()
          }
        }),
        // Update entry status
        import_prisma.prisma.journal_entries.update({
          where: { id },
          data: {
            status: "POSTED",
            postedDate: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          }
        })
      ]);
      const updatedEntry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id },
        include: {
          accounts_journal_entries_debitAccountIdToaccounts: true,
          accounts_journal_entries_creditAccountIdToaccounts: true
        }
      });
      res.json({
        success: true,
        data: updatedEntry,
        message: "Journal entry posted successfully"
      });
    } catch (error) {
      console.error("Error posting journal entry:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to post journal entry"
      });
    }
  }
);
router.delete(
  "/:id",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("managePermissions"),
  [(0, import_express_validator.param)("id").notEmpty().withMessage("Entry ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { id } = req.params;
      const entry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id }
      });
      if (!entry) {
        return res.status(404).json({
          success: false,
          error: "Journal entry not found"
        });
      }
      if (entry.status === "POSTED") {
        return res.status(400).json({
          success: false,
          error: "Cannot delete posted journal entry. Please reverse it instead."
        });
      }
      await import_prisma.prisma.journal_entries.delete({
        where: { id }
      });
      res.json({
        success: true,
        message: "Journal entry deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting journal entry:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to delete journal entry"
      });
    }
  }
);
var journalRoutes_default = router;
