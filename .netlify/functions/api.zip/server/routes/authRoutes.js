"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var authRoutes_exports = {};
__export(authRoutes_exports, {
  default: () => authRoutes_default
});
module.exports = __toCommonJS(authRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_authController = require("../controllers/authController");
var import_auth = require("../middleware/auth");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.post(
  "/login",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("username").notEmpty().trim(),
    (0, import_express_validator.body)("password").notEmpty()
  ]),
  import_authController.authController.login.bind(import_authController.authController)
);
router.post(
  "/register",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("username").notEmpty().trim().isLength({ min: 3 }),
    (0, import_express_validator.body)("email").isEmail().normalizeEmail(),
    (0, import_express_validator.body)("password").isLength({ min: 6 }),
    (0, import_express_validator.body)("firstName").notEmpty(),
    (0, import_express_validator.body)("lastName").notEmpty(),
    (0, import_express_validator.body)("role").isIn(["ADMIN", "ACCOUNTANT", "BOOKING_AGENT", "CUSTOMER_SERVICE", "MANAGER"])
  ]),
  import_authController.authController.register.bind(import_authController.authController)
);
router.get("/profile", import_auth.authenticate, import_authController.authController.getProfile.bind(import_authController.authController));
router.put(
  "/profile",
  import_auth.authenticate,
  (0, import_validation.validate)([
    (0, import_express_validator.body)("firstName").optional().notEmpty(),
    (0, import_express_validator.body)("lastName").optional().notEmpty()
  ]),
  import_authController.authController.updateProfile.bind(import_authController.authController)
);
router.post(
  "/change-password",
  import_auth.authenticate,
  (0, import_validation.validate)([
    (0, import_express_validator.body)("oldPassword").notEmpty(),
    (0, import_express_validator.body)("newPassword").isLength({ min: 6 })
  ]),
  import_authController.authController.changePassword.bind(import_authController.authController)
);
var authRoutes_default = router;
