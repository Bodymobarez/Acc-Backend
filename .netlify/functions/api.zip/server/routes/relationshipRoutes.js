"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var relationshipRoutes_exports = {};
__export(relationshipRoutes_exports, {
  default: () => relationshipRoutes_default
});
module.exports = __toCommonJS(relationshipRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_auth = require("../middleware/auth");
var import_relationshipService = require("../services/relationshipService");
const router = (0, import_express.Router)();
const handleValidationErrors = (req, res, next) => {
  const errors = (0, import_express_validator.validationResult)(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  next();
};
router.get(
  "/verify/booking/:bookingId",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("bookingId").notEmpty().withMessage("Booking ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { bookingId } = req.params;
      const result = await import_relationshipService.relationshipService.verifyBookingToInvoiceRelationship(bookingId);
      res.json({
        success: result.valid,
        data: result
      });
    } catch (error) {
      console.error("Error verifying booking relationship:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify booking relationship"
      });
    }
  }
);
router.get(
  "/verify/invoice/:invoiceId",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewInvoices"),
  [(0, import_express_validator.param)("invoiceId").notEmpty().withMessage("Invoice ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { invoiceId } = req.params;
      const result = await import_relationshipService.relationshipService.verifyInvoiceToReceiptRelationship(invoiceId);
      res.json({
        success: result.valid,
        data: result
      });
    } catch (error) {
      console.error("Error verifying invoice relationship:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify invoice relationship"
      });
    }
  }
);
router.get(
  "/verify/receipt/:receiptId",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewInvoices"),
  [(0, import_express_validator.param)("receiptId").notEmpty().withMessage("Receipt ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { receiptId } = req.params;
      const result = await import_relationshipService.relationshipService.verifyReceiptMatching(receiptId);
      res.json({
        success: result.valid,
        data: result
      });
    } catch (error) {
      console.error("Error verifying receipt matching:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to verify receipt matching"
      });
    }
  }
);
router.get(
  "/flow/booking/:bookingId",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("viewBookings"),
  [(0, import_express_validator.param)("bookingId").notEmpty().withMessage("Booking ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { bookingId } = req.params;
      const result = await import_relationshipService.relationshipService.getCompleteTransactionFlow(bookingId);
      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error("Error getting transaction flow:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to get transaction flow"
      });
    }
  }
);
router.post(
  "/sync/invoice/:invoiceId",
  import_auth.authenticate,
  (0, import_auth.requirePermission)("editInvoice"),
  [(0, import_express_validator.param)("invoiceId").notEmpty().withMessage("Invoice ID is required")],
  handleValidationErrors,
  async (req, res) => {
    try {
      const { invoiceId } = req.params;
      const result = await import_relationshipService.relationshipService.synchronizeInvoiceStatus(invoiceId);
      res.json({
        success: true,
        data: result,
        message: result.updated ? `Invoice status synchronized: ${result.oldStatus} \u2192 ${result.newStatus}` : "Invoice status is already correct"
      });
    } catch (error) {
      console.error("Error synchronizing invoice status:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to synchronize invoice status"
      });
    }
  }
);
var relationshipRoutes_default = router;
