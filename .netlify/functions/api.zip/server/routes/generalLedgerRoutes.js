"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var generalLedgerRoutes_exports = {};
__export(generalLedgerRoutes_exports, {
  default: () => generalLedgerRoutes_default
});
module.exports = __toCommonJS(generalLedgerRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
const router = (0, import_express.Router)();
router.get("/", import_auth.authenticateToken, async (req, res) => {
  try {
    const { startDate, endDate, accountId, currency = "AED" } = req.query;
    if (!startDate || !endDate) {
      return res.status(400).json({
        success: false,
        error: "Start date and end date are required"
      });
    }
    const start = new Date(startDate);
    const end = new Date(endDate);
    let exchangeRate = 1;
    if (currency !== "AED") {
      const currencyData = await import_prisma.prisma.currencies.findUnique({
        where: { code: currency }
      });
      exchangeRate = currencyData?.exchangeRateToAED || 1;
    }
    const where = {
      date: {
        gte: start,
        lte: end
      },
      status: "POSTED"
      // Only include posted entries
    };
    if (accountId) {
      where.OR = [
        { debitAccountId: accountId },
        { creditAccountId: accountId }
      ];
    }
    const entries = await import_prisma.prisma.journal_entries.findMany({
      where,
      include: {
        accounts_journal_entries_debitAccountIdToaccounts: {
          select: {
            id: true,
            code: true,
            name: true,
            nameAr: true,
            type: true
          }
        },
        accounts_journal_entries_creditAccountIdToaccounts: {
          select: {
            id: true,
            code: true,
            name: true,
            nameAr: true,
            type: true
          }
        }
      },
      orderBy: [
        { date: "asc" },
        { entryNumber: "asc" }
      ]
    });
    const accountIds = /* @__PURE__ */ new Set();
    entries.forEach((entry) => {
      if (entry.debitAccountId) accountIds.add(entry.debitAccountId);
      if (entry.creditAccountId) accountIds.add(entry.creditAccountId);
    });
    const accounts = await import_prisma.prisma.accounts.findMany({
      where: {
        id: {
          in: Array.from(accountIds)
        }
      },
      select: {
        id: true,
        code: true,
        name: true,
        nameAr: true,
        type: true
      },
      orderBy: {
        code: "asc"
      }
    });
    const openingBalances = /* @__PURE__ */ new Map();
    for (const accountData of accounts) {
      const previousEntries = await import_prisma.prisma.journal_entries.findMany({
        where: {
          date: {
            lt: start
          },
          status: "POSTED",
          OR: [
            { debitAccountId: accountData.id },
            { creditAccountId: accountData.id }
          ]
        },
        select: {
          debitAccountId: true,
          creditAccountId: true,
          amount: true
        }
      });
      let totalDebit = 0;
      let totalCredit = 0;
      previousEntries.forEach((entry) => {
        if (entry.debitAccountId === accountData.id) {
          totalDebit += Number(entry.amount);
        }
        if (entry.creditAccountId === accountData.id) {
          totalCredit += Number(entry.amount);
        }
      });
      openingBalances.set(accountData.id, {
        debit: totalDebit,
        credit: totalCredit
      });
    }
    const accountLedgers = accounts.map((account) => {
      const accountEntries = entries.filter(
        (entry) => entry.debitAccountId === account.id || entry.creditAccountId === account.id
      ).map((entry) => {
        const isDebit = entry.debitAccountId === account.id;
        const amount = Number(entry.amount);
        const convertedAmount = amount / exchangeRate;
        return {
          entryId: entry.id,
          entryNumber: entry.entryNumber,
          date: entry.date,
          description: entry.description,
          reference: entry.reference,
          debit: isDebit ? convertedAmount : 0,
          credit: !isDebit ? convertedAmount : 0,
          debitAccountCode: entry.accounts_journal_entries_debitAccountIdToaccounts?.code,
          debitAccountName: entry.accounts_journal_entries_debitAccountIdToaccounts?.name,
          debitAccountNameAr: entry.accounts_journal_entries_debitAccountIdToaccounts?.nameAr,
          creditAccountCode: entry.accounts_journal_entries_creditAccountIdToaccounts?.code,
          creditAccountName: entry.accounts_journal_entries_creditAccountIdToaccounts?.name,
          creditAccountNameAr: entry.accounts_journal_entries_creditAccountIdToaccounts?.nameAr,
          transactionType: entry.transactionType
        };
      });
      const opening = openingBalances.get(account.id) || { debit: 0, credit: 0 };
      const openingBalance = (opening.debit - opening.credit) / exchangeRate;
      let runningBalance = openingBalance;
      const entriesWithBalance = accountEntries.map((entry) => {
        if (account.type === "ASSET" || account.type === "EXPENSE") {
          runningBalance += entry.debit - entry.credit;
        } else {
          runningBalance += entry.credit - entry.debit;
        }
        return {
          ...entry,
          balance: runningBalance
        };
      });
      const totalDebit = accountEntries.reduce((sum, e) => sum + e.debit, 0);
      const totalCredit = accountEntries.reduce((sum, e) => sum + e.credit, 0);
      const closingBalance = openingBalance + (totalDebit - totalCredit);
      return {
        account: {
          id: account.id,
          code: account.code,
          name: account.name,
          nameAr: account.nameAr,
          type: account.type
        },
        openingBalance,
        entries: entriesWithBalance,
        totals: {
          debit: totalDebit,
          credit: totalCredit
        },
        closingBalance,
        entryCount: accountEntries.length
      };
    }).filter((ledger) => ledger.entryCount > 0);
    const grandTotals = {
      totalDebit: accountLedgers.reduce((sum, l) => sum + l.totals.debit, 0),
      totalCredit: accountLedgers.reduce((sum, l) => sum + l.totals.credit, 0),
      accountCount: accountLedgers.length,
      entryCount: entries.length
    };
    res.json({
      success: true,
      data: {
        period: {
          startDate: start,
          endDate: end
        },
        currency,
        exchangeRate,
        ledgers: accountLedgers,
        grandTotals
      }
    });
  } catch (error) {
    console.error("Error generating general ledger:", error);
    res.status(500).json({
      success: false,
      error: "Failed to generate general ledger report"
    });
  }
});
router.get("/accounts", import_auth.authenticateToken, async (req, res) => {
  try {
    const accounts = await import_prisma.prisma.accounts.findMany({
      select: {
        id: true,
        code: true,
        name: true,
        nameAr: true,
        type: true
      },
      orderBy: {
        code: "asc"
      }
    });
    res.json({
      success: true,
      data: accounts
    });
  } catch (error) {
    console.error("Error fetching accounts:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch accounts"
    });
  }
});
var generalLedgerRoutes_default = router;
