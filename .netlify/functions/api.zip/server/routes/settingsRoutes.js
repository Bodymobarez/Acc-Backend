"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settingsRoutes_exports = {};
__export(settingsRoutes_exports, {
  default: () => settingsRoutes_default
});
module.exports = __toCommonJS(settingsRoutes_exports);
var import_express = require("express");
var import_settingsController = require("../controllers/settingsController");
var import_auth = require("../middleware/auth");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get("/company", import_settingsController.settingsController.getCompanySettings);
router.put("/company/:id", import_settingsController.settingsController.updateCompanySettings);
router.get("/system", import_settingsController.settingsController.getAllSystemSettings);
router.get("/system/:key", import_settingsController.settingsController.getSystemSetting);
router.post("/system", import_settingsController.settingsController.upsertSystemSetting);
router.put("/system/:key", import_settingsController.settingsController.upsertSystemSetting);
router.delete("/system/:key", import_settingsController.settingsController.deleteSystemSetting);
router.get("/print", import_settingsController.settingsController.getPrintSettings);
router.put("/print", import_settingsController.settingsController.updatePrintSettings);
var settingsRoutes_default = router;
