"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var invoiceRoutes_exports = {};
__export(invoiceRoutes_exports, {
  default: () => invoiceRoutes_default
});
module.exports = __toCommonJS(invoiceRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_invoiceController = require("../controllers/invoiceController");
var import_auth = require("../middleware/auth");
var import_rbac = require("../middleware/rbac");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.post(
  "/",
  (0, import_auth.requirePermission)("createInvoice"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("bookingId").notEmpty()
  ]),
  import_invoiceController.invoiceController.create.bind(import_invoiceController.invoiceController)
);
router.get(
  "/",
  (0, import_auth.requirePermission)("viewInvoices"),
  import_rbac.applyInvoiceFilter,
  import_invoiceController.invoiceController.getAll.bind(import_invoiceController.invoiceController)
);
router.get(
  "/booking/:bookingId",
  (0, import_auth.requirePermission)("viewInvoices"),
  import_invoiceController.invoiceController.getByBooking.bind(import_invoiceController.invoiceController)
);
router.get(
  "/:id",
  (0, import_auth.requirePermission)("viewInvoices"),
  import_rbac.canAccessInvoice,
  import_invoiceController.invoiceController.getById.bind(import_invoiceController.invoiceController)
);
router.put(
  "/:id",
  (0, import_auth.requirePermission)("editInvoice"),
  import_rbac.canAccessInvoice,
  import_invoiceController.invoiceController.update.bind(import_invoiceController.invoiceController)
);
router.put(
  "/:id/status",
  (0, import_auth.requirePermission)("editInvoice"),
  import_rbac.canAccessInvoice,
  (0, import_validation.validate)([
    (0, import_express_validator.body)("status").isIn(["DRAFT", "UNPAID", "PARTIALLY_PAID", "PAID", "OVERDUE", "CANCELLED"])
  ]),
  import_invoiceController.invoiceController.updateStatus.bind(import_invoiceController.invoiceController)
);
router.post(
  "/:id/generate-pdf",
  (0, import_auth.requirePermission)("generateInvoice"),
  import_rbac.canAccessInvoice,
  import_invoiceController.invoiceController.generatePDF.bind(import_invoiceController.invoiceController)
);
router.get(
  "/:id/download",
  (0, import_auth.requirePermission)("viewInvoices"),
  import_rbac.canAccessInvoice,
  import_invoiceController.invoiceController.downloadPDF.bind(import_invoiceController.invoiceController)
);
router.delete(
  "/:id",
  (0, import_auth.requirePermission)("deleteInvoice"),
  import_rbac.canAccessInvoice,
  import_invoiceController.invoiceController.delete.bind(import_invoiceController.invoiceController)
);
var invoiceRoutes_default = router;
