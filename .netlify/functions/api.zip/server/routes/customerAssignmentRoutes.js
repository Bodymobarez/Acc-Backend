"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var customerAssignmentRoutes_exports = {};
__export(customerAssignmentRoutes_exports, {
  default: () => customerAssignmentRoutes_default
});
module.exports = __toCommonJS(customerAssignmentRoutes_exports);
var import_express = require("express");
var import__ = require("../index");
var import_auth = require("../middleware/auth");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get(
  "/",
  (0, import_auth.requirePermission)("viewCustomers"),
  async (req, res) => {
    try {
      const { customerId, status } = req.query;
      const where = {};
      if (customerId) {
        where.customerId = customerId;
      }
      if (status === "active" || !status) {
        where.isActive = true;
      } else if (status === "inactive") {
        where.isActive = false;
      }
      console.log("\u{1F50D} Customer assignments query:", { customerId, status, where });
      const assignments = await import__.prisma.customer_assignments.findMany({
        where,
        include: {
          customers: {
            select: {
              id: true,
              customerCode: true,
              companyName: true,
              firstName: true,
              lastName: true,
              email: true,
              phone: true
            }
          },
          users: {
            select: {
              id: true,
              username: true,
              firstName: true,
              lastName: true,
              email: true,
              role: true
            }
          }
        }
      });
      console.log("\u{1F4E5} Found assignments:", assignments.length);
      res.json(assignments);
    } catch (error) {
      console.error("Error fetching customer assignments:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch customer assignments"
      });
    }
  }
);
router.post(
  "/",
  (0, import_auth.requirePermission)("createCustomer"),
  async (req, res) => {
    try {
      const {
        customerId,
        userId,
        assignedRole = "SALES",
        commissionRate,
        flightCommission,
        hotelCommission,
        visaCommission,
        transferCommission,
        cruiseCommission,
        rentalCarCommission,
        trainCommission,
        activityCommission,
        notes
      } = req.body;
      console.log(`${(/* @__PURE__ */ new Date()).toISOString()} - POST /api/customer-assignments`);
      console.log("Body:", JSON.stringify(req.body));
      if (!customerId || !userId) {
        res.status(400).json({
          success: false,
          error: "Customer ID and User ID are required"
        });
        return;
      }
      const existing = await import__.prisma.customer_assignments.findFirst({
        where: {
          customerId,
          userId,
          assignedRole,
          isActive: true
        }
      });
      if (existing) {
        const updated = await import__.prisma.customer_assignments.update({
          where: { id: existing.id },
          data: {
            commissionRate: commissionRate || null,
            flightCommission: flightCommission || null,
            hotelCommission: hotelCommission || null,
            visaCommission: visaCommission || null,
            transferCommission: transferCommission || null,
            cruiseCommission: cruiseCommission || null,
            rentalCarCommission: rentalCarCommission || null,
            trainCommission: trainCommission || null,
            activityCommission: activityCommission || null,
            notes: notes || null,
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            users: true
          }
        });
        res.json({
          success: true,
          data: updated
        });
      } else {
        const assignment = await import__.prisma.customer_assignments.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            customerId,
            userId,
            assignedRole,
            commissionRate: commissionRate || null,
            flightCommission: flightCommission || null,
            hotelCommission: hotelCommission || null,
            visaCommission: visaCommission || null,
            transferCommission: transferCommission || null,
            cruiseCommission: cruiseCommission || null,
            rentalCarCommission: rentalCarCommission || null,
            trainCommission: trainCommission || null,
            activityCommission: activityCommission || null,
            notes: notes || null,
            isActive: true,
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            users: true
          }
        });
        res.status(201).json({
          success: true,
          data: assignment
        });
      }
    } catch (error) {
      console.error("Error creating customer assignment:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to create customer assignment"
      });
    }
  }
);
router.delete(
  "/:id",
  (0, import_auth.requirePermission)("deleteCustomer"),
  async (req, res) => {
    try {
      const { id } = req.params;
      await import__.prisma.customer_assignments.update({
        where: { id },
        data: {
          isActive: false,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      res.json({
        success: true,
        message: "Customer assignment deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting customer assignment:", error);
      if (error.code === "P2025") {
        res.status(404).json({
          success: false,
          error: "Customer assignment not found"
        });
        return;
      }
      res.status(500).json({
        success: false,
        error: error.message || "Failed to delete customer assignment"
      });
    }
  }
);
var customerAssignmentRoutes_default = router;
