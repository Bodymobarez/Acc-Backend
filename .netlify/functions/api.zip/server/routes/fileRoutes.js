"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fileRoutes_exports = {};
__export(fileRoutes_exports, {
  default: () => fileRoutes_default
});
module.exports = __toCommonJS(fileRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_fileController = require("../controllers/fileController");
var import_auth = require("../middleware/auth");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.post(
  "/",
  (0, import_auth.requirePermission)("createFile"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("bookingId").notEmpty()
  ]),
  import_fileController.fileController.create.bind(import_fileController.fileController)
);
router.get(
  "/",
  (0, import_auth.requirePermission)("viewFiles"),
  import_fileController.fileController.getAll.bind(import_fileController.fileController)
);
router.get(
  "/:id",
  (0, import_auth.requirePermission)("viewFiles"),
  import_fileController.fileController.getById.bind(import_fileController.fileController)
);
router.put(
  "/:id/status",
  (0, import_auth.requirePermission)("editFile"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("status").isIn(["ACTIVE", "ARCHIVED", "CANCELLED"])
  ]),
  import_fileController.fileController.updateStatus.bind(import_fileController.fileController)
);
router.post(
  "/:id/generate-pdf",
  (0, import_auth.requirePermission)("generateFile"),
  import_fileController.fileController.generatePDF.bind(import_fileController.fileController)
);
router.get(
  "/:id/download",
  (0, import_auth.requirePermission)("viewFiles"),
  import_fileController.fileController.downloadPDF.bind(import_fileController.fileController)
);
router.delete(
  "/:id",
  (0, import_auth.requirePermission)("deleteFile"),
  import_fileController.fileController.delete.bind(import_fileController.fileController)
);
var fileRoutes_default = router;
