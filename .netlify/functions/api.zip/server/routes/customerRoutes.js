"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var customerRoutes_exports = {};
__export(customerRoutes_exports, {
  default: () => customerRoutes_default
});
module.exports = __toCommonJS(customerRoutes_exports);
var import_express = require("express");
var import__ = require("../index");
var import_auth = require("../middleware/auth");
var import_rbac = require("../middleware/rbac");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get(
  "/",
  (0, import_auth.requirePermission)("viewCustomers"),
  import_rbac.applyCustomerFilter,
  async (req, res) => {
    try {
      const rbacFilter = req.customerFilter;
      const where = {};
      if (rbacFilter !== null) {
        Object.assign(where, rbacFilter);
      }
      const customers = await import__.prisma.customers.findMany({
        where,
        include: {
          customer_assignments: {
            where: { isActive: true },
            include: {
              users: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                  role: true
                }
              }
            }
          }
        },
        orderBy: {
          createdAt: "desc"
        }
      });
      res.json(customers);
    } catch (error) {
      console.error("Error fetching customers:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch customers"
      });
    }
  }
);
router.get(
  "/:id",
  (0, import_auth.requirePermission)("viewCustomers"),
  import_rbac.canAccessCustomer,
  async (req, res) => {
    try {
      const { id } = req.params;
      const customer = await import__.prisma.customers.findUnique({
        where: { id }
      });
      if (!customer) {
        res.status(404).json({
          success: false,
          error: "Customer not found"
        });
        return;
      }
      res.json({
        success: true,
        data: customer
      });
    } catch (error) {
      console.error("Error fetching customer:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch customer"
      });
    }
  }
);
router.post(
  "/",
  (0, import_auth.requirePermission)("createCustomer"),
  async (req, res) => {
    try {
      const requestData = req.body;
      console.log(`${(/* @__PURE__ */ new Date()).toISOString()} - POST /api/customers`);
      console.log("Body:", JSON.stringify(requestData));
      const customerData = {
        id: (0, import_crypto.randomUUID)(),
        customerCode: requestData.customerCode,
        type: requestData.customerType || "INDIVIDUAL",
        companyName: requestData.companyName || null,
        firstName: requestData.firstName,
        lastName: requestData.lastName,
        email: requestData.email,
        phone: requestData.primaryPhone || "",
        alternatePhone: requestData.secondaryPhone || null,
        addressLine1: requestData.addressLine1 || "",
        addressLine2: requestData.addressLine2 || null,
        city: requestData.city || "",
        state: requestData.state || null,
        country: requestData.country || "",
        postalCode: requestData.postalCode || null,
        taxNumber: requestData.emiratesId || null,
        taxRegistered: requestData.taxRegistered || false,
        depositAmount: requestData.depositAmount || 0,
        openingBalance: requestData.openingBalance || 0,
        notes: requestData.notes || null,
        isActive: true,
        updatedAt: /* @__PURE__ */ new Date()
      };
      if (!customerData.customerCode) {
        const lastCustomer = await import__.prisma.customers.findFirst({
          orderBy: { createdAt: "desc" }
        });
        let nextNumber = 1;
        if (lastCustomer && lastCustomer.customerCode) {
          const match = lastCustomer.customerCode.match(/CUST-(\d+)/);
          if (match) {
            nextNumber = parseInt(match[1]) + 1;
          }
        }
        customerData.customerCode = `CUST-${String(nextNumber).padStart(5, "0")}`;
      }
      const customer = await import__.prisma.customers.create({
        data: customerData
      });
      if (requestData.depositAmount && requestData.depositAmount > 0) {
        try {
          const bankAccount = await import__.prisma.accounts.findFirst({
            where: {
              OR: [
                { code: { startsWith: "1010" } },
                // Bank AED
                { name: { contains: "Bank", mode: "insensitive" } }
              ]
            }
          });
          const depositAccount = await import__.prisma.accounts.findFirst({
            where: {
              OR: [
                { name: { contains: "\u062A\u0623\u0645\u064A\u0646", mode: "insensitive" } },
                { name: { contains: "Deposit", mode: "insensitive" } },
                { name: { contains: "Customer Deposit", mode: "insensitive" } }
              ]
            }
          });
          if (bankAccount && depositAccount) {
            const entryNumber = `JE-${Date.now()}`;
            const customerName = customer.companyName || `${customer.firstName} ${customer.lastName}`;
            await import__.prisma.journal_entries.create({
              data: {
                id: (0, import_crypto.randomUUID)(),
                entryNumber,
                date: /* @__PURE__ */ new Date(),
                description: `Customer Deposit - ${customerName}`,
                reference: customer.customerCode,
                debitAccountId: depositAccount.id,
                creditAccountId: bankAccount.id,
                amount: requestData.depositAmount,
                transactionType: "DEPOSIT",
                status: "POSTED",
                postedDate: /* @__PURE__ */ new Date(),
                createdAt: /* @__PURE__ */ new Date(),
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
            console.log(`\u2705 Journal entry created for deposit: ${entryNumber}`);
          }
        } catch (journalError) {
          console.error("\u26A0\uFE0F Failed to create journal entry for deposit:", journalError);
        }
      }
      res.status(201).json({
        success: true,
        data: customer
      });
    } catch (error) {
      console.error("Error creating customer:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to create customer"
      });
    }
  }
);
router.put(
  "/:id",
  (0, import_auth.requirePermission)("editCustomer"),
  import_rbac.canAccessCustomer,
  async (req, res) => {
    try {
      const { id } = req.params;
      const customerData = req.body;
      console.log("\u{1F4DD} Update customer data:", customerData);
      const oldCustomer = await import__.prisma.customers.findUnique({
        where: { id },
        select: { depositAmount: true, customerCode: true, firstName: true, lastName: true, companyName: true }
      });
      const customer = await import__.prisma.customers.update({
        where: { id },
        data: {
          ...customerData,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      const oldDeposit = oldCustomer?.depositAmount || 0;
      const newDeposit = customerData.depositAmount || 0;
      const depositDifference = newDeposit - oldDeposit;
      if (depositDifference !== 0) {
        try {
          const bankAccount = await import__.prisma.accounts.findFirst({
            where: {
              OR: [
                { code: { startsWith: "1010" } },
                { name: { contains: "Bank", mode: "insensitive" } }
              ]
            }
          });
          const depositAccount = await import__.prisma.accounts.findFirst({
            where: {
              OR: [
                { name: { contains: "\u062A\u0623\u0645\u064A\u0646", mode: "insensitive" } },
                { name: { contains: "Deposit", mode: "insensitive" } },
                { name: { contains: "Customer Deposit", mode: "insensitive" } }
              ]
            }
          });
          if (bankAccount && depositAccount) {
            const entryNumber = `JE-${Date.now()}`;
            const customerName = customer.companyName || `${customer.firstName} ${customer.lastName}`;
            const isIncrease = depositDifference > 0;
            await import__.prisma.journal_entries.create({
              data: {
                id: (0, import_crypto.randomUUID)(),
                entryNumber,
                date: /* @__PURE__ */ new Date(),
                description: `${isIncrease ? "Increase" : "Decrease"} Customer Deposit - ${customerName}`,
                reference: oldCustomer?.customerCode || customer.customerCode,
                debitAccountId: isIncrease ? depositAccount.id : bankAccount.id,
                creditAccountId: isIncrease ? bankAccount.id : depositAccount.id,
                amount: Math.abs(depositDifference),
                transactionType: "DEPOSIT",
                status: "POSTED",
                postedDate: /* @__PURE__ */ new Date(),
                createdAt: /* @__PURE__ */ new Date(),
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
            console.log(`\u2705 Journal entry created for deposit change: ${entryNumber}`);
          }
        } catch (journalError) {
          console.error("\u26A0\uFE0F Failed to create journal entry for deposit change:", journalError);
        }
      }
      res.json({
        success: true,
        data: customer
      });
    } catch (error) {
      console.error("Error updating customer:", error);
      if (error.code === "P2025") {
        res.status(404).json({
          success: false,
          error: "Customer not found"
        });
        return;
      }
      res.status(500).json({
        success: false,
        error: error.message || "Failed to update customer"
      });
    }
  }
);
router.delete(
  "/:id",
  (0, import_auth.requirePermission)("deleteCustomer"),
  import_rbac.canAccessCustomer,
  async (req, res) => {
    try {
      const { id } = req.params;
      const bookingsCount = await import__.prisma.bookings.count({
        where: { customerId: id }
      });
      if (bookingsCount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete customer. Found ${bookingsCount} booking(s) linked to this customer.`
        });
        return;
      }
      const invoicesCount = await import__.prisma.invoices.count({
        where: { customerId: id }
      });
      if (invoicesCount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete customer. Found ${invoicesCount} invoice(s) linked to this customer.`
        });
        return;
      }
      await import__.prisma.customers.delete({
        where: { id }
      });
      res.json({
        success: true,
        message: "Customer deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting customer:", error);
      if (error.code === "P2025") {
        res.status(404).json({
          success: false,
          error: "Customer not found"
        });
        return;
      }
      res.status(500).json({
        success: false,
        error: error.message || "Failed to delete customer"
      });
    }
  }
);
router.get(
  "/:id/stats",
  (0, import_auth.requirePermission)("viewCustomers"),
  import_rbac.canAccessCustomer,
  async (req, res) => {
    try {
      const { id } = req.params;
      const [customer, bookingsCount, totalSpent] = await Promise.all([
        import__.prisma.customers.findUnique({ where: { id } }),
        import__.prisma.bookings.count({ where: { customerId: id } }),
        import__.prisma.bookings.aggregate({
          where: { customerId: id },
          _sum: { saleInAED: true }
        })
      ]);
      if (!customer) {
        res.status(404).json({
          success: false,
          error: "Customer not found"
        });
        return;
      }
      res.json({
        success: true,
        data: {
          customer,
          stats: {
            totalBookings: bookingsCount,
            totalSpent: totalSpent._sum.saleInAED || 0
          }
        }
      });
    } catch (error) {
      console.error("Error fetching customer stats:", error);
      res.status(500).json({
        success: false,
        error: error.message || "Failed to fetch customer statistics"
      });
    }
  }
);
var customerRoutes_default = router;
