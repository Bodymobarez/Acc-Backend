"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bankAccountRoutes_exports = {};
__export(bankAccountRoutes_exports, {
  default: () => bankAccountRoutes_default
});
module.exports = __toCommonJS(bankAccountRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_bankAccountController = require("../controllers/bankAccountController");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.post("/", import_bankAccountController.bankAccountController.create);
router.get("/", import_bankAccountController.bankAccountController.getAll);
router.get("/statistics", import_bankAccountController.bankAccountController.getStatistics);
router.get("/:id", import_bankAccountController.bankAccountController.getById);
router.put("/:id", import_bankAccountController.bankAccountController.update);
router.put("/:id/balance", import_bankAccountController.bankAccountController.updateBalance);
router.delete("/:id", import_bankAccountController.bankAccountController.delete);
var bankAccountRoutes_default = router;
