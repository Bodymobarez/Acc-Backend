"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var reportRoutes_exports = {};
__export(reportRoutes_exports, {
  default: () => reportRoutes_default
});
module.exports = __toCommonJS(reportRoutes_exports);
var import_express = __toESM(require("express"));
var import_reportController = require("../controllers/reportController");
var import_auth = require("../middleware/auth");
const router = import_express.default.Router();
router.use(import_auth.authenticate);
router.use((0, import_auth.requirePermission)("viewReports"));
router.get("/dashboard", import_reportController.reportController.getDashboardData.bind(import_reportController.reportController));
router.get(
  "/financial-summary",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getFinancialSummary.bind(import_reportController.reportController)
);
router.get(
  "/financial/summary",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getFinancialSummary.bind(import_reportController.reportController)
);
router.get(
  "/financial/revenue",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getRevenueTimeSeries.bind(import_reportController.reportController)
);
router.get(
  "/financial/profit-loss",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getProfitLoss.bind(import_reportController.reportController)
);
router.get(
  "/financial/cash-flow",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getCashFlow.bind(import_reportController.reportController)
);
router.get(
  "/financial/aging",
  (0, import_auth.requirePermission)("viewFinancialReports"),
  import_reportController.reportController.getAgingReport.bind(import_reportController.reportController)
);
router.get(
  "/financial/vat",
  (0, import_auth.requirePermission)("viewVATReports"),
  import_reportController.reportController.getVATReport.bind(import_reportController.reportController)
);
router.get("/customers/analysis", import_reportController.reportController.getCustomerAnalysis.bind(import_reportController.reportController));
router.get("/suppliers/performance", import_reportController.reportController.getSupplierPerformance.bind(import_reportController.reportController));
router.get(
  "/commissions",
  (0, import_auth.requirePermission)("viewCommissionReports"),
  import_reportController.reportController.getCommissions.bind(import_reportController.reportController)
);
router.get("/kpis", import_reportController.reportController.getKPIs.bind(import_reportController.reportController));
router.get("/bookings/performance", import_reportController.reportController.getBookingPerformance.bind(import_reportController.reportController));
router.get("/preset/:preset/:reportType", import_reportController.reportController.getReportByPreset.bind(import_reportController.reportController));
router.get("/compare/:reportType", import_reportController.reportController.comparePeriods.bind(import_reportController.reportController));
var reportRoutes_default = router;
