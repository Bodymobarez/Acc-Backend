"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var userRoutes_exports = {};
__export(userRoutes_exports, {
  default: () => userRoutes_default
});
module.exports = __toCommonJS(userRoutes_exports);
var import_express = require("express");
var import_userController = require("../controllers/userController");
var import_auth = require("../middleware/auth");
var import_express_validator = require("express-validator");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get("/stats", import_userController.userController.getUserStats);
router.get("/", import_userController.userController.getAllUsers);
router.get("/:id", import_userController.userController.getUserById);
router.post(
  "/",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("username").notEmpty().trim().isLength({ min: 3 }),
    (0, import_express_validator.body)("email").isEmail().normalizeEmail(),
    (0, import_express_validator.body)("password").isLength({ min: 6 }),
    (0, import_express_validator.body)("firstName").notEmpty().trim(),
    (0, import_express_validator.body)("lastName").notEmpty().trim(),
    (0, import_express_validator.body)("role").notEmpty()
  ]),
  import_userController.userController.createUser
);
router.put(
  "/:id",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("username").optional().trim().isLength({ min: 3 }),
    (0, import_express_validator.body)("email").optional().isEmail().normalizeEmail(),
    (0, import_express_validator.body)("password").optional({ checkFalsy: true }).isLength({ min: 6 }),
    (0, import_express_validator.body)("firstName").optional().trim(),
    (0, import_express_validator.body)("lastName").optional().trim(),
    (0, import_express_validator.body)("role").optional()
  ]),
  import_userController.userController.updateUser
);
router.delete("/:id", import_userController.userController.deleteUser);
router.patch("/:id/toggle-status", import_userController.userController.toggleUserStatus);
var userRoutes_default = router;
