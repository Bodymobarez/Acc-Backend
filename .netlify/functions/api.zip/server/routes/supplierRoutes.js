"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var supplierRoutes_exports = {};
__export(supplierRoutes_exports, {
  default: () => supplierRoutes_default
});
module.exports = __toCommonJS(supplierRoutes_exports);
var import_express = require("express");
var import__ = require("../index");
var import_crypto = require("crypto");
const router = (0, import_express.Router)();
router.get("/", async (req, res) => {
  try {
    const suppliers = await import__.prisma.suppliers.findMany({
      orderBy: {
        createdAt: "desc"
      }
    });
    const mappedSuppliers = suppliers.map((supplier) => ({
      ...supplier,
      contactPerson: supplier.contactPerson,
      email: supplier.email,
      phone: supplier.phone,
      status: supplier.isActive ? "Active" : "Inactive"
    }));
    res.json(mappedSuppliers);
  } catch (error) {
    console.error("Error fetching suppliers:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch suppliers"
    });
  }
});
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const supplier = await import__.prisma.suppliers.findUnique({
      where: { id }
    });
    if (!supplier) {
      return res.status(404).json({
        success: false,
        error: "Supplier not found"
      });
    }
    res.json({
      success: true,
      data: supplier
    });
  } catch (error) {
    console.error("Error fetching supplier:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch supplier"
    });
  }
});
router.post("/", async (req, res) => {
  try {
    const requestData = req.body;
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} - POST /api/suppliers`);
    console.log("Body:", JSON.stringify(requestData));
    const supplierData = {
      id: (0, import_crypto.randomUUID)(),
      supplierCode: requestData.supplierCode,
      companyName: requestData.companyName,
      contactPerson: requestData.primaryContactName || "",
      email: requestData.primaryEmail,
      phone: requestData.primaryPhone || "",
      // Map primaryPhone to phone
      alternatePhone: requestData.secondaryPhone || null,
      addressLine1: requestData.addressLine1 || "",
      addressLine2: requestData.addressLine2 || null,
      city: requestData.city || "",
      state: requestData.state || null,
      country: requestData.country || "",
      postalCode: requestData.postalCode || null,
      taxNumber: requestData.licenseNumber || null,
      taxRegistered: requestData.taxRegistered || false,
      paymentTerms: requestData.paymentTerms || null,
      currency: requestData.preferredCurrency || "AED",
      serviceTypes: requestData.serviceTypes || "",
      notes: requestData.notes || null,
      isActive: requestData.status !== void 0 ? requestData.status : true,
      updatedAt: /* @__PURE__ */ new Date()
    };
    if (!supplierData.supplierCode) {
      const lastSupplier = await import__.prisma.suppliers.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastSupplier && lastSupplier.supplierCode) {
        const match = lastSupplier.supplierCode.match(/SUPP-(\d+)/);
        if (match) {
          nextNumber = parseInt(match[1]) + 1;
        }
      }
      supplierData.supplierCode = `SUPP-${String(nextNumber).padStart(5, "0")}`;
    }
    const supplier = await import__.prisma.suppliers.create({
      data: supplierData
    });
    res.status(201).json({
      success: true,
      data: supplier
    });
  } catch (error) {
    console.error("Error creating supplier:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to create supplier"
    });
  }
});
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const requestData = req.body;
    console.log(`${(/* @__PURE__ */ new Date()).toISOString()} - PUT /api/suppliers/${id}`);
    console.log("Body:", JSON.stringify(requestData));
    const updateData = {
      updatedAt: /* @__PURE__ */ new Date()
    };
    if (requestData.companyName !== void 0) updateData.companyName = requestData.companyName;
    if (requestData.primaryContactName !== void 0) updateData.contactPerson = requestData.primaryContactName;
    if (requestData.primaryEmail !== void 0) updateData.email = requestData.primaryEmail;
    if (requestData.primaryPhone !== void 0) updateData.phone = requestData.primaryPhone;
    if (requestData.secondaryPhone !== void 0) updateData.alternatePhone = requestData.secondaryPhone;
    if (requestData.addressLine1 !== void 0) updateData.addressLine1 = requestData.addressLine1;
    if (requestData.addressLine2 !== void 0) updateData.addressLine2 = requestData.addressLine2;
    if (requestData.city !== void 0) updateData.city = requestData.city;
    if (requestData.state !== void 0) updateData.state = requestData.state;
    if (requestData.country !== void 0) updateData.country = requestData.country;
    if (requestData.postalCode !== void 0) updateData.postalCode = requestData.postalCode;
    if (requestData.taxNumber !== void 0) updateData.taxNumber = requestData.taxNumber;
    if (requestData.serviceTypes !== void 0) updateData.serviceTypes = requestData.serviceTypes;
    if (requestData.paymentTerms !== void 0) updateData.paymentTerms = requestData.paymentTerms;
    if (requestData.preferredCurrency !== void 0) updateData.currency = requestData.preferredCurrency;
    if (requestData.notes !== void 0) updateData.notes = requestData.notes;
    if (requestData.status !== void 0) {
      updateData.isActive = requestData.status === "active";
    }
    const supplier = await import__.prisma.suppliers.update({
      where: { id },
      data: updateData
    });
    res.json({
      success: true,
      data: supplier
    });
  } catch (error) {
    console.error("Error updating supplier:", error);
    if (error.code === "P2025") {
      return res.status(404).json({
        success: false,
        error: "Supplier not found"
      });
    }
    res.status(500).json({
      success: false,
      error: error.message || "Failed to update supplier"
    });
  }
});
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const bookingsCount = await import__.prisma.bookings.count({
      where: { supplierId: id }
    });
    if (bookingsCount > 0) {
      return res.status(400).json({
        success: false,
        error: `Cannot delete supplier. Found ${bookingsCount} booking(s) linked to this supplier.`
      });
    }
    await import__.prisma.suppliers.delete({
      where: { id }
    });
    res.json({
      success: true,
      message: "Supplier deleted successfully"
    });
  } catch (error) {
    console.error("Error deleting supplier:", error);
    if (error.code === "P2025") {
      return res.status(404).json({
        success: false,
        error: "Supplier not found"
      });
    }
    res.status(500).json({
      success: false,
      error: error.message || "Failed to delete supplier"
    });
  }
});
router.get("/:id/stats", async (req, res) => {
  try {
    const { id } = req.params;
    const [supplier, bookingsCount, totalRevenue] = await Promise.all([
      import__.prisma.suppliers.findUnique({ where: { id } }),
      import__.prisma.bookings.count({ where: { supplierId: id } }),
      import__.prisma.bookings.aggregate({
        where: { supplierId: id },
        _sum: { costInAED: true }
      })
    ]);
    if (!supplier) {
      return res.status(404).json({
        success: false,
        error: "Supplier not found"
      });
    }
    res.json({
      success: true,
      data: {
        supplier,
        stats: {
          totalBookings: bookingsCount,
          totalRevenue: totalRevenue._sum.costInAED || 0
        }
      }
    });
  } catch (error) {
    console.error("Error fetching supplier stats:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to fetch supplier statistics"
    });
  }
});
var supplierRoutes_default = router;
