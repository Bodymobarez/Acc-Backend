"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var airlineRoutes_exports = {};
__export(airlineRoutes_exports, {
  default: () => airlineRoutes_default
});
module.exports = __toCommonJS(airlineRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_airlineController = require("../controllers/airlineController");
var import_auth = require("../middleware/auth");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.get("/", import_airlineController.airlineController.getAll.bind(import_airlineController.airlineController));
router.post(
  "/",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("name").notEmpty().withMessage("Airline name is required")
  ]),
  import_airlineController.airlineController.create.bind(import_airlineController.airlineController)
);
router.post(
  "/get-or-create",
  (0, import_validation.validate)([
    (0, import_express_validator.body)("name").notEmpty().withMessage("Airline name is required")
  ]),
  import_airlineController.airlineController.getOrCreate.bind(import_airlineController.airlineController)
);
var airlineRoutes_default = router;
