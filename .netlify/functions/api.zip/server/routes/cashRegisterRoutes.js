"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cashRegisterRoutes_exports = {};
__export(cashRegisterRoutes_exports, {
  default: () => cashRegisterRoutes_default
});
module.exports = __toCommonJS(cashRegisterRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_cashRegisterController = require("../controllers/cashRegisterController");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.post("/", import_cashRegisterController.cashRegisterController.create);
router.get("/", import_cashRegisterController.cashRegisterController.getAll);
router.get("/:id", import_cashRegisterController.cashRegisterController.getById);
router.put("/:id", import_cashRegisterController.cashRegisterController.update);
router.put("/:id/balance", import_cashRegisterController.cashRegisterController.updateBalance);
router.delete("/:id", import_cashRegisterController.cashRegisterController.delete);
var cashRegisterRoutes_default = router;
