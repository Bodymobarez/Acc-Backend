"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bookingRoutes_exports = {};
__export(bookingRoutes_exports, {
  default: () => bookingRoutes_default
});
module.exports = __toCommonJS(bookingRoutes_exports);
var import_express = require("express");
var import_express_validator = require("express-validator");
var import_bookingController = require("../controllers/bookingController");
var import_auth = require("../middleware/auth");
var import_rbac = require("../middleware/rbac");
var import_validation = require("../middleware/validation");
const router = (0, import_express.Router)();
router.use(import_auth.authenticate);
router.post(
  "/",
  (0, import_auth.requirePermission)("createBooking"),
  (0, import_validation.validate)([
    (0, import_express_validator.body)("customerId").notEmpty().withMessage("Customer is required"),
    (0, import_express_validator.body)("supplierId").optional().isString(),
    (0, import_express_validator.body)("serviceType").isIn(["FLIGHT", "HOTEL", "TRANSFER", "RENTAL_CAR", "RENT_CAR", "VISA", "TRAIN", "CRUISE", "ACTIVITY"]).withMessage("Invalid service type"),
    (0, import_express_validator.body)("costAmount").isFloat({ min: 0 }).withMessage("Cost amount must be a positive number"),
    (0, import_express_validator.body)("costCurrency").notEmpty().withMessage("Cost currency is required"),
    (0, import_express_validator.body)("saleAmount").isFloat({ min: 0 }).withMessage("Sale amount must be a positive number"),
    (0, import_express_validator.body)("saleCurrency").notEmpty().withMessage("Sale currency is required"),
    (0, import_express_validator.body)("isUAEBooking").isBoolean().withMessage("UAE booking flag must be boolean"),
    (0, import_express_validator.body)("serviceDetails").isObject().withMessage("Service details must be an object")
  ]),
  import_bookingController.bookingController.create.bind(import_bookingController.bookingController)
);
router.get(
  "/",
  (0, import_auth.requirePermission)("viewBookings"),
  import_rbac.applyBookingFilter,
  import_bookingController.bookingController.getAll.bind(import_bookingController.bookingController)
);
router.get(
  "/:id",
  (0, import_auth.requirePermission)("viewBookings"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.getById.bind(import_bookingController.bookingController)
);
router.put(
  "/:id",
  (0, import_auth.requirePermission)("editBooking"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.update.bind(import_bookingController.bookingController)
);
router.put(
  "/:id/commissions",
  (0, import_auth.requirePermission)("reviewBooking"),
  import_rbac.canAccessBooking,
  (0, import_validation.validate)([
    (0, import_express_validator.body)("agentCommissionRate").optional().isFloat({ min: 0, max: 100 }),
    (0, import_express_validator.body)("csCommissionRate").optional().isFloat({ min: 0, max: 100 })
  ]),
  import_bookingController.bookingController.updateCommissions.bind(import_bookingController.bookingController)
);
router.post(
  "/:id/approve",
  (0, import_auth.requirePermission)("reviewBooking"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.approve.bind(import_bookingController.bookingController)
);
router.delete(
  "/:id",
  (0, import_auth.requirePermission)("deleteBooking"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.delete.bind(import_bookingController.bookingController)
);
router.post(
  "/:id/cancel",
  (0, import_auth.requirePermission)("editBooking"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.cancelWithRefund.bind(import_bookingController.bookingController)
);
router.post(
  "/:id/suppliers",
  (0, import_auth.requirePermission)("editBooking"),
  import_rbac.canAccessBooking,
  (0, import_validation.validate)([
    (0, import_express_validator.body)("supplierId").notEmpty(),
    (0, import_express_validator.body)("serviceType").isIn(["FLIGHT", "HOTEL", "TRANSFER", "RENT_CAR", "VISA", "TRAIN", "CRUISE"]),
    (0, import_express_validator.body)("costAmount").isFloat({ min: 0 }),
    (0, import_express_validator.body)("costCurrency").notEmpty()
  ]),
  import_bookingController.bookingController.addSupplier.bind(import_bookingController.bookingController)
);
router.get(
  "/:id/suppliers",
  (0, import_auth.requirePermission)("viewBookings"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.getSuppliers.bind(import_bookingController.bookingController)
);
router.delete(
  "/:id/suppliers/:supplierId",
  (0, import_auth.requirePermission)("editBooking"),
  import_rbac.canAccessBooking,
  import_bookingController.bookingController.removeSupplier.bind(import_bookingController.bookingController)
);
var bookingRoutes_default = router;
