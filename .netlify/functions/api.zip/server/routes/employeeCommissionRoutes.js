"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var employeeCommissionRoutes_exports = {};
__export(employeeCommissionRoutes_exports, {
  default: () => employeeCommissionRoutes_default
});
module.exports = __toCommonJS(employeeCommissionRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
const router = (0, import_express.Router)();
router.get("/", import_auth.authenticateToken, async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) {
      return res.status(400).json({
        success: false,
        error: "Month and year are required"
      });
    }
    const startDate = new Date(Number(year), Number(month) - 1, 1);
    const endDate = new Date(Number(year), Number(month), 0, 23, 59, 59, 999);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: {
          gte: startDate,
          lte: endDate
        },
        status: {
          in: ["CONFIRMED", "REFUNDED"]
        }
      },
      select: {
        id: true,
        bookingNumber: true,
        bookingDate: true,
        agentCommissionAmount: true,
        csCommissionAmount: true,
        employees_bookings_bookingAgentIdToemployees: {
          select: {
            id: true,
            users: {
              select: {
                firstName: true,
                lastName: true
              }
            },
            department: true
          }
        },
        employees_bookings_customerServiceIdToemployees: {
          select: {
            id: true,
            users: {
              select: {
                firstName: true,
                lastName: true
              }
            },
            department: true
          }
        }
      }
    });
    const employeeMap = /* @__PURE__ */ new Map();
    for (const booking of bookings) {
      if (booking.employees_bookings_bookingAgentIdToemployees && booking.agentCommissionAmount) {
        const agent = booking.employees_bookings_bookingAgentIdToemployees;
        const agentId = agent.id;
        const agentName = `${agent.users.firstName} ${agent.users.lastName}`;
        const commission = Number(booking.agentCommissionAmount);
        if (!employeeMap.has(agentId)) {
          employeeMap.set(agentId, {
            employeeId: agentId,
            employeeName: agentName,
            department: agent.department || "N/A",
            totalBookings: 0,
            agentCommission: 0,
            csCommission: 0,
            totalCommission: 0
          });
        }
        const emp = employeeMap.get(agentId);
        emp.totalBookings++;
        emp.agentCommission += commission;
        emp.totalCommission += commission;
      }
      if (booking.employees_bookings_customerServiceIdToemployees && booking.csCommissionAmount) {
        const cs = booking.employees_bookings_customerServiceIdToemployees;
        const csId = cs.id;
        const csName = `${cs.users.firstName} ${cs.users.lastName}`;
        const commission = Number(booking.csCommissionAmount);
        if (!employeeMap.has(csId)) {
          employeeMap.set(csId, {
            employeeId: csId,
            employeeName: csName,
            department: cs.department || "N/A",
            totalBookings: 0,
            agentCommission: 0,
            csCommission: 0,
            totalCommission: 0
          });
        }
        const emp = employeeMap.get(csId);
        emp.totalBookings++;
        emp.csCommission += commission;
        emp.totalCommission += commission;
      }
    }
    const employees = Array.from(employeeMap.values()).sort((a, b) => b.totalCommission - a.totalCommission);
    const totalEmployees = employees.length;
    const totalBookings = bookings.length;
    const totalCommissions = employees.reduce((sum, emp) => sum + emp.totalCommission, 0);
    const totalAgentCommissions = employees.reduce((sum, emp) => sum + emp.agentCommission, 0);
    const totalCSCommissions = employees.reduce((sum, emp) => sum + emp.csCommission, 0);
    res.json({
      success: true,
      data: {
        month: Number(month),
        year: Number(year),
        employees,
        summary: {
          totalEmployees,
          totalBookings,
          totalCommissions,
          totalAgentCommissions,
          totalCSCommissions,
          avgCommissionPerEmployee: totalEmployees > 0 ? totalCommissions / totalEmployees : 0
        }
      }
    });
  } catch (error) {
    console.error("Error generating employee commission report:", error);
    res.status(500).json({
      success: false,
      error: "Failed to generate employee commission report"
    });
  }
});
router.get("/export", import_auth.authenticateToken, async (req, res) => {
  try {
    const { month, year, format } = req.query;
    if (!month || !year) {
      return res.status(400).json({
        success: false,
        error: "Month and year are required"
      });
    }
    res.json({
      success: true,
      message: "Export functionality will be implemented with Excel library",
      data: { month, year, format }
    });
  } catch (error) {
    console.error("Error exporting employee commission report:", error);
    res.status(500).json({
      success: false,
      error: "Failed to export employee commission report"
    });
  }
});
var employeeCommissionRoutes_default = router;
