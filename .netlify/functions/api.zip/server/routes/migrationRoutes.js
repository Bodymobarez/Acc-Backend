"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var migrationRoutes_exports = {};
__export(migrationRoutes_exports, {
  default: () => migrationRoutes_default
});
module.exports = __toCommonJS(migrationRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
var import_accountingService = require("../services/accountingService");
const router = (0, import_express.Router)();
router.post("/create-all-journal-entries", async (req, res) => {
  try {
    console.log("\u{1F680} Creating journal entries for ALL transactions...\n");
    const stats = {
      bookings: { processed: 0, success: 0, skipped: 0, failed: 0 },
      invoices: { processed: 0, success: 0, skipped: 0, failed: 0 },
      receipts: { processed: 0, success: 0, skipped: 0, failed: 0 },
      commissions: 0
    };
    console.log("\u{1F4E6} Processing Bookings...");
    const bookings = await import_prisma.prisma.bookings.findMany({
      include: {
        suppliers: true,
        customers: true,
        users: true,
        booking_suppliers: {
          include: { suppliers: true }
        }
      },
      orderBy: { createdAt: "asc" }
    });
    for (const booking of bookings) {
      stats.bookings.processed++;
      try {
        const existing = await import_prisma.prisma.journal_entries.findFirst({
          where: { bookingId: booking.id, transactionType: "BOOKING_COST" }
        });
        if (existing) {
          stats.bookings.skipped++;
          continue;
        }
        await import_accountingService.accountingService.createBookingJournalEntry(booking);
        stats.bookings.success++;
        if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
          await import_accountingService.accountingService.createCommissionJournalEntry(booking, "AGENT");
          stats.commissions++;
        }
        if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
          await import_accountingService.accountingService.createCommissionJournalEntry(booking, "CS");
          stats.commissions++;
        }
      } catch (error) {
        stats.bookings.failed++;
        console.error(`\u274C Booking ${booking.bookingNumber}:`, error.message);
      }
    }
    console.log("\u{1F4C4} Processing Invoices...");
    const invoices = await import_prisma.prisma.invoices.findMany({
      include: {
        customers: true,
        bookings: true
      },
      orderBy: { createdAt: "asc" }
    });
    for (const invoice of invoices) {
      stats.invoices.processed++;
      try {
        const existing = await import_prisma.prisma.journal_entries.findFirst({
          where: { invoiceId: invoice.id, transactionType: "INVOICE_REVENUE" }
        });
        if (existing) {
          stats.invoices.skipped++;
          continue;
        }
        await import_accountingService.accountingService.createInvoiceJournalEntry(invoice);
        stats.invoices.success++;
      } catch (error) {
        stats.invoices.failed++;
        console.error(`\u274C Invoice ${invoice.invoiceNumber}:`, error.message);
      }
    }
    console.log("\u{1F4B0} Processing Receipts...");
    const receipts = await import_prisma.prisma.receipts.findMany({
      include: { customers: true },
      orderBy: { createdAt: "asc" }
    });
    for (const receipt of receipts) {
      stats.receipts.processed++;
      try {
        const existing = await import_prisma.prisma.journal_entries.findFirst({
          where: { reference: receipt.receiptNumber, transactionType: "RECEIPT_PAYMENT" }
        });
        if (existing) {
          stats.receipts.skipped++;
          continue;
        }
        await import_accountingService.accountingService.createReceiptJournalEntry(receipt);
        stats.receipts.success++;
      } catch (error) {
        stats.receipts.failed++;
        console.error(`\u274C Receipt ${receipt.receiptNumber}:`, error.message);
      }
    }
    const totalEntries = await import_prisma.prisma.journal_entries.count();
    const postedEntries = await import_prisma.prisma.journal_entries.count({ where: { status: "POSTED" } });
    console.log("\n\u2705 All journal entries created!");
    res.json({
      success: true,
      message: "Journal entries created successfully",
      stats,
      journalEntries: {
        total: totalEntries,
        posted: postedEntries,
        draft: totalEntries - postedEntries
      }
    });
  } catch (error) {
    console.error("\u274C Error:", error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});
router.post("/create-booking-journal-entries", import_auth.authenticate, async (req, res) => {
  try {
    console.log("\u{1F527} Starting migration: Creating journal entries for existing bookings...");
    const bookings = await import_prisma.prisma.bookings.findMany({
      include: {
        suppliers: true,
        customers: true,
        users: true
      },
      orderBy: {
        createdAt: "asc"
      }
    });
    console.log(`\u{1F4E6} Found ${bookings.length} total bookings`);
    let successCount = 0;
    let skippedCount = 0;
    let errorCount = 0;
    for (const booking of bookings) {
      try {
        const existingEntries = await import_prisma.prisma.journal_entries.findFirst({
          where: { bookingId: booking.id }
        });
        if (existingEntries) {
          console.log(`\u23ED\uFE0F  Skipping booking ${booking.bookingNumber} - already has journal entries`);
          skippedCount++;
          continue;
        }
        console.log(`\u2728 Creating journal entries for booking ${booking.bookingNumber}...`);
        await import_accountingService.accountingService.createBookingJournalEntry(booking);
        if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
          await import_accountingService.accountingService.createCommissionJournalEntry(booking, "AGENT");
        }
        if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
          await import_accountingService.accountingService.createCommissionJournalEntry(booking, "CS");
        }
        successCount++;
        console.log(`\u2705 Created journal entries for booking ${booking.bookingNumber}`);
      } catch (error) {
        errorCount++;
        console.error(`\u274C Error creating journal entries for booking ${booking.bookingNumber}:`, error.message);
      }
    }
    const summary = {
      total: bookings.length,
      success: successCount,
      skipped: skippedCount,
      errors: errorCount
    };
    console.log("\u{1F4CA} Migration Summary:", summary);
    res.json({
      success: true,
      message: "Migration completed",
      summary
    });
  } catch (error) {
    console.error("\u274C Migration failed:", error);
    res.status(500).json({
      success: false,
      error: "Migration failed",
      details: error.message
    });
  }
});
router.post("/recalculate-account-balances", import_auth.authenticate, async (req, res) => {
  try {
    console.log("\u{1F527} Starting migration: Recalculating account balances...");
    const accounts = await import_prisma.prisma.accounts.findMany();
    console.log(`\u{1F4E6} Found ${accounts.length} accounts`);
    let updatedCount = 0;
    for (const account of accounts) {
      try {
        const debitEntries = await import_prisma.prisma.journal_entries.findMany({
          where: { debitAccountId: account.id }
        });
        const creditEntries = await import_prisma.prisma.journal_entries.findMany({
          where: { creditAccountId: account.id }
        });
        const totalDebits = debitEntries.reduce((sum, entry) => sum + Number(entry.amount), 0);
        const totalCredits = creditEntries.reduce((sum, entry) => sum + Number(entry.amount), 0);
        let balance = 0;
        if (account.type === "ASSET" || account.type === "EXPENSE") {
          balance = totalDebits - totalCredits;
        } else {
          balance = totalCredits - totalDebits;
        }
        await import_prisma.prisma.accounts.update({
          where: { id: account.id },
          data: {
            balance,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        updatedCount++;
        console.log(`\u2705 Updated balance for ${account.name} (${account.code}): AED ${balance.toFixed(2)}`);
      } catch (error) {
        console.error(`\u274C Error updating account ${account.name}:`, error.message);
      }
    }
    console.log(`\u{1F4CA} Updated ${updatedCount} account balances`);
    res.json({
      success: true,
      message: "Account balances recalculated",
      updatedCount
    });
  } catch (error) {
    console.error("\u274C Migration failed:", error);
    res.status(500).json({
      success: false,
      error: "Migration failed",
      details: error.message
    });
  }
});
var migrationRoutes_default = router;
