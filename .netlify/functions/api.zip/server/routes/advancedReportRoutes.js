"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var advancedReportRoutes_exports = {};
__export(advancedReportRoutes_exports, {
  default: () => advancedReportRoutes_default
});
module.exports = __toCommonJS(advancedReportRoutes_exports);
var import_express = require("express");
var import_auth = require("../middleware/auth");
var import_prisma = require("../lib/prisma");
const router = (0, import_express.Router)();
const exchangeRates = {
  // Base
  AED: 1,
  // Major Currencies
  USD: 3.67,
  EUR: 4.1,
  GBP: 4.75,
  CHF: 4.15,
  CAD: 2.65,
  AUD: 2.38,
  NZD: 2.18,
  // GCC Currencies
  SAR: 0.98,
  KWD: 12.05,
  QAR: 1.01,
  BHD: 9.73,
  OMR: 9.54,
  // Middle East & North Africa
  EGP: 0.075,
  JOD: 5.17,
  LBP: 4e-5,
  TRY: 0.11,
  IQD: 28e-4,
  SYP: 14e-5,
  YER: 0.015,
  ILS: 1.02,
  MAD: 0.37,
  TND: 1.18,
  DZD: 0.027,
  LYD: 0.76,
  SDG: 61e-4,
  IRR: 87e-6,
  AFN: 0.053,
  // Asian Currencies
  INR: 0.044,
  PKR: 0.013,
  BDT: 0.031,
  PHP: 0.063,
  IDR: 23e-5,
  MYR: 0.82,
  SGD: 2.73,
  THB: 0.106,
  VND: 15e-5,
  CNY: 0.51,
  JPY: 0.024,
  KRW: 28e-4,
  AZN: 2.16,
  GEL: 1.33,
  // European Currencies
  SEK: 0.35,
  NOK: 0.34,
  DKK: 0.55,
  PLN: 0.92,
  CZK: 0.16,
  HUF: 0.01,
  RUB: 0.038,
  // African Currencies
  ZAR: 0.2,
  NGN: 24e-4,
  KES: 0.028,
  GHS: 0.24,
  TZS: 14e-4,
  UGX: 98e-5,
  ETB: 0.029,
  // Latin American Currencies
  BRL: 0.63,
  MXN: 0.18,
  ARS: 37e-4,
  CLP: 38e-4,
  COP: 84e-5,
  PEN: 0.97
};
const convertToAED = (amount, currency) => {
  return amount * (exchangeRates[currency] || 1);
};
const convertFromAED = (amountInAED, targetCurrency) => {
  if (targetCurrency === "AED") return amountInAED;
  const rate = exchangeRates[targetCurrency] || 1;
  return amountInAED / rate;
};
const convertCurrency = (amount, fromCurrency, toCurrency) => {
  if (fromCurrency === toCurrency) return amount;
  const amountInAED = convertToAED(amount, fromCurrency);
  return convertFromAED(amountInAED, toCurrency);
};
router.get("/financial-old-deprecated", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: { in: ["CONFIRMED", "REFUNDED"] }
      },
      include: {
        customers: { select: { firstName: true, lastName: true, companyName: true } },
        suppliers: { select: { companyName: true } }
      }
    });
    let totalRevenue = 0;
    let totalCost = 0;
    let totalProfit = 0;
    let totalCommissions = 0;
    bookings.forEach((booking) => {
      const revenue = convertToAED(booking.saleAmount, booking.saleCurrency);
      const cost = convertToAED(booking.costAmount, booking.costCurrency);
      totalRevenue += revenue;
      totalCost += cost;
      totalProfit += booking.netProfit || 0;
      totalCommissions += booking.totalCommission || 0;
    });
    res.json({
      success: true,
      data: {
        summary: {
          "Total Revenue": totalRevenue,
          "Total Cost": totalCost,
          "Gross Profit": totalProfit,
          "Total Commissions": totalCommissions
        },
        details: bookings.map((b) => ({
          Date: new Date(b.bookingDate).toLocaleDateString(),
          "Booking #": b.bookingNumber,
          Customer: b.customers?.companyName || `${b.customers?.firstName || ""} ${b.customers?.lastName || ""}`.trim() || "N/A",
          Supplier: b.suppliers?.companyName,
          Revenue: convertToAED(b.saleAmount, b.saleCurrency),
          Cost: convertToAED(b.costAmount, b.costCurrency),
          Profit: b.netProfit || 0
        }))
      }
    });
  } catch (error) {
    console.error("Error generating financial report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/bookings", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate }
      },
      include: {
        customers: { select: { firstName: true, lastName: true, companyName: true } },
        suppliers: { select: { companyName: true } },
        bookingAgent: { select: { users: { select: { firstName: true, lastName: true } } } },
        customerService: { select: { users: { select: { firstName: true, lastName: true } } } }
      }
    });
    res.json({
      success: true,
      data: {
        summary: {
          "Total Bookings": bookings.length,
          "Confirmed": bookings.filter((b) => b.status === "CONFIRMED").length,
          "Refunded": bookings.filter((b) => b.status === "REFUNDED" || b.status === "REFUNDED").length
        },
        details: bookings.map((b) => ({
          Date: new Date(b.bookingDate).toLocaleDateString(),
          "Booking #": b.bookingNumber,
          Customer: b.customers?.companyName || `${b.customers?.firstName || ""} ${b.customers?.lastName || ""}`.trim() || "N/A",
          Service: b.serviceType,
          Status: b.status,
          "Sale Amount": convertToAED(b.saleAmount, b.saleCurrency),
          Agent: b.bookingAgent ? `${b.bookingAgent.users.firstName} ${b.bookingAgent.users.lastName}` : "N/A"
        }))
      }
    });
  } catch (error) {
    console.error("Error generating bookings report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/employees", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: { in: ["CONFIRMED", "REFUNDED"] }
      },
      include: {
        bookingAgent: {
          select: {
            id: true,
            users: { select: { firstName: true, lastName: true } }
          }
        },
        customerService: {
          select: {
            id: true,
            users: { select: { firstName: true, lastName: true } }
          }
        }
      }
    });
    const employeeMap = /* @__PURE__ */ new Map();
    bookings.forEach((booking) => {
      if (booking.bookingAgent && booking.agentCommissionAmount) {
        const id = booking.bookingAgent.id;
        const name = `${booking.bookingAgent.users.firstName} ${booking.bookingAgent.users.lastName}`;
        if (!employeeMap.has(id)) {
          employeeMap.set(id, { name, commission: 0, bookings: 0, type: "Agent" });
        }
        const emp = employeeMap.get(id);
        emp.commission += booking.agentCommissionAmount;
        emp.bookings += 1;
      }
      if (booking.customerService && booking.csCommissionAmount) {
        const id = booking.customerService.id;
        const name = `${booking.customerService.users.firstName} ${booking.customerService.users.lastName}`;
        if (!employeeMap.has(id)) {
          employeeMap.set(id, { name, commission: 0, bookings: 0, type: "CS" });
        }
        const emp = employeeMap.get(id);
        emp.commission += booking.csCommissionAmount;
        emp.bookings += 1;
      }
    });
    const employees = Array.from(employeeMap.values());
    const totalCommissions = employees.reduce((sum, e) => sum + e.commission, 0);
    res.json({
      success: true,
      data: {
        summary: {
          "Total Employees": employees.length,
          "Total Commissions": totalCommissions,
          "Total Bookings": bookings.length
        },
        details: employees.map((e) => ({
          Employee: e.name,
          Type: e.type,
          "Total Bookings": e.bookings,
          "Total Commission": e.commission,
          "Avg per Booking": e.bookings > 0 ? e.commission / e.bookings : 0
        }))
      }
    });
  } catch (error) {
    console.error("Error generating employee report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/customers", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate }
      },
      include: {
        customers: { select: { firstName: true, lastName: true, companyName: true, email: true, phone: true } }
      }
    });
    const customerMap = /* @__PURE__ */ new Map();
    bookings.forEach((booking) => {
      const customerId = booking.customerId;
      if (!customerMap.has(customerId)) {
        customerMap.set(customerId, {
          name: booking.customers?.companyName || `${booking.customers?.firstName || ""} ${booking.customers?.lastName || ""}`.trim() || "N/A",
          email: booking.customers?.email,
          phone: booking.customers?.phone,
          bookings: 0,
          revenue: 0
        });
      }
      const cust = customerMap.get(customerId);
      cust.bookings += 1;
      cust.revenue += convertToAED(booking.saleAmount, booking.saleCurrency);
    });
    const customers = Array.from(customerMap.values());
    const totalRevenue = customers.reduce((sum, c) => sum + c.revenue, 0);
    res.json({
      success: true,
      data: {
        summary: {
          "Total Customers": customers.length,
          "Total Revenue": totalRevenue,
          "Total Bookings": bookings.length
        },
        details: customers.map((c) => ({
          Customer: c.name,
          Email: c.email,
          Phone: c.phone,
          "Total Bookings": c.bookings,
          "Total Revenue": c.revenue,
          "Avg per Booking": c.bookings > 0 ? c.revenue / c.bookings : 0
        }))
      }
    });
  } catch (error) {
    console.error("Error generating customer report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/suppliers", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        supplierId: { not: null }
      },
      include: {
        suppliers: { select: { companyName: true, contactPerson: true, email: true } }
      }
    });
    const supplierMap = /* @__PURE__ */ new Map();
    bookings.forEach((booking) => {
      if (!booking.supplierId) return;
      const supplierId = booking.supplierId;
      if (!supplierMap.has(supplierId)) {
        supplierMap.set(supplierId, {
          name: booking.suppliers?.companyName,
          contact: booking.suppliers?.contactPerson,
          email: booking.suppliers?.email,
          bookings: 0,
          cost: 0
        });
      }
      const supp = supplierMap.get(supplierId);
      supp.bookings += 1;
      supp.cost += convertToAED(booking.costAmount, booking.costCurrency);
    });
    const suppliers = Array.from(supplierMap.values());
    const totalCost = suppliers.reduce((sum, s) => sum + s.cost, 0);
    res.json({
      success: true,
      data: {
        summary: {
          "Total Suppliers": suppliers.length,
          "Total Cost": totalCost,
          "Total Bookings": bookings.length
        },
        details: suppliers.map((s) => ({
          Supplier: s.name,
          Contact: s.contact,
          Email: s.email,
          "Total Bookings": s.bookings,
          "Total Cost": s.cost,
          "Avg per Booking": s.bookings > 0 ? s.cost / s.bookings : 0
        }))
      }
    });
  } catch (error) {
    console.error("Error generating supplier report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/vat", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        vatApplicable: true
      }
    });
    let totalVAT = 0;
    let totalNetBeforeVAT = 0;
    let totalWithVAT = 0;
    const details = bookings.map((booking) => {
      const vat = booking.vatAmount || 0;
      const net = booking.netBeforeVAT || 0;
      const total = booking.totalWithVAT || 0;
      totalVAT += vat;
      totalNetBeforeVAT += net;
      totalWithVAT += total;
      return {
        Date: new Date(booking.bookingDate).toLocaleDateString(),
        "Booking #": booking.bookingNumber,
        "Net Before VAT": net,
        "VAT Amount": vat,
        "Total with VAT": total
      };
    });
    res.json({
      success: true,
      data: {
        summary: {
          "Total Net Before VAT": totalNetBeforeVAT,
          "Total VAT": totalVAT,
          "Total with VAT": totalWithVAT,
          "VAT Rate": "5%"
        },
        details
      }
    });
  } catch (error) {
    console.error("Error generating VAT report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/customer-statement/:customerId", import_auth.authenticate, async (req, res) => {
  try {
    const { customerId } = req.params;
    const { dateFrom, dateTo, currency } = req.query;
    const targetCurrency = currency || "AED";
    console.log("\u{1F4CA} Customer Statement Request:", {
      customerId,
      dateFrom,
      dateTo,
      currency: targetCurrency
    });
    const dateToEnd = new Date(dateTo);
    dateToEnd.setDate(dateToEnd.getDate() + 1);
    const invoices = await import_prisma.prisma.invoices.findMany({
      where: {
        customerId,
        invoiceDate: {
          gte: new Date(dateFrom),
          lt: dateToEnd
        }
      },
      orderBy: { invoiceDate: "asc" },
      select: {
        id: true,
        invoiceNumber: true,
        invoiceDate: true,
        totalAmount: true,
        status: true,
        bookings: {
          select: {
            bookingNumber: true,
            serviceType: true,
            serviceDetails: true
          }
        }
      }
    });
    console.log(`\u{1F4C4} Found ${invoices.length} invoices:`, invoices);
    const allInvoices = await import_prisma.prisma.invoices.findMany({
      where: { customerId },
      select: { invoiceNumber: true, invoiceDate: true, totalAmount: true }
    });
    console.log(`\u{1F4CB} Total invoices for customer (any date): ${allInvoices.length}`, allInvoices);
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: {
        customerId,
        receiptDate: {
          gte: new Date(dateFrom),
          lt: dateToEnd
        },
        status: { not: "CANCELLED" }
      },
      orderBy: { receiptDate: "asc" },
      select: {
        id: true,
        receiptNumber: true,
        receiptDate: true,
        amount: true,
        paymentMethod: true,
        reference: true,
        invoiceId: true
      }
    });
    console.log(`\u{1F4B0} Found ${receipts.length} receipts:`, receipts);
    const openingInvoices = await import_prisma.prisma.invoices.findMany({
      where: {
        customerId,
        invoiceDate: { lt: new Date(dateFrom) }
      },
      select: { totalAmount: true }
    });
    const openingReceipts = await import_prisma.prisma.receipts.findMany({
      where: {
        customerId,
        receiptDate: { lt: new Date(dateFrom) },
        status: { not: "CANCELLED" }
      },
      select: { amount: true }
    });
    const customer = await import_prisma.prisma.customers.findUnique({
      where: { id: customerId },
      select: {
        depositAmount: true,
        openingBalance: true
      }
    });
    const depositAmount = customer?.depositAmount || 0;
    const customerOpeningBalance = customer?.openingBalance || 0;
    const transactionsOpeningBalance = openingInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0) - openingReceipts.reduce((sum, rec) => sum + rec.amount, 0);
    const openingBalance = transactionsOpeningBalance + customerOpeningBalance;
    let balance = openingBalance;
    const transactions = [];
    if (Math.abs(openingBalance) > 0.01) {
      transactions.push({
        date: new Date(dateFrom),
        type: "Opening Balance",
        reference: "-",
        description: "Opening Balance",
        debit: openingBalance > 0 ? openingBalance : 0,
        credit: openingBalance < 0 ? Math.abs(openingBalance) : 0,
        balance: openingBalance,
        currency: targetCurrency
      });
    }
    invoices.forEach((inv) => {
      const amount = inv.totalAmount;
      balance += amount;
      let description = `Invoice ${inv.invoiceNumber}`;
      if (inv.bookings) {
        const serviceType = inv.bookings.serviceType || "";
        let details = {};
        try {
          details = typeof inv.bookings.serviceDetails === "string" ? JSON.parse(inv.bookings.serviceDetails) : inv.bookings.serviceDetails || {};
        } catch (e) {
          details = {};
        }
        let passengerName = "";
        if (details.passengers && details.passengers.length > 0) {
          const passenger = details.passengers[0];
          passengerName = `${passenger.firstName || ""} ${passenger.lastName || ""}`.trim();
        } else if (details.passengerName) {
          passengerName = details.passengerName;
        }
        let serviceInfo = "";
        if (serviceType === "HOTEL" && details.hotelName) {
          serviceInfo = details.hotelName;
        } else if (serviceType === "FLIGHT" && details.airline) {
          serviceInfo = details.airline;
        } else if (serviceType === "VISA") {
          serviceInfo = details.visaType ? `${details.visaType} - ${details.country || ""}` : details.country || "";
        }
        const parts = [passengerName, serviceInfo].filter(Boolean);
        if (parts.length > 0) {
          description = parts.join(" - ");
        }
      }
      const transactionType = inv.bookings?.serviceType || "Invoice";
      transactions.push({
        date: inv.invoiceDate,
        type: transactionType,
        reference: inv.invoiceNumber,
        description,
        debit: amount,
        credit: 0,
        balance,
        currency: targetCurrency
      });
    });
    receipts.forEach((rec) => {
      const amount = rec.amount;
      balance -= amount;
      transactions.push({
        date: rec.receiptDate,
        type: "Receipt",
        reference: rec.receiptNumber,
        description: `Receipt ${rec.receiptNumber} - ${rec.paymentMethod}${rec.reference ? ` (${rec.reference})` : ""}`,
        debit: 0,
        credit: amount,
        balance,
        currency: targetCurrency
      });
    });
    const sortedTransactions = transactions.sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    let runningBalance = openingBalance;
    const recalculatedTransactions = sortedTransactions.map((t, index) => {
      if (index === 0 && t.type === "Opening Balance") {
        return t;
      }
      runningBalance += t.debit - t.credit;
      return { ...t, balance: runningBalance };
    });
    const totalDebit = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalCredit = receipts.reduce((sum, rec) => sum + rec.amount, 0);
    res.json({
      success: true,
      data: {
        transactions: recalculatedTransactions,
        summary: {
          openingBalance,
          depositAmount,
          totalDebit,
          totalCredit,
          closingBalance: openingBalance + totalDebit - totalCredit
        }
      }
    });
  } catch (error) {
    console.error("Error generating customer statement:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/trial-balance", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo, currency } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const journalEntries = await import_prisma.prisma.journal_entries.findMany({
      where: {
        date: { gte: startDate, lte: endDate }
      },
      select: {
        debitAccountId: true,
        creditAccountId: true,
        amount: true
      }
    });
    const accounts = await import_prisma.prisma.accounts.findMany({
      select: {
        id: true,
        code: true,
        name: true,
        nameAr: true
      }
    });
    const balanceMap = /* @__PURE__ */ new Map();
    journalEntries.forEach((entry) => {
      if (entry.debitAccountId) {
        const current = balanceMap.get(entry.debitAccountId) || { debit: 0, credit: 0 };
        current.debit += entry.amount;
        balanceMap.set(entry.debitAccountId, current);
      }
      if (entry.creditAccountId) {
        const current = balanceMap.get(entry.creditAccountId) || { debit: 0, credit: 0 };
        current.credit += entry.amount;
        balanceMap.set(entry.creditAccountId, current);
      }
    });
    const data = accounts.map((account) => {
      const balance = balanceMap.get(account.id) || { debit: 0, credit: 0 };
      return {
        accountCode: account.code,
        accountName: account.name,
        accountNameAr: account.nameAr,
        debit: balance.debit,
        credit: balance.credit
      };
    }).filter((a) => a.debit !== 0 || a.credit !== 0);
    const totalDebit = data.reduce((sum, a) => sum + a.debit, 0);
    const totalCredit = data.reduce((sum, a) => sum + a.credit, 0);
    res.json({
      success: true,
      data: {
        accounts: data,
        totals: {
          totalDebit,
          totalCredit,
          difference: totalDebit - totalCredit
        }
      }
    });
  } catch (error) {
    console.error("Error generating trial balance:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/employee-commissions-monthly", import_auth.authenticate, async (req, res) => {
  try {
    const { year, month, currency } = req.query;
    const startDate = new Date(Number(year), Number(month) - 1, 1);
    const endDate = new Date(Number(year), Number(month), 0);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: { in: ["CONFIRMED", "REFUNDED", "COMPLETE"] }
      },
      select: {
        id: true,
        bookingNumber: true,
        bookingDate: true,
        serviceType: true,
        serviceDetails: true,
        status: true,
        saleCurrency: true,
        costCurrency: true,
        saleAmount: true,
        costAmount: true,
        grossProfit: true,
        agentCommissionAmount: true,
        csCommissionAmount: true,
        salesCommissionAmount: true,
        employees_bookings_bookingAgentIdToemployees: {
          select: {
            id: true,
            users: { select: { firstName: true, lastName: true } }
          }
        },
        employees_bookings_customerServiceIdToemployees: {
          select: {
            id: true,
            users: { select: { firstName: true, lastName: true } }
          }
        },
        customers: { select: { firstName: true, lastName: true, companyName: true } }
      }
    });
    const employeeMap = /* @__PURE__ */ new Map();
    const targetCurrency = currency || "AED";
    bookings.forEach((booking) => {
      const bookingAgent = booking.employees_bookings_bookingAgentIdToemployees;
      if (bookingAgent && booking.agentCommissionAmount) {
        const id = bookingAgent.id;
        const name = `${bookingAgent.users.firstName} ${bookingAgent.users.lastName}`;
        const commissionInTargetCurrency = convertCurrency(
          booking.agentCommissionAmount,
          booking.saleCurrency,
          targetCurrency
        );
        if (!employeeMap.has(id)) {
          employeeMap.set(id, {
            employeeName: name,
            totalBookings: 0,
            totalCommission: 0,
            breakdown: []
          });
        }
        const emp = employeeMap.get(id);
        emp.totalBookings += 1;
        emp.totalCommission += commissionInTargetCurrency;
        let serviceDetailsText = "";
        try {
          const details = JSON.parse(booking.serviceDetails || "{}");
          const hasDetails = Object.keys(details).length > 0;
          if (hasDetails) {
            if (booking.serviceType === "HOTEL") {
              serviceDetailsText = details.hotelName || details.name || "";
            } else if (booking.serviceType === "FLIGHT") {
              serviceDetailsText = details.passengerName || details.passenger || "";
            } else if (booking.serviceType === "VISA") {
              serviceDetailsText = details.passengerName || details.travelerName || details.country || "";
            } else if (booking.serviceType === "TRANSFER") {
              serviceDetailsText = details.passengerName || (details.from && details.to ? `${details.from} \u2192 ${details.to}` : details.route || "");
            } else if (booking.serviceType === "CRUISE") {
              serviceDetailsText = details.passengerName || details.cruiseName || details.shipName || "";
            } else {
              serviceDetailsText = details.passengerName || details.description || details.name || "";
            }
          }
        } catch (e) {
          serviceDetailsText = "";
        }
        if (!serviceDetailsText || serviceDetailsText.trim() === "") {
          serviceDetailsText = "Not specified";
        }
        const saleOrigAgent = Number(booking.saleAmount || 0);
        const costOrigAgent = Number(booking.costAmount || 0);
        const profitInAEDAgent = Number(booking.grossProfit || 0);
        const commissionInAEDAgent = Number(booking.agentCommissionAmount || 0);
        const saleCurrAgent = booking.saleCurrency || "AED";
        const profitInSaleCurrencyAgent = convertCurrency(profitInAEDAgent, "AED", saleCurrAgent);
        const commissionInSaleCurrencyAgent = convertCurrency(commissionInAEDAgent, "AED", saleCurrAgent);
        emp.breakdown.push({
          date: new Date(booking.bookingDate).toLocaleDateString(),
          bookingNumber: booking.bookingNumber,
          customer: booking.customers?.companyName || `${booking.customers?.firstName || ""} ${booking.customers?.lastName || ""}`.trim() || "N/A",
          service: booking.serviceType,
          serviceDetails: serviceDetailsText,
          status: booking.status,
          commission: commissionInTargetCurrency,
          saleCurrency: saleCurrAgent,
          costCurrency: booking.costCurrency || "AED",
          saleOriginal: saleOrigAgent,
          costOriginal: costOrigAgent,
          profitInAED: profitInAEDAgent,
          profitInSaleCurrency: profitInSaleCurrencyAgent,
          commissionInAED: commissionInAEDAgent,
          commissionInSaleCurrency: commissionInSaleCurrencyAgent,
          commissionOriginal: commissionInAEDAgent
        });
      }
      const customerService = booking.employees_bookings_customerServiceIdToemployees;
      if (customerService && booking.csCommissionAmount) {
        const id = customerService.id;
        const name = `${customerService.users.firstName} ${customerService.users.lastName}`;
        const commissionInTargetCurrency = convertCurrency(
          booking.csCommissionAmount,
          booking.saleCurrency,
          targetCurrency
        );
        if (!employeeMap.has(id)) {
          employeeMap.set(id, {
            employeeName: name,
            totalBookings: 0,
            totalCommission: 0,
            breakdown: []
          });
        }
        const emp = employeeMap.get(id);
        emp.totalBookings += 1;
        emp.totalCommission += commissionInTargetCurrency;
        let serviceDetailsText = "";
        try {
          const details = JSON.parse(booking.serviceDetails || "{}");
          const hasDetails = Object.keys(details).length > 0;
          if (hasDetails) {
            if (booking.serviceType === "HOTEL") {
              serviceDetailsText = details.hotelName || details.name || "";
            } else if (booking.serviceType === "FLIGHT") {
              serviceDetailsText = details.passengerName || details.passenger || "";
            } else if (booking.serviceType === "VISA") {
              serviceDetailsText = details.passengerName || details.travelerName || details.country || "";
            } else if (booking.serviceType === "TRANSFER") {
              serviceDetailsText = details.passengerName || (details.from && details.to ? `${details.from} \u2192 ${details.to}` : details.route || "");
            } else if (booking.serviceType === "CRUISE") {
              serviceDetailsText = details.passengerName || details.cruiseName || details.shipName || "";
            } else {
              serviceDetailsText = details.passengerName || details.description || details.name || "";
            }
          }
        } catch (e) {
          serviceDetailsText = "";
        }
        if (!serviceDetailsText || serviceDetailsText.trim() === "") {
          serviceDetailsText = "Not specified";
        }
        const saleOrigCS = Number(booking.saleAmount || 0);
        const costOrigCS = Number(booking.costAmount || 0);
        const profitInAEDCS = Number(booking.grossProfit || 0);
        const commissionInAEDCS = Number(booking.csCommissionAmount || 0);
        const saleCurrCS = booking.saleCurrency || "AED";
        const profitInSaleCurrencyCS = convertCurrency(profitInAEDCS, "AED", saleCurrCS);
        const commissionInSaleCurrencyCS = convertCurrency(commissionInAEDCS, "AED", saleCurrCS);
        emp.breakdown.push({
          date: new Date(booking.bookingDate).toLocaleDateString(),
          bookingNumber: booking.bookingNumber,
          customer: booking.customers?.companyName || `${booking.customers?.firstName || ""} ${booking.customers?.lastName || ""}`.trim() || "N/A",
          service: booking.serviceType,
          serviceDetails: serviceDetailsText,
          status: booking.status,
          commission: commissionInTargetCurrency,
          saleCurrency: saleCurrCS,
          costCurrency: booking.costCurrency || "AED",
          saleOriginal: saleOrigCS,
          costOriginal: costOrigCS,
          profitInAED: profitInAEDCS,
          profitInSaleCurrency: profitInSaleCurrencyCS,
          commissionInAED: commissionInAEDCS,
          commissionInSaleCurrency: commissionInSaleCurrencyCS,
          commissionOriginal: commissionInAEDCS
        });
      }
    });
    const employees = Array.from(employeeMap.values()).map((emp) => {
      const confirmedCount = emp.breakdown.filter((b) => b.status === "CONFIRMED" || b.status === "COMPLETE").length;
      const refundedCount = emp.breakdown.filter((b) => b.status === "REFUNDED").length;
      return {
        ...emp,
        averageCommission: emp.totalCommission / emp.totalBookings,
        currency: currency || "AED",
        confirmedCount,
        refundedCount
      };
    });
    res.json({
      success: true,
      data: {
        employees,
        summary: {
          totalEmployees: employees.length,
          totalBookings: bookings.length,
          totalCommissions: employees.reduce((sum, e) => sum + e.totalCommission, 0),
          averagePerEmployee: employees.length > 0 ? employees.reduce((sum, e) => sum + e.totalCommission, 0) / employees.length : 0
        }
      }
    });
  } catch (error) {
    console.error("Error generating employee commissions report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/employee-commissions-monthly/:employeeId", import_auth.authenticate, async (req, res) => {
  try {
    const { employeeId } = req.params;
    const { year, month, currency } = req.query;
    const startDate = new Date(Number(year), Number(month) - 1, 1);
    const endDate = new Date(Number(year), Number(month), 0);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        OR: [
          { bookingAgentId: employeeId },
          { customerServiceId: employeeId }
        ],
        bookingDate: { gte: startDate, lte: endDate },
        status: { in: ["CONFIRMED", "REFUNDED", "COMPLETE"] }
      },
      include: {
        customers: { select: { firstName: true, lastName: true, companyName: true } },
        employees_bookings_bookingAgentIdToemployees: {
          include: { users: { select: { firstName: true, lastName: true } } }
        }
      }
    });
    const targetCurrency = currency || "AED";
    let confirmedCount = 0;
    let refundedCount = 0;
    const transactions = bookings.map((b) => {
      if (b.status === "CONFIRMED" || b.status === "COMPLETE") confirmedCount++;
      else if (b.status === "REFUNDED") refundedCount++;
      let commissionInAED = 0;
      if (b.bookingAgentId === employeeId && b.agentCommissionAmount) {
        commissionInAED += Number(b.agentCommissionAmount || 0);
      }
      if (b.customerServiceId === employeeId && (b.csCommissionAmount || b.salesCommissionAmount)) {
        commissionInAED += Number(b.csCommissionAmount || b.salesCommissionAmount || 0);
      }
      const saleOrig = Number(b.saleAmount || 0);
      const costOrig = Number(b.costAmount || 0);
      const profitInAED = Number(b.grossProfit || 0);
      const saleCurr = b.saleCurrency || "AED";
      const profitInSaleCurrency = convertCurrency(profitInAED, "AED", saleCurr);
      const commissionInSaleCurrency = convertCurrency(commissionInAED, "AED", saleCurr);
      const commissionInTargetCurrency = convertCurrency(commissionInAED, "AED", targetCurrency);
      return {
        date: b.bookingDate.toISOString().split("T")[0],
        bookingNumber: b.bookingNumber,
        bookingId: b.id,
        customer: b.customers?.companyName || `${b.customers?.firstName || ""} ${b.customers?.lastName || ""}`.trim() || "N/A",
        serviceType: b.serviceType || "N/A",
        serviceDetails: b.serviceDetails || "",
        status: b.status,
        commission: commissionInTargetCurrency,
        saleCurrency: saleCurr,
        costCurrency: b.costCurrency || "AED",
        saleOriginal: saleOrig,
        costOriginal: costOrig,
        profitInAED,
        profitInSaleCurrency,
        commissionInAED,
        commissionInSaleCurrency,
        commissionOriginal: commissionInAED,
        currency: targetCurrency
      };
    });
    const totalCommission = transactions.reduce((sum, t) => sum + t.commission, 0);
    const employee = await import_prisma.prisma.employees.findUnique({
      where: { id: employeeId },
      include: { users: { select: { firstName: true, lastName: true } } }
    });
    const employeeName = employee ? `${employee.users.firstName} ${employee.users.lastName}` : "Unknown";
    const employees = [{
      employeeName,
      totalBookings: transactions.length,
      totalCommission,
      averageCommission: transactions.length > 0 ? totalCommission / transactions.length : 0,
      currency: targetCurrency,
      confirmedCount,
      refundedCount,
      breakdown: transactions
    }];
    res.json({
      success: true,
      data: {
        employees,
        summary: {
          totalEmployees: 1,
          totalBookings: transactions.length,
          totalCommissions: totalCommission,
          averagePerEmployee: totalCommission,
          confirmedBookings: confirmedCount,
          refundedBookings: refundedCount
        }
      }
    });
  } catch (error) {
    console.error("Error generating employee report:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/vat-return", import_auth.authenticate, async (req, res) => {
  try {
    const { year, month } = req.query;
    const startDate = new Date(Number(year), Number(month) - 1, 1);
    const endDate = new Date(Number(year), Number(month), 0);
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        vatApplicable: true
      }
    });
    const standardRatedSupplies = bookings.reduce((sum, b) => sum + (b.netBeforeVAT || 0), 0);
    const taxOnStandardRatedSupplies = bookings.reduce((sum, b) => sum + (b.vatAmount || 0), 0);
    const payments = await import_prisma.prisma.payments.findMany({
      where: {
        paymentDate: { gte: startDate, lte: endDate }
      }
    });
    const standardRatedPurchases = payments.reduce((sum, p) => sum + p.amount, 0);
    const inputVATOnPurchases = standardRatedPurchases * 0.05;
    const totalVATDue = taxOnStandardRatedSupplies;
    const recoverableVAT = inputVATOnPurchases;
    const netVATDue = totalVATDue - recoverableVAT;
    res.json({
      success: true,
      data: {
        standardRatedSupplies,
        taxOnStandardRatedSupplies,
        zeroRatedSupplies: 0,
        exemptSupplies: 0,
        goodsImported: 0,
        adjustments: 0,
        totalVATDue,
        standardRatedPurchases,
        inputVATOnPurchases,
        recoverableVAT,
        netVATDue
      }
    });
  } catch (error) {
    console.error("Error generating VAT return:", error);
    res.status(500).json({ success: false, error: "Failed to generate report" });
  }
});
router.get("/:reportType/export", import_auth.authenticate, async (req, res) => {
  try {
    res.json({
      success: true,
      message: "Export functionality will be implemented with Excel library"
    });
  } catch (error) {
    console.error("Error exporting report:", error);
    res.status(500).json({ success: false, error: "Failed to export report" });
  }
});
router.get("/supplier-statement/:supplierId", import_auth.authenticate, async (req, res) => {
  try {
    const { supplierId } = req.params;
    const { dateFrom, dateTo, currency = "AED" } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const supplier = await import_prisma.prisma.suppliers.findUnique({
      where: { id: supplierId }
    });
    if (!supplier) {
      return res.status(404).json({ success: false, error: "Supplier not found" });
    }
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        supplierId,
        bookingDate: { gte: startDate, lte: endDate }
      },
      orderBy: { bookingDate: "asc" }
    });
    const payments = await import_prisma.prisma.payments.findMany({
      where: {
        supplierId,
        paymentDate: { gte: startDate, lte: endDate }
      },
      orderBy: { paymentDate: "asc" }
    });
    const previousBookings = await import_prisma.prisma.bookings.findMany({
      where: { supplierId, bookingDate: { lt: startDate } }
    });
    const previousPayments = await import_prisma.prisma.payments.findMany({
      where: { supplierId, paymentDate: { lt: startDate } }
    });
    const targetCurrency = currency || "AED";
    let openingBalance = 0;
    previousBookings.forEach((b) => {
      const amountInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      openingBalance += convertFromAED(amountInAED, targetCurrency);
    });
    previousPayments.forEach((p) => {
      const amountInAED = p.amount;
      openingBalance -= convertFromAED(amountInAED, targetCurrency);
    });
    const transactions = [];
    let totalDebit = 0;
    let totalCredit = 0;
    let runningBalance = openingBalance;
    bookings.forEach((b) => {
      const amountInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      const amount = convertFromAED(amountInAED, targetCurrency);
      runningBalance += amount;
      totalCredit += amount;
      transactions.push({
        date: b.bookingDate.toISOString(),
        type: "Booking",
        reference: b.bookingNumber,
        description: `Booking ${b.bookingNumber}`,
        serviceDetails: b.serviceType || "",
        bookingId: b.id,
        debit: 0,
        credit: amount,
        balance: runningBalance,
        currency: targetCurrency
      });
    });
    payments.forEach((p) => {
      const amountInAED = p.amount;
      const amount = convertFromAED(amountInAED, targetCurrency);
      runningBalance -= amount;
      totalDebit += amount;
      transactions.push({
        date: p.paymentDate.toISOString(),
        type: "Payment",
        reference: p.paymentNumber,
        description: p.notes || "Payment",
        debit: amount,
        credit: 0,
        balance: runningBalance,
        currency: targetCurrency
      });
    });
    transactions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    res.json({
      success: true,
      data: {
        supplier: {
          name: supplier.companyName,
          id: supplier.id
        },
        summary: {
          openingBalance,
          totalDebit,
          totalCredit,
          closingBalance: runningBalance
        },
        transactions
      }
    });
  } catch (error) {
    console.error("Error generating supplier statement:", error);
    res.status(500).json({ success: false, error: "Failed to generate supplier statement" });
  }
});
router.get("/financial-summary", import_auth.authenticate, async (req, res) => {
  console.log("\u{1F3AF} Financial Summary API called");
  try {
    const { dateFrom, dateTo, currency = "AED" } = req.query;
    console.log("\u{1F4C5} Date range:", dateFrom, "to", dateTo);
    const startDate = new Date(String(dateFrom));
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(String(dateTo));
    endDate.setHours(23, 59, 59, 999);
    const confirmedBookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: "CONFIRMED"
      },
      orderBy: { bookingDate: "asc" }
    });
    console.log("\u{1F50D} Querying REFUNDED bookings with dates:", startDate, "to", endDate);
    const refundedBookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: "REFUNDED"
      },
      orderBy: { bookingDate: "asc" }
    });
    console.log("\u{1F4CA} Found", refundedBookings.length, "refunded bookings");
    let totalRevenue = 0;
    let totalCost = 0;
    let totalCommissions = 0;
    confirmedBookings.forEach((b) => {
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      totalRevenue += Math.abs(saleInAED);
      totalCost += Math.abs(costInAED);
      totalCommissions += Math.abs(b.totalCommission || 0);
    });
    let totalRefunds = 0;
    let refundCost = 0;
    refundedBookings.forEach((b) => {
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      console.log(`  \u2192 ${b.bookingNumber}: saleInAED=${saleInAED}, Math.abs=${Math.abs(saleInAED)}`);
      totalRefunds += Math.abs(saleInAED);
      refundCost += Math.abs(costInAED);
    });
    console.log("\u{1F4B0} Final totalRefunds:", totalRefunds, "| refundCost:", refundCost);
    const netRevenue = totalRevenue - totalRefunds;
    const netCost = totalCost - refundCost;
    const grossProfit = netRevenue - netCost;
    const netProfit = grossProfit - totalCommissions;
    const profitMargin = netRevenue > 0 ? (netProfit / netRevenue * 100).toFixed(2) : "0.00";
    const monthlyData = {};
    confirmedBookings.forEach((b) => {
      const monthKey = b.bookingDate.toISOString().substring(0, 7);
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = {
          revenue: 0,
          refunds: 0,
          cost: 0,
          refundCost: 0,
          commissions: 0,
          bookings: 0
        };
      }
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      monthlyData[monthKey].revenue += Math.abs(saleInAED);
      monthlyData[monthKey].cost += Math.abs(costInAED);
      monthlyData[monthKey].commissions += Math.abs(b.totalCommission || 0);
      monthlyData[monthKey].bookings += 1;
    });
    refundedBookings.forEach((b) => {
      const monthKey = b.bookingDate.toISOString().substring(0, 7);
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = {
          revenue: 0,
          refunds: 0,
          cost: 0,
          refundCost: 0,
          commissions: 0,
          bookings: 0
        };
      }
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      monthlyData[monthKey].refunds += Math.abs(saleInAED);
      monthlyData[monthKey].refundCost += Math.abs(costInAED);
    });
    const monthlyBreakdown = Object.entries(monthlyData).map(([month, data]) => ({
      Month: month,
      Revenue: data.revenue,
      Refunds: data.refunds,
      "Net Revenue": data.revenue - data.refunds,
      Cost: data.cost,
      "Refund Cost": data.refundCost,
      "Net Cost": data.cost - data.refundCost,
      "Gross Profit": data.revenue - data.refunds - (data.cost - data.refundCost),
      Commissions: data.commissions,
      "Net Profit": data.revenue - data.refunds - (data.cost - data.refundCost) - data.commissions,
      Bookings: data.bookings
    }));
    const targetCurrency = currency;
    const convertedMonthlyBreakdown = monthlyBreakdown.map((month) => ({
      ...month,
      Revenue: convertFromAED(month.Revenue, targetCurrency),
      Refunds: convertFromAED(month.Refunds, targetCurrency),
      "Net Revenue": convertFromAED(month["Net Revenue"], targetCurrency),
      Cost: convertFromAED(month.Cost, targetCurrency),
      "Refund Cost": convertFromAED(month["Refund Cost"], targetCurrency),
      "Net Cost": convertFromAED(month["Net Cost"], targetCurrency),
      "Gross Profit": convertFromAED(month["Gross Profit"], targetCurrency),
      Commissions: convertFromAED(month.Commissions, targetCurrency),
      "Net Profit": convertFromAED(month["Net Profit"], targetCurrency)
    }));
    const responseData = {
      success: true,
      data: {
        totalRevenue: convertFromAED(totalRevenue, targetCurrency),
        totalRefunds: convertFromAED(totalRefunds, targetCurrency),
        netRevenue: convertFromAED(netRevenue, targetCurrency),
        totalCost: convertFromAED(totalCost, targetCurrency),
        refundCost: convertFromAED(refundCost, targetCurrency),
        netCost: convertFromAED(netCost, targetCurrency),
        grossProfit: convertFromAED(grossProfit, targetCurrency),
        totalCommissions: convertFromAED(totalCommissions, targetCurrency),
        netProfit: convertFromAED(netProfit, targetCurrency),
        profitMargin: parseFloat(profitMargin),
        monthlyBreakdown: convertedMonthlyBreakdown,
        confirmedBookingsCount: confirmedBookings.length,
        refundedBookingsCount: refundedBookings.length
      }
    };
    console.log("\u{1F4E4} Sending response:", JSON.stringify({
      totalRevenue,
      totalRefunds,
      refundCost,
      confirmedCount: confirmedBookings.length,
      refundedCount: refundedBookings.length
    }));
    res.json(responseData);
  } catch (error) {
    console.error("Error generating financial summary:", error);
    res.status(500).json({ success: false, error: "Failed to generate financial summary" });
  }
});
router.get("/profit-loss", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo, currency = "AED" } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const confirmedBookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: "CONFIRMED"
      }
    });
    const refundedBookings = await import_prisma.prisma.bookings.findMany({
      where: {
        bookingDate: { gte: startDate, lte: endDate },
        status: "REFUNDED"
      }
    });
    let totalRevenue = 0;
    let totalCost = 0;
    let totalCommissions = 0;
    confirmedBookings.forEach((b) => {
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      totalRevenue += Math.abs(saleInAED);
      totalCost += Math.abs(costInAED);
      totalCommissions += Math.abs(b.totalCommission || 0);
    });
    let totalRefunds = 0;
    let refundCost = 0;
    refundedBookings.forEach((b) => {
      const saleInAED = b.saleInAED || convertToAED(b.saleAmount, b.saleCurrency);
      const costInAED = b.costInAED || convertToAED(b.costAmount, b.costCurrency);
      totalRefunds += Math.abs(saleInAED);
      refundCost += Math.abs(costInAED);
    });
    const netRevenue = totalRevenue - totalRefunds;
    const netCost = totalCost - refundCost;
    const grossProfit = netRevenue - netCost;
    const netProfit = grossProfit - totalCommissions;
    const profitMargin = netRevenue > 0 ? (netProfit / netRevenue * 100).toFixed(2) : "0.00";
    const targetCurrency = currency;
    res.json({
      success: true,
      data: {
        totalRevenue: convertFromAED(totalRevenue, targetCurrency),
        totalRefunds: convertFromAED(totalRefunds, targetCurrency),
        netRevenue: convertFromAED(netRevenue, targetCurrency),
        totalCost: convertFromAED(totalCost, targetCurrency),
        refundCost: convertFromAED(refundCost, targetCurrency),
        netCost: convertFromAED(netCost, targetCurrency),
        grossProfit: convertFromAED(grossProfit, targetCurrency),
        totalCommissions: convertFromAED(totalCommissions, targetCurrency),
        netProfit: convertFromAED(netProfit, targetCurrency),
        profitMargin: parseFloat(profitMargin)
      }
    });
  } catch (error) {
    console.error("Error generating P&L report:", error);
    res.status(500).json({ success: false, error: "Failed to generate P&L report" });
  }
});
router.get("/cash-flow", import_auth.authenticate, async (req, res) => {
  try {
    const { dateFrom, dateTo, currency = "AED" } = req.query;
    const startDate = new Date(dateFrom);
    const endDate = new Date(dateTo);
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: {
        receiptDate: { gte: startDate, lte: endDate }
      },
      include: {
        customers: { select: { firstName: true, lastName: true, companyName: true } }
      },
      orderBy: { receiptDate: "asc" }
    });
    const payments = await import_prisma.prisma.payments.findMany({
      where: {
        paymentDate: { gte: startDate, lte: endDate }
      },
      include: {
        supplier: { select: { companyName: true } }
      },
      orderBy: { paymentDate: "asc" }
    });
    let totalInflows = 0;
    let totalOutflows = 0;
    const details = [];
    receipts.forEach((r) => {
      const amountInTargetCurrency = convertFromAED(r.amount, currency);
      totalInflows += amountInTargetCurrency;
      details.push({
        Date: r.receiptDate.toISOString(),
        Type: "Inflow",
        Reference: r.receiptNumber,
        Method: r.paymentMethod,
        Amount: amountInTargetCurrency
      });
    });
    payments.forEach((p) => {
      const amountInTargetCurrency = convertFromAED(p.amount, currency);
      totalOutflows += amountInTargetCurrency;
      details.push({
        Date: p.paymentDate.toISOString(),
        Type: "Outflow",
        Reference: p.paymentNumber,
        Method: p.paymentMethod,
        Amount: -amountInTargetCurrency
      });
    });
    details.sort((a, b) => new Date(a.Date).getTime() - new Date(b.Date).getTime());
    const netCashFlow = totalInflows - totalOutflows;
    res.json({
      success: true,
      data: {
        totalInflows,
        totalOutflows,
        netCashFlow,
        details
      }
    });
  } catch (error) {
    console.error("Error generating cash flow report:", error);
    res.status(500).json({ success: false, error: "Failed to generate cash flow report" });
  }
});
var advancedReportRoutes_default = router;
