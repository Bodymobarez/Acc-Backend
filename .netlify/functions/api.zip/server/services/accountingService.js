"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var accountingService_exports = {};
__export(accountingService_exports, {
  AccountingService: () => AccountingService,
  accountingService: () => accountingService
});
module.exports = __toCommonJS(accountingService_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
class AccountingService {
  /**
   * Get the fiscal year for a given date
   * Returns the fiscal year that contains this date, or null if none found
   */
  async getFiscalYearForDate(date) {
    const fiscalYear = await import_prisma.prisma.fiscal_years.findFirst({
      where: {
        startDate: { lte: date },
        endDate: { gte: date }
      },
      select: { id: true, status: true, name: true }
    });
    return fiscalYear;
  }
  /**
   * Validate that a date falls within an OPEN fiscal year
   * Throws error if fiscal year is closed or not found
   */
  async validateFiscalYear(date, throwOnClosed = true) {
    const fiscalYear = await this.getFiscalYearForDate(date);
    if (!fiscalYear) {
      console.warn(`\u26A0\uFE0F  No fiscal year found for date: ${date.toISOString()}`);
      return null;
    }
    if (fiscalYear.status === "CLOSED" && throwOnClosed) {
      throw new Error(`\u0644\u0627 \u064A\u0645\u0643\u0646 \u0625\u0636\u0627\u0641\u0629 \u0642\u064A\u0648\u062F \u0644\u0633\u0646\u0629 \u0645\u0627\u0644\u064A\u0629 \u0645\u063A\u0644\u0642\u0629. \u0627\u0644\u062A\u0627\u0631\u064A\u062E ${date.toISOString()} \u064A\u0642\u0639 \u0641\u064A \u0633\u0646\u0629 \u0645\u0627\u0644\u064A\u0629 \u0645\u063A\u0644\u0642\u0629.`);
    }
    return fiscalYear.id;
  }
  /**
   * Get revenue account code based on service type
   */
  getRevenueAccountCode(serviceType) {
    const serviceAccountMap = {
      "FLIGHT": "4110",
      // Flight Booking Revenue
      "HOTEL": "4120",
      // Hotel Booking Revenue
      "VISA": "4130",
      // Visa Services Revenue
      "TRANSFER": "4140",
      // Transfer Services Revenue
      "RENTAL_CAR": "4150",
      // Car Rental Revenue
      "RENT_CAR": "4150",
      // Car Rental Revenue (alias)
      "CRUISE": "4160",
      // Cruise Booking Revenue
      "TRAIN": "4170",
      // Train Tickets Revenue
      "ACTIVITY": "4180",
      // Activity Booking Revenue
      "PACKAGE": "4160",
      // Tourism Package Revenue (same as cruise)
      "UMRAH": "4180"
      // Other Services Revenue
    };
    return serviceAccountMap[serviceType] || "4180";
  }
  /**
   * Get operating cost account code based on service type
   */
  getCostAccountCode(serviceType) {
    const costAccountMap = {
      "FLIGHT": "5110",
      // Flight Ticket Costs
      "HOTEL": "5120",
      // Hotel Accommodation Costs
      "VISA": "5130",
      // Visa Processing Costs
      "TRANSFER": "5140",
      // Transfer Services Costs
      "RENTAL_CAR": "5150",
      // Car Rental Costs
      "RENT_CAR": "5150",
      // Car Rental Costs (alias)
      "CRUISE": "5160",
      // Cruise Booking Costs
      "TRAIN": "5170",
      // Train Tickets Costs
      "ACTIVITY": "5180",
      // Activity Booking Costs
      "PACKAGE": "5160",
      // Tourism Package Costs (same as cruise)
      "UMRAH": "5180"
      // Other Services Costs
    };
    return costAccountMap[serviceType] || "5180";
  }
  /**
   * Create journal entry for booking creation - COST ONLY
   * Records cost with supplier
   * Handles both single and multi-supplier bookings
   * PREVENTS DUPLICATE ENTRIES
   * LINKS TO FISCAL YEAR
   */
  async createBookingJournalEntry(booking) {
    try {
      const entryDate = booking.bookingDate || /* @__PURE__ */ new Date();
      const fiscalYearId = await this.validateFiscalYear(new Date(entryDate), false);
      const existingCostEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          bookingId: booking.id,
          transactionType: "BOOKING_COST"
        }
      });
      if (existingCostEntry) {
        console.log(`\u2705 Booking ${booking.bookingNumber} already has cost entry, skipping (no duplication)`);
        return;
      }
      const isMultiSupplier = booking.booking_suppliers && booking.booking_suppliers.length > 0;
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const supplierPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2111" }
        // Accounts Payable - Suppliers
      });
      const costAccountCode = this.getCostAccountCode(booking.serviceType || "OTHER");
      const costOfSalesAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: costAccountCode }
      });
      if (!supplierPayableAccount || !costOfSalesAccount) {
        console.warn("\u26A0\uFE0F  Accounting accounts not found, skipping journal entry");
        return;
      }
      if (isMultiSupplier) {
        for (const supplier of booking.booking_suppliers) {
          const supplierEntryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
          nextNumber++;
          const costInAED = Math.round(supplier.costInAED * 100) / 100;
          const created = await import_prisma.prisma.journal_entries.create({
            data: {
              id: (0, import_crypto.randomUUID)(),
              entryNumber: supplierEntryNumber,
              date: entryDate,
              description: `\u062A\u0643\u0644\u0641\u0629 \u062D\u062C\u0632 - ${booking.bookingNumber}`,
              reference: booking.bookingNumber,
              debitAccountId: costOfSalesAccount.id,
              creditAccountId: supplierPayableAccount.id,
              amount: costInAED,
              bookingId: booking.id,
              fiscalYearId,
              transactionType: "BOOKING_COST",
              status: "DRAFT",
              createdBy: booking.createdById,
              updatedAt: /* @__PURE__ */ new Date()
            }
          });
          await this.postJournalEntry(created.id);
          console.log(`\u2705 Created booking cost journal entry for supplier: ${supplierEntryNumber} (FY: ${fiscalYearId || "N/A"})`);
        }
      } else {
        const costInAED = Math.round(booking.costInAED * 100) / 100;
        const created = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: entryDate,
            description: `\u062A\u0643\u0644\u0641\u0629 \u062D\u062C\u0632 - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: costOfSalesAccount.id,
            creditAccountId: supplierPayableAccount.id,
            amount: costInAED,
            bookingId: booking.id,
            fiscalYearId,
            transactionType: "BOOKING_COST",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(created.id);
        console.log(`\u2705 Created booking cost journal entry: ${entryNumber}`);
      }
    } catch (error) {
      console.error("\u274C Error creating booking journal entry:", error.message);
    }
  }
  /**
   * Create journal entry for booking revenue with customer
   * Records accounts receivable and revenue
   * This is called at booking creation, not at invoice generation
   * PREVENTS DUPLICATE ENTRIES
   * LINKS TO FISCAL YEAR
   */
  async createBookingRevenueJournalEntry(booking) {
    try {
      const entryDate = booking.bookingDate || /* @__PURE__ */ new Date();
      const fiscalYearId = await this.validateFiscalYear(new Date(entryDate), false);
      const existingRevenueEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          bookingId: booking.id,
          transactionType: "BOOKING_REVENUE"
        }
      });
      if (existingRevenueEntry) {
        console.log(`\u2705 Booking ${booking.bookingNumber} already has revenue entry, skipping (no duplication)`);
        return;
      }
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const accountsReceivableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "1121" }
        // Customers - Trade Receivables
      });
      const revenueCode = this.getRevenueAccountCode(booking.serviceType || "OTHER");
      const revenueAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: revenueCode }
      });
      if (!accountsReceivableAccount || !revenueAccount) {
        console.warn("\u26A0\uFE0F  Accounting accounts not found, skipping revenue journal entry");
        return;
      }
      const subtotal = Math.round((booking.netBeforeVAT || 0) * 100) / 100;
      if (subtotal <= 0) {
        console.warn("\u26A0\uFE0F  Booking subtotal is zero or negative, skipping revenue entry");
        return;
      }
      const revenueEntry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          date: entryDate,
          description: `\u0625\u064A\u0631\u0627\u062F \u062D\u062C\u0632 - ${booking.bookingNumber}`,
          reference: booking.bookingNumber,
          debitAccountId: accountsReceivableAccount.id,
          creditAccountId: revenueAccount.id,
          amount: subtotal,
          bookingId: booking.id,
          fiscalYearId,
          transactionType: "BOOKING_REVENUE",
          status: "DRAFT",
          createdBy: booking.createdById,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      await this.postJournalEntry(revenueEntry.id);
      console.log(`\u2705 Created booking revenue journal entry: ${entryNumber} (FY: ${fiscalYearId || "N/A"})`);
    } catch (error) {
      console.error("\u274C Error creating booking revenue journal entry:", error.message);
    }
  }
  /**
   * Create journal entry for booking VAT
   * Records VAT payable
   * This is called at booking creation, not at invoice generation
   * PREVENTS DUPLICATE ENTRIES
   * LINKS TO FISCAL YEAR
   */
  async createBookingVATJournalEntry(booking) {
    try {
      const vatAmount = Math.round((booking.vatAmount || 0) * 100) / 100;
      if (vatAmount <= 0) {
        return;
      }
      const entryDate = booking.bookingDate || /* @__PURE__ */ new Date();
      const fiscalYearId = await this.validateFiscalYear(new Date(entryDate), false);
      const existingVATEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          bookingId: booking.id,
          transactionType: { in: ["BOOKING_VAT_UAE", "BOOKING_VAT_NON_UAE"] }
        }
      });
      if (existingVATEntry) {
        console.log(`\u2705 Booking ${booking.bookingNumber} already has VAT entry, skipping (no duplication)`);
        return;
      }
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const accountsReceivableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "1121" }
        // Customers - Trade Receivables
      });
      const vatPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2121" }
        // VAT Payable
      });
      if (!accountsReceivableAccount || !vatPayableAccount) {
        console.warn("\u26A0\uFE0F  Accounting accounts not found, skipping VAT journal entry");
        return;
      }
      const isUAEBooking = booking.isUAEBooking || false;
      const description = `\u0636\u0631\u064A\u0628\u0629 \u0642\u064A\u0645\u0629 \u0645\u0636\u0627\u0641\u0629 - ${booking.bookingNumber}`;
      const vatEntry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          date: entryDate,
          description,
          reference: booking.bookingNumber,
          debitAccountId: accountsReceivableAccount.id,
          creditAccountId: vatPayableAccount.id,
          amount: vatAmount,
          bookingId: booking.id,
          fiscalYearId,
          transactionType: isUAEBooking ? "BOOKING_VAT_UAE" : "BOOKING_VAT_NON_UAE",
          status: "DRAFT",
          createdBy: booking.createdById,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      await this.postJournalEntry(vatEntry.id);
      console.log(`\u2705 Created booking VAT journal entry: ${entryNumber}`);
    } catch (error) {
      console.error("\u274C Error creating booking VAT journal entry:", error.message);
    }
  }
  /**
   * Create journal entry for invoice generation
   * DEPRECATED: Revenue and VAT are now recorded at booking creation
   * This method is kept for backward compatibility with old invoices
   * that don't have associated booking journal entries
   * PREVENTS DUPLICATE ENTRIES
   */
  async createInvoiceJournalEntry(invoice) {
    try {
      if (invoice.bookingId) {
        const existingRevenueEntry = await import_prisma.prisma.journal_entries.findFirst({
          where: {
            bookingId: invoice.bookingId,
            transactionType: "BOOKING_REVENUE"
          }
        });
        if (existingRevenueEntry) {
          console.log("\u2705 Booking already has revenue entry, skipping invoice journal entries (no duplication)");
          return;
        }
      }
      const existingInvoiceEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          invoiceId: invoice.id,
          transactionType: { in: ["INVOICE_REVENUE", "INVOICE_VAT_UAE", "INVOICE_VAT_NON_UAE"] }
        }
      });
      if (existingInvoiceEntry) {
        console.log("\u2705 Invoice already has journal entries, skipping (no duplication)");
        return;
      }
      console.warn("\u26A0\uFE0F  Creating invoice journal entries (legacy mode - booking has no entries)");
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const accountsReceivableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "1121" }
        // Customers - Trade Receivables
      });
      const revenueCode = this.getRevenueAccountCode(invoice.bookings?.serviceType || "OTHER");
      const revenueAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: revenueCode }
      });
      if (!accountsReceivableAccount || !revenueAccount) {
        console.warn("\u26A0\uFE0F  Accounting accounts not found, skipping journal entry");
        return;
      }
      const subtotal = Math.round(invoice.subtotal * 100) / 100;
      const vatAmount = Math.round((invoice.vatAmount || 0) * 100) / 100;
      const totalAmount = Math.round(invoice.totalAmount * 100) / 100;
      const revenueEntry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          date: invoice.invoiceDate || /* @__PURE__ */ new Date(),
          description: `\u0625\u064A\u0631\u0627\u062F \u0641\u0627\u062A\u0648\u0631\u0629 - ${invoice.invoiceNumber}`,
          reference: invoice.invoiceNumber,
          debitAccountId: accountsReceivableAccount.id,
          creditAccountId: revenueAccount.id,
          amount: subtotal,
          invoiceId: invoice.id,
          transactionType: "INVOICE_REVENUE",
          status: "DRAFT",
          createdBy: invoice.createdById,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      await this.postJournalEntry(revenueEntry.id);
      if (vatAmount > 0) {
        const vatPayableAccount = await import_prisma.prisma.accounts.findFirst({
          where: { code: "2121" }
          // VAT Payable
        });
        if (vatPayableAccount) {
          const vatEntryNumber = `JE-${String(nextNumber + 1).padStart(6, "0")}`;
          const isUAEBooking = invoice.bookings?.isUAEBooking || false;
          const description = `\u0636\u0631\u064A\u0628\u0629 \u0642\u064A\u0645\u0629 \u0645\u0636\u0627\u0641\u0629 - ${invoice.invoiceNumber}`;
          const vatEntry = await import_prisma.prisma.journal_entries.create({
            data: {
              id: (0, import_crypto.randomUUID)(),
              entryNumber: vatEntryNumber,
              date: invoice.invoiceDate || /* @__PURE__ */ new Date(),
              description,
              reference: invoice.invoiceNumber,
              debitAccountId: accountsReceivableAccount.id,
              creditAccountId: vatPayableAccount.id,
              amount: vatAmount,
              invoiceId: invoice.id,
              transactionType: isUAEBooking ? "INVOICE_VAT_UAE" : "INVOICE_VAT_NON_UAE",
              status: "DRAFT",
              createdBy: invoice.createdById,
              updatedAt: /* @__PURE__ */ new Date()
            }
          });
          await this.postJournalEntry(vatEntry.id);
        }
      }
      console.log(`\u2705 Created invoice journal entries (legacy mode): ${entryNumber}`);
    } catch (error) {
      console.error("\u274C Error creating invoice journal entry:", error.message);
    }
  }
  /**
   * Create journal entry for payment received
   * Records cash/bank and reduces accounts receivable
   * PREVENTS DUPLICATE ENTRIES
   * LINKS TO FISCAL YEAR
   */
  async createReceiptJournalEntry(receipt) {
    try {
      const entryDate = receipt.receiptDate || /* @__PURE__ */ new Date();
      const fiscalYearId = await this.validateFiscalYear(new Date(entryDate), false);
      const existingReceiptEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          reference: receipt.receiptNumber,
          transactionType: "RECEIPT_PAYMENT"
        }
      });
      if (existingReceiptEntry) {
        console.log(`\u2705 Receipt ${receipt.receiptNumber} already has journal entry, skipping (no duplication)`);
        return;
      }
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      let cashAccount = null;
      if (receipt.paymentMethod === "CASH") {
        cashAccount = await import_prisma.prisma.accounts.findFirst({
          where: { code: "1111" }
          // Cash on Hand - AED
        });
      } else if (receipt.bankAccountId) {
        const bankAccount = await import_prisma.prisma.bank_accounts.findUnique({
          where: { id: receipt.bankAccountId }
        });
        if (bankAccount) {
          let bankCode = "1114";
          if (bankAccount.currency === "USD") {
            bankCode = "1115";
          }
          cashAccount = await import_prisma.prisma.accounts.findFirst({
            where: { code: bankCode }
          });
        }
      }
      if (!cashAccount) {
        cashAccount = await import_prisma.prisma.accounts.findFirst({
          where: { code: "1114" }
          // Bank Account - Main AED
        });
      }
      const accountsReceivableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "1121" }
        // Customers - Trade Receivables
      });
      if (!cashAccount || !accountsReceivableAccount) {
        console.warn("\u26A0\uFE0F  Accounting accounts not found, skipping journal entry");
        return;
      }
      const amount = Math.round(receipt.amount * 100) / 100;
      const receiptEntry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          date: entryDate,
          description: `\u0633\u062F\u0627\u062F - ${receipt.receiptNumber}`,
          reference: receipt.receiptNumber,
          debitAccountId: cashAccount.id,
          creditAccountId: accountsReceivableAccount.id,
          amount,
          fiscalYearId,
          transactionType: "RECEIPT_PAYMENT",
          status: "DRAFT",
          createdBy: receipt.createdById,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      await this.postJournalEntry(receiptEntry.id);
      console.log(`\u2705 Created receipt journal entry: ${entryNumber}`);
    } catch (error) {
      console.error("\u274C Error creating receipt journal entry:", error.message);
    }
  }
  /**
   * Create journal entry for commission payment
   * Records commission expense and payable to employee
   * PREVENTS DUPLICATE ENTRIES
   * LINKS TO FISCAL YEAR
   */
  async createCommissionJournalEntry(booking, employeeType) {
    try {
      const amount = employeeType === "AGENT" ? booking.agentCommissionAmount : booking.csCommissionAmount;
      if (!amount || amount === 0) {
        return;
      }
      const entryDate = booking.bookingDate || /* @__PURE__ */ new Date();
      const fiscalYearId = await this.validateFiscalYear(new Date(entryDate), false);
      const transactionType = `COMMISSION_${employeeType}`;
      const existingCommissionEntry = await import_prisma.prisma.journal_entries.findFirst({
        where: {
          bookingId: booking.id,
          transactionType
        }
      });
      if (existingCommissionEntry) {
        console.log(`\u2705 Booking ${booking.bookingNumber} already has ${employeeType} commission entry, skipping (no duplication)`);
        return;
      }
      const commissionAmount = Math.round(amount * 100) / 100;
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
      const commissionExpenseAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "6120" }
        // Employee Commissions
      });
      const accountsPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2132" }
        // Commissions Payable
      });
      if (!commissionExpenseAccount || !accountsPayableAccount) {
        console.warn(`\u26A0\uFE0F  Accounting accounts not found (6120 or 2132), skipping journal entry`);
        return;
      }
      const employeeLabel = employeeType === "AGENT" ? "\u0639\u0645\u0648\u0644\u0629 \u0645\u0648\u0638\u0641 \u062D\u062C\u0632" : "\u0639\u0645\u0648\u0644\u0629 \u062E\u062F\u0645\u0629 \u0639\u0645\u0644\u0627\u0621";
      const commissionEntry = await import_prisma.prisma.journal_entries.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          entryNumber,
          date: entryDate,
          description: `${employeeLabel} - ${booking.bookingNumber}`,
          reference: booking.bookingNumber,
          debitAccountId: commissionExpenseAccount.id,
          creditAccountId: accountsPayableAccount.id,
          amount: commissionAmount,
          bookingId: booking.id,
          fiscalYearId,
          transactionType: `COMMISSION_${employeeType}`,
          status: "DRAFT",
          createdBy: booking.createdById,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      await this.postJournalEntry(commissionEntry.id);
      console.log(`\u2705 Created commission journal entry (${employeeLabel}): ${entryNumber}`);
    } catch (error) {
      console.error("\u274C Error creating commission journal entry:", error.message);
    }
  }
  /**
   * Post journal entry - update account balances
   * All amounts are rounded to 2 decimal places
   * Prevents duplicate posting
   */
  async postJournalEntry(entryId) {
    try {
      const entry = await import_prisma.prisma.journal_entries.findUnique({
        where: { id: entryId }
      });
      if (!entry) {
        throw new Error("Journal entry not found");
      }
      if (entry.status === "POSTED") {
        console.warn(`\u26A0\uFE0F  Journal entry ${entry.entryNumber} is already posted, skipping...`);
        return;
      }
      const amount = Math.round(entry.amount * 100) / 100;
      const [debitAccount, creditAccount] = await Promise.all([
        import_prisma.prisma.accounts.findUnique({ where: { id: entry.debitAccountId } }),
        import_prisma.prisma.accounts.findUnique({ where: { id: entry.creditAccountId } })
      ]);
      if (!debitAccount || !creditAccount) {
        throw new Error("Related accounts not found for journal entry");
      }
      const isDebitPositiveType = debitAccount.type === "ASSET" || debitAccount.type === "EXPENSE";
      const isCreditPositiveType = creditAccount.type === "LIABILITY" || creditAccount.type === "EQUITY" || creditAccount.type === "REVENUE";
      const debitBalanceDelta = isDebitPositiveType ? amount : -amount;
      const creditBalanceDelta = isCreditPositiveType ? amount : -amount;
      await import_prisma.prisma.$transaction([
        // Update debit account
        import_prisma.prisma.accounts.update({
          where: { id: entry.debitAccountId },
          data: {
            debitBalance: { increment: amount },
            balance: { increment: debitBalanceDelta },
            updatedAt: /* @__PURE__ */ new Date()
          }
        }),
        // Update credit account
        import_prisma.prisma.accounts.update({
          where: { id: entry.creditAccountId },
          data: {
            creditBalance: { increment: amount },
            balance: { increment: creditBalanceDelta },
            updatedAt: /* @__PURE__ */ new Date()
          }
        }),
        // Mark entry as posted
        import_prisma.prisma.journal_entries.update({
          where: { id: entryId },
          data: {
            status: "POSTED",
            postedDate: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          }
        })
      ]);
      console.log(`\u2705 Posted journal entry: ${entry.entryNumber}`);
      await this.updateParentAccountBalances(entry.debitAccountId);
      await this.updateParentAccountBalances(entry.creditAccountId);
    } catch (error) {
      console.error("\u274C Error posting journal entry:", error.message);
      throw error;
    }
  }
  /**
   * Update parent account balances recursively
   * This updates all parent accounts including root accounts (1000, 2000, etc)
   * Ensures correct balance calculation based on account type
   */
  async updateParentAccountBalances(accountId) {
    try {
      const account = await import_prisma.prisma.accounts.findUnique({
        where: { id: accountId }
      });
      if (!account) {
        return;
      }
      if (!account.parentId) {
        const children = await import_prisma.prisma.accounts.findMany({
          where: { parentId: account.id }
        });
        if (children.length > 0) {
          await this.updateAccountFromChildren(account.id);
        }
        return;
      }
      const parent = await import_prisma.prisma.accounts.findUnique({
        where: { id: account.parentId }
      });
      if (!parent) return;
      await this.updateAccountFromChildren(parent.id);
      await this.updateParentAccountBalances(parent.id);
    } catch (error) {
      console.error("\u274C Error updating parent account balances:", error.message);
    }
  }
  /**
   * Update an account's balances from its direct children
   * Calculates balance correctly based on account type:
   * - Assets & Expenses: Debit increases balance
   * - Liabilities, Equity & Revenue: Credit increases balance
   */
  async updateAccountFromChildren(accountId) {
    try {
      const account = await import_prisma.prisma.accounts.findUnique({
        where: { id: accountId }
      });
      if (!account) return;
      const children = await import_prisma.prisma.accounts.findMany({
        where: { parentId: accountId }
      });
      if (children.length === 0) return;
      const totalDebit = children.reduce((sum, child) => sum + Number(child.debitBalance || 0), 0);
      const totalCredit = children.reduce((sum, child) => sum + Number(child.creditBalance || 0), 0);
      let balance = 0;
      if (account.type === "ASSET" || account.type === "EXPENSE") {
        balance = totalDebit - totalCredit;
      } else {
        balance = totalCredit - totalDebit;
      }
      const roundedDebit = Math.round(totalDebit * 100) / 100;
      const roundedCredit = Math.round(totalCredit * 100) / 100;
      const roundedBalance = Math.round(balance * 100) / 100;
      await import_prisma.prisma.accounts.update({
        where: { id: accountId },
        data: {
          debitBalance: roundedDebit,
          creditBalance: roundedCredit,
          balance: roundedBalance,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    } catch (error) {
      console.error("\u274C Error updating account from children:", error.message);
    }
  }
  /**
   * Update journal entries for booking changes
   * Deletes old entries and creates new ones with updated amounts
   */
  async updateBookingJournalEntries(bookingId) {
    try {
      console.log("\n\u{1F504} Updating journal entries for booking...");
      const booking = await import_prisma.prisma.bookings.findUnique({
        where: { id: bookingId },
        include: {
          suppliers: true,
          customers: true,
          users: true,
          booking_suppliers: {
            include: {
              suppliers: true
            }
          }
        }
      });
      if (!booking) {
        console.warn("\u26A0\uFE0F  Booking not found, cannot update journal entries");
        return;
      }
      console.log("\u{1F5D1}\uFE0F  Deleting old booking journal entries...");
      const deletedEntries = await import_prisma.prisma.journal_entries.deleteMany({
        where: {
          bookingId,
          transactionType: {
            in: ["BOOKING_COST", "BOOKING_REVENUE", "BOOKING_VAT_UAE", "BOOKING_VAT_NON_UAE", "COMMISSION_AGENT", "COMMISSION_CS"]
          }
        }
      });
      console.log(`   Deleted ${deletedEntries.count} old booking entries`);
      console.log("\u{1F4DD} Creating new booking journal entries...");
      await this.createBookingJournalEntry(booking);
      await this.createBookingRevenueJournalEntry(booking);
      await this.createBookingVATJournalEntry(booking);
      if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
        await this.createCommissionJournalEntry(booking, "AGENT");
      }
      if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
        await this.createCommissionJournalEntry(booking, "CS");
      }
      console.log("\u2705 Booking journal entries updated successfully");
    } catch (error) {
      console.error("\u274C Error updating booking journal entries:", error.message);
    }
  }
  /**
   * Create reverse journal entries for refunded booking
   * Reverses all original entries (revenue, cost, commissions)
   */
  async createRefundJournalEntries(booking) {
    try {
      const lastEntry = await import_prisma.prisma.journal_entries.findFirst({
        orderBy: { createdAt: "desc" }
      });
      let nextNumber = 1;
      if (lastEntry && lastEntry.entryNumber) {
        const match = lastEntry.entryNumber.match(/JE-(\d+)/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
      const accountsReceivableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "1121" }
        // Customers - Trade Receivables
      });
      const supplierPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2111" }
        // Suppliers - Trade Payables
      });
      const vatPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2121" }
        // VAT Payable
      });
      const commissionPayableAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "2132" }
        // Commissions Payable
      });
      const commissionExpenseAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: "6120" }
        // Commission Expense
      });
      const revenueCode = this.getRevenueAccountCode(booking.serviceType || "OTHER");
      const revenueAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: revenueCode }
      });
      const costCode = this.getCostAccountCode(booking.serviceType || "OTHER");
      const costAccount = await import_prisma.prisma.accounts.findFirst({
        where: { code: costCode }
      });
      if (!accountsReceivableAccount || !revenueAccount || !costAccount || !supplierPayableAccount) {
        console.warn("\u26A0\uFE0F  Required accounting accounts not found, skipping refund entries");
        return;
      }
      if (booking.netBeforeVAT && booking.netBeforeVAT > 0) {
        const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
        nextNumber++;
        const entry = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: booking.updatedAt || /* @__PURE__ */ new Date(),
            description: `\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0625\u064A\u0631\u0627\u062F - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: revenueAccount.id,
            creditAccountId: accountsReceivableAccount.id,
            amount: Math.round(booking.netBeforeVAT * 100) / 100,
            bookingId: booking.id,
            transactionType: "REFUND_REVENUE",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(entry.id);
        console.log(`\u2705 Created refund revenue entry: ${entryNumber}`);
      }
      if (booking.vatAmount && booking.vatAmount > 0 && vatPayableAccount) {
        const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
        nextNumber++;
        const entry = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: booking.updatedAt || /* @__PURE__ */ new Date(),
            description: `\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0636\u0631\u064A\u0628\u0629 - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: vatPayableAccount.id,
            creditAccountId: accountsReceivableAccount.id,
            amount: Math.round(booking.vatAmount * 100) / 100,
            bookingId: booking.id,
            transactionType: "REFUND_VAT",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(entry.id);
        console.log(`\u2705 Created refund VAT entry: ${entryNumber}`);
      }
      if (booking.costInAED && booking.costInAED > 0) {
        const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
        nextNumber++;
        const entry = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: booking.updatedAt || /* @__PURE__ */ new Date(),
            description: `\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u062A\u0643\u0644\u0641\u0629 - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: supplierPayableAccount.id,
            creditAccountId: costAccount.id,
            amount: Math.round(booking.costInAED * 100) / 100,
            bookingId: booking.id,
            transactionType: "REFUND_COST",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(entry.id);
        console.log(`\u2705 Created refund cost entry: ${entryNumber}`);
      }
      if (booking.agentCommissionAmount && Math.abs(booking.agentCommissionAmount) > 0 && commissionPayableAccount && commissionExpenseAccount) {
        const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
        nextNumber++;
        const commAmount = Math.abs(booking.agentCommissionAmount);
        const entry = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: booking.updatedAt || /* @__PURE__ */ new Date(),
            description: `\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0639\u0645\u0648\u0644\u0629 \u0645\u0648\u0638\u0641 \u062D\u062C\u0632 - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: commissionPayableAccount.id,
            creditAccountId: commissionExpenseAccount.id,
            amount: Math.round(commAmount * 100) / 100,
            bookingId: booking.id,
            transactionType: "REFUND_COMMISSION_AGENT",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(entry.id);
        console.log(`\u2705 Created refund agent commission entry: ${entryNumber}`);
      }
      if (booking.csCommissionAmount && booking.csCommissionAmount > 0 && commissionPayableAccount && commissionExpenseAccount) {
        const entryNumber = `JE-${String(nextNumber).padStart(6, "0")}`;
        nextNumber++;
        const entry = await import_prisma.prisma.journal_entries.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            entryNumber,
            date: booking.updatedAt || /* @__PURE__ */ new Date(),
            description: `\u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0639\u0645\u0648\u0644\u0629 \u062E\u062F\u0645\u0629 \u0639\u0645\u0644\u0627\u0621 - ${booking.bookingNumber}`,
            reference: booking.bookingNumber,
            debitAccountId: commissionPayableAccount.id,
            creditAccountId: commissionExpenseAccount.id,
            amount: Math.round(booking.csCommissionAmount * 100) / 100,
            bookingId: booking.id,
            transactionType: "REFUND_COMMISSION_CS",
            status: "DRAFT",
            createdBy: booking.createdById,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        await this.postJournalEntry(entry.id);
        console.log(`\u2705 Created refund CS commission entry: ${entryNumber}`);
      }
      console.log(`\u2705 All refund journal entries created for ${booking.bookingNumber}`);
    } catch (error) {
      console.error("\u274C Error creating refund journal entries:", error.message);
      throw error;
    }
  }
}
const accountingService = new AccountingService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AccountingService,
  accountingService
});
