"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var invoiceService_exports = {};
__export(invoiceService_exports, {
  InvoiceService: () => InvoiceService,
  invoiceService: () => invoiceService
});
module.exports = __toCommonJS(invoiceService_exports);
var import_crypto = require("crypto");
var import_calculations = require("../utils/calculations");
var import_accountingService = require("./accountingService");
var import_prisma = require("../lib/prisma");
class InvoiceService {
  /**
   * Create invoice from booking
   */
  async createInvoice(input) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: input.bookingId },
      include: { customers: true }
    });
    if (!booking) {
      throw new Error("Booking not found");
    }
    const existing = await import_prisma.prisma.invoices.findUnique({
      where: { bookingId: input.bookingId }
    });
    if (existing) {
      throw new Error("Invoice already exists for this booking");
    }
    const lastInvoice = await import_prisma.prisma.invoices.findFirst({
      orderBy: { createdAt: "desc" }
    });
    const settings = await import_prisma.prisma.company_settings.findFirst();
    const prefix = settings?.invoicePrefix || "INV";
    const nextSequence = lastInvoice ? parseInt(lastInvoice.invoiceNumber.split("-").pop() || "0") + 1 : 1;
    const invoiceNumber = (0, import_calculations.generateInvoiceNumber)(prefix, nextSequence);
    let invoiceSubtotal;
    let invoiceVAT;
    let invoiceTotal;
    invoiceVAT = booking.vatAmount || 0;
    invoiceSubtotal = booking.saleInAED - invoiceVAT;
    invoiceTotal = booking.saleInAED;
    const invoice = await import_prisma.prisma.invoices.create({
      data: {
        id: (0, import_crypto.randomUUID)(),
        invoiceNumber,
        bookingId: input.bookingId,
        customerId: booking.customerId,
        subtotal: invoiceSubtotal,
        vatAmount: invoiceVAT,
        totalAmount: invoiceTotal,
        currency: "AED",
        // ALWAYS AED
        dueDate: input.dueDate,
        notes: input.notes,
        termsConditions: input.termsConditions || settings?.invoiceTerms || void 0,
        createdById: input.createdById,
        status: "UNPAID",
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        bookings: {
          include: {
            suppliers: true
          }
        },
        customers: true,
        users: true
      }
    });
    const currentBooking = await import_prisma.prisma.bookings.findUnique({
      where: { id: input.bookingId },
      select: { status: true }
    });
    if (currentBooking && currentBooking.status !== "CONFIRMED") {
      await import_prisma.prisma.bookings.update({
        where: { id: input.bookingId },
        data: {
          status: "CONFIRMED",
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    await import_accountingService.accountingService.createInvoiceJournalEntry(invoice);
    return invoice;
  }
  /**
   * Get invoice by ID
   */
  async getInvoiceById(id) {
    return await import_prisma.prisma.invoices.findUnique({
      where: { id },
      include: {
        bookings: {
          include: {
            suppliers: true,
            customers: true
          }
        },
        customers: true,
        users: true
      }
    });
  }
  /**
   * Get invoice by booking ID
   */
  async getInvoiceByBooking(bookingId) {
    return await import_prisma.prisma.invoices.findUnique({
      where: { bookingId },
      include: {
        bookings: {
          include: {
            suppliers: true,
            customers: true
          }
        },
        customers: true,
        users: true
      }
    });
  }
  /**
   * Get all invoices with filters
   * OPTIMIZED: Two queries instead of N+1 queries
   */
  async getInvoices(filters) {
    const invoices2 = await import_prisma.prisma.invoices.findMany({
      where: {
        ...filters.status && { status: filters.status },
        ...filters.customerId && { customerId: filters.customerId },
        ...filters.startDate && filters.endDate && {
          invoiceDate: {
            gte: filters.startDate,
            lte: filters.endDate
          }
        }
      },
      include: {
        customers: true,
        bookings: {
          include: {
            customers: true,
            suppliers: true
          }
        },
        users: true
      },
      orderBy: {
        invoiceDate: "desc"
      }
    });
    const invoiceIds = invoices2.map((inv) => inv.id);
    const allReceipts = await import_prisma.prisma.receipts.findMany({
      where: {
        invoiceId: { in: invoiceIds },
        status: { not: "CANCELLED" }
      },
      select: {
        id: true,
        receiptNumber: true,
        amount: true,
        receiptDate: true,
        status: true,
        invoiceId: true
      }
    });
    const receiptsByInvoice = {};
    for (const receipt of allReceipts) {
      if (receipt.invoiceId) {
        if (!receiptsByInvoice[receipt.invoiceId]) {
          receiptsByInvoice[receipt.invoiceId] = [];
        }
        receiptsByInvoice[receipt.invoiceId].push(receipt);
      }
    }
    const invoicesWithPaidAmount = invoices2.map((invoice) => {
      const receipts = receiptsByInvoice[invoice.id] || [];
      const paidAmount = receipts.reduce((sum, receipt) => sum + receipt.amount, 0);
      return {
        ...invoice,
        paidAmount,
        receipts
      };
    });
    return invoicesWithPaidAmount;
  }
  /**
   * Update invoice status
   */
  async updateInvoiceStatus(id, status, paidDate) {
    return await import_prisma.prisma.invoices.update({
      where: { id },
      data: {
        status,
        ...status === "PAID" && paidDate && { paidDate },
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  /**
   * Update invoice
   */
  async updateInvoice(id, data) {
    return await import_prisma.prisma.invoices.update({
      where: { id },
      data: {
        ...data,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  /**
   * Update invoice from booking changes
   * Recalculates invoice amounts based on updated booking data
   * and updates journal entries
   */
  async updateInvoiceFromBooking(invoiceId, booking) {
    console.log(`\u{1F504} Updating invoice ${invoiceId} from booking changes...`);
    let invoiceSubtotal;
    let invoiceVAT;
    let invoiceTotal;
    invoiceVAT = booking.vatAmount || 0;
    invoiceSubtotal = booking.saleInAED - invoiceVAT;
    invoiceTotal = booking.saleInAED;
    console.log("\u{1F4CA} Invoice amounts calculated:", {
      serviceType: booking.serviceType,
      saleInAED: booking.saleInAED,
      vatAmount: booking.vatAmount,
      invoiceSubtotal,
      invoiceVAT,
      invoiceTotal
    });
    const updatedInvoice = await import_prisma.prisma.invoices.update({
      where: { id: invoiceId },
      data: {
        subtotal: invoiceSubtotal,
        vatAmount: invoiceVAT,
        totalAmount: invoiceTotal,
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        bookings: {
          include: {
            suppliers: true
          }
        },
        customers: true,
        users: true
      }
    });
    console.log("\u{1F5D1}\uFE0F Deleting old invoice journal entries...");
    const deletedEntries = await import_prisma.prisma.journal_entries.deleteMany({
      where: { invoiceId }
    });
    console.log(`   Deleted ${deletedEntries.count} old entries`);
    console.log("\u{1F4DD} Creating new invoice journal entries...");
    await import_accountingService.accountingService.createInvoiceJournalEntry(updatedInvoice);
    console.log("\u2705 Invoice and journal entries updated successfully");
    return updatedInvoice;
  }
  /**
   * Delete invoice
   */
  async deleteInvoice(id) {
    const invoice = await import_prisma.prisma.invoices.findUnique({
      where: { id }
    });
    if (invoice) {
      await import_prisma.prisma.bookings.update({
        where: { id: invoice.bookingId },
        data: {
          status: "CONFIRMED",
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    return await import_prisma.prisma.invoices.delete({
      where: { id }
    });
  }
}
const invoiceService = new InvoiceService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  InvoiceService,
  invoiceService
});
