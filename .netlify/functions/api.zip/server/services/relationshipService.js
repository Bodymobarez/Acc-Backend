"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var relationshipService_exports = {};
__export(relationshipService_exports, {
  RelationshipService: () => RelationshipService,
  relationshipService: () => relationshipService
});
module.exports = __toCommonJS(relationshipService_exports);
var import_prisma = require("../lib/prisma");
class RelationshipService {
  /**
   * Verify booking can generate invoice
   * Returns validation result and any issues
   */
  async verifyBookingToInvoiceRelationship(bookingId) {
    const issues = [];
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId },
      include: {
        customers: true,
        suppliers: true,
        users: true,
        invoices: true
      }
    });
    if (!booking) {
      return {
        valid: false,
        booking: null,
        existingInvoice: null,
        canCreateInvoice: false,
        issues: ["Booking not found"]
      };
    }
    const existingInvoice = booking.invoices;
    if (existingInvoice) {
      issues.push(`Invoice already exists: ${existingInvoice.invoiceNumber}`);
    }
    if (!booking.customerId) {
      issues.push("Booking missing customer");
    }
    if (!booking.saleInAED || booking.saleInAED <= 0) {
      issues.push("Booking has invalid sale amount");
    }
    return {
      valid: issues.length === 0,
      booking,
      existingInvoice: existingInvoice || null,
      canCreateInvoice: !existingInvoice && issues.length === 0,
      issues
    };
  }
  /**
   * Verify invoice can receive payments
   * Returns validation result and payment status
   */
  async verifyInvoiceToReceiptRelationship(invoiceId) {
    const issues = [];
    const invoice = await import_prisma.prisma.invoices.findUnique({
      where: { id: invoiceId },
      include: {
        bookings: {
          include: {
            customers: true,
            suppliers: true
          }
        },
        customers: true,
        users: true
      }
    });
    if (!invoice) {
      return {
        valid: false,
        invoice: null,
        receipts: [],
        totalPaid: 0,
        remainingAmount: 0,
        status: "NOT_FOUND",
        issues: ["Invoice not found"]
      };
    }
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: {
        invoiceId,
        status: { not: "CANCELLED" }
      },
      include: {
        customers: true
      }
    });
    const totalPaid = receipts.reduce((sum, receipt) => sum + receipt.amount, 0);
    const remainingAmount = invoice.totalAmount - totalPaid;
    let status = "UNPAID";
    const epsilon = 0.01;
    if (Math.abs(remainingAmount) < epsilon || totalPaid >= invoice.totalAmount) {
      status = "PAID";
    } else if (totalPaid > 0) {
      status = "PARTIALLY_PAID";
    }
    if (invoice.status !== status) {
      issues.push(`Invoice status mismatch: DB says ${invoice.status}, calculated ${status}`);
    }
    return {
      valid: issues.length === 0,
      invoice,
      receipts,
      totalPaid,
      remainingAmount,
      status,
      issues
    };
  }
  /**
   * Verify receipt matching to invoice
   * Ensures receipt-invoice relationship is correct
   */
  async verifyReceiptMatching(receiptId) {
    const issues = [];
    const receipt = await import_prisma.prisma.receipts.findUnique({
      where: { id: receiptId },
      include: {
        customers: true
      }
    });
    if (!receipt) {
      return {
        valid: false,
        receipt: null,
        matchedInvoice: null,
        matchingCorrect: false,
        issues: ["Receipt not found"]
      };
    }
    let matchedInvoice = null;
    let matchingCorrect = true;
    if (receipt.invoiceId) {
      matchedInvoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: receipt.invoiceId },
        include: {
          bookings: true,
          customers: true
        }
      });
      if (!matchedInvoice) {
        issues.push("Receipt linked to non-existent invoice");
        matchingCorrect = false;
      } else {
        if (matchedInvoice.customerId !== receipt.customerId) {
          issues.push("Receipt customer does not match invoice customer");
          matchingCorrect = false;
        }
        if (receipt.amount > matchedInvoice.totalAmount) {
          issues.push("Receipt amount exceeds invoice total");
        }
      }
    }
    return {
      valid: issues.length === 0,
      receipt,
      matchedInvoice,
      matchingCorrect,
      issues
    };
  }
  /**
   * Get complete transaction flow for a booking
   * Shows full relationship chain: Booking → Invoice → Receipts
   */
  async getCompleteTransactionFlow(bookingId) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId },
      include: {
        customers: true,
        suppliers: true,
        users: true,
        invoices: true,
        employees_bookings_bookingAgentIdToemployees: {
          include: { users: true }
        },
        employees_bookings_customerServiceIdToemployees: {
          include: { users: true }
        }
      }
    });
    if (!booking) {
      throw new Error("Booking not found");
    }
    const invoice = booking.invoices || null;
    let receipts = [];
    let totalPaid = 0;
    if (invoice) {
      receipts = await import_prisma.prisma.receipts.findMany({
        where: {
          invoiceId: invoice.id,
          status: { not: "CANCELLED" }
        },
        include: {
          customers: true
        },
        orderBy: {
          receiptDate: "desc"
        }
      });
      totalPaid = receipts.reduce((sum, r) => sum + r.amount, 0);
    }
    const journalEntries = await import_prisma.prisma.journal_entries.findMany({
      where: {
        OR: [
          { bookingId },
          ...invoice ? [{ invoiceId: invoice.id }] : []
        ]
      },
      include: {
        accounts_journal_entries_debitAccountIdToaccounts: true,
        accounts_journal_entries_creditAccountIdToaccounts: true
      },
      orderBy: {
        date: "asc"
      }
    });
    const bookingTotal = booking.totalWithVAT || booking.saleInAED;
    const invoiceTotal = invoice?.totalAmount || 0;
    const remainingBalance = invoiceTotal - totalPaid;
    const epsilon = 0.01;
    const fullyPaid = Math.abs(remainingBalance) < epsilon || totalPaid >= invoiceTotal;
    return {
      booking,
      invoice,
      receipts,
      journalEntries,
      status: {
        bookingStatus: booking.status,
        invoiceStatus: invoice?.status || "NO_INVOICE",
        paymentStatus: fullyPaid ? "PAID" : totalPaid > 0 ? "PARTIALLY_PAID" : "UNPAID",
        fullyPaid
      },
      financial: {
        bookingTotal,
        invoiceTotal,
        totalPaid,
        remainingBalance
      }
    };
  }
  /**
   * Synchronize invoice status with receipt payments
   * Ensures invoice status matches actual payments
   */
  async synchronizeInvoiceStatus(invoiceId) {
    const invoice = await import_prisma.prisma.invoices.findUnique({
      where: { id: invoiceId }
    });
    if (!invoice) {
      throw new Error("Invoice not found");
    }
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: {
        invoiceId,
        status: { not: "CANCELLED" }
      }
    });
    const totalPaid = receipts.reduce((sum, r) => sum + r.amount, 0);
    const epsilon = 0.01;
    const difference = invoice.totalAmount - totalPaid;
    let newStatus = "UNPAID";
    if (Math.abs(difference) < epsilon || totalPaid >= invoice.totalAmount) {
      newStatus = "PAID";
    } else if (totalPaid > 0) {
      newStatus = "PARTIALLY_PAID";
    }
    const oldStatus = invoice.status;
    const updated = oldStatus !== newStatus;
    if (updated) {
      await import_prisma.prisma.invoices.update({
        where: { id: invoiceId },
        data: {
          status: newStatus,
          ...newStatus === "PAID" && !invoice.paidDate ? { paidDate: /* @__PURE__ */ new Date() } : {}
        }
      });
    }
    return {
      updated,
      oldStatus,
      newStatus,
      totalPaid
    };
  }
}
const relationshipService = new RelationshipService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RelationshipService,
  relationshipService
});
