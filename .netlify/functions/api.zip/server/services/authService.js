"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var authService_exports = {};
__export(authService_exports, {
  AuthService: () => AuthService,
  authService: () => authService
});
module.exports = __toCommonJS(authService_exports);
var import_bcryptjs = __toESM(require("bcryptjs"));
var import_auth = require("../middleware/auth");
var import_permissions = require("../utils/permissions");
var import_activityTracker = require("../middleware/activityTracker");
var import_prisma = require("../lib/prisma");
class AuthService {
  /**
   * Login user
   */
  async login(input) {
    if (!input.username || !input.password) {
      console.error("\u274C Login failed: Missing credentials");
      throw new Error("Username and password are required");
    }
    console.log("\u{1F511} Login attempt for username:", input.username);
    const user = await import_prisma.prisma.users.findUnique({
      where: { username: input.username.toLowerCase() },
      include: {
        employees: true
      }
    });
    if (!user) {
      console.error("\u274C Login failed: User not found -", input.username);
      throw new Error("Invalid username or password");
    }
    if (!user.isActive) {
      console.error("\u274C Login failed: Account inactive -", input.username);
      throw new Error("Account is inactive");
    }
    const isPasswordValid = await import_bcryptjs.default.compare(input.password, user.password);
    if (!isPasswordValid) {
      console.error("\u274C Login failed: Invalid password -", input.username);
      throw new Error("Invalid username or password");
    }
    await import_prisma.prisma.users.update({
      where: { id: user.id },
      data: { lastLogin: /* @__PURE__ */ new Date() }
    });
    try {
      await (0, import_activityTracker.trackLogin)(user.id, user.email, "unknown", "unknown", true);
    } catch (error) {
      console.error("Failed to track login:", error);
    }
    let userPermissions;
    try {
      const permissionsString = user.permissions;
      const parsedPermissions = typeof permissionsString === "string" ? JSON.parse(permissionsString) : permissionsString;
      if (!parsedPermissions || Object.keys(parsedPermissions).length === 0) {
        console.log(`User ${user.email} has empty permissions, using defaults for role: ${user.role}`);
        userPermissions = (0, import_permissions.getDefaultPermissions)(user.role);
        await import_prisma.prisma.users.update({
          where: { id: user.id },
          data: { permissions: JSON.stringify(userPermissions) }
        });
      } else {
        userPermissions = parsedPermissions;
      }
    } catch (error) {
      console.log(`Error parsing permissions for ${user.email}, using defaults for role: ${user.role}`);
      userPermissions = (0, import_permissions.getDefaultPermissions)(user.role);
      await import_prisma.prisma.users.update({
        where: { id: user.id },
        data: { permissions: JSON.stringify(userPermissions) }
      });
    }
    const authenticatedUser = {
      id: user.id,
      email: user.email,
      role: user.role,
      permissions: userPermissions
    };
    const token = (0, import_auth.generateToken)(authenticatedUser);
    const { password: _, ...userWithoutPassword } = user;
    return {
      user: userWithoutPassword,
      token
    };
  }
  /**
   * Register new user
   */
  async register(input) {
    const existingUsername = await import_prisma.prisma.users.findUnique({
      where: { username: input.username.toLowerCase() }
    });
    if (existingUsername) {
      throw new Error("Username already registered");
    }
    const existingEmail = await import_prisma.prisma.users.findUnique({
      where: { email: input.email.toLowerCase() }
    });
    if (existingEmail) {
      throw new Error("Email already registered");
    }
    const hashedPassword = await import_bcryptjs.default.hash(input.password, 10);
    const permissions = (0, import_permissions.getDefaultPermissions)(input.role);
    const user = await import_prisma.prisma.users.create({
      data: {
        username: input.username.toLowerCase(),
        email: input.email.toLowerCase(),
        password: hashedPassword,
        firstName: input.firstName,
        lastName: input.lastName,
        role: input.role,
        permissions
      }
    });
    const authenticatedUser = {
      id: user.id,
      email: user.email,
      role: user.role,
      permissions
    };
    const token = (0, import_auth.generateToken)(authenticatedUser);
    const { password: _, ...userWithoutPassword } = user;
    return {
      user: userWithoutPassword,
      token
    };
  }
  /**
   * Get current user profile
   */
  async getProfile(userId) {
    const user = await import_prisma.prisma.users.findUnique({
      where: { id: userId },
      include: {
        employees: true
      }
    });
    if (!user) {
      throw new Error("User not found");
    }
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
  /**
   * Update user profile
   */
  async updateProfile(userId, data) {
    const user = await import_prisma.prisma.users.update({
      where: { id: userId },
      data
    });
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
  /**
   * Change password
   */
  async changePassword(userId, oldPassword, newPassword) {
    const user = await import_prisma.prisma.users.findUnique({
      where: { id: userId }
    });
    if (!user) {
      throw new Error("User not found");
    }
    const isPasswordValid = await import_bcryptjs.default.compare(oldPassword, user.password);
    if (!isPasswordValid) {
      throw new Error("Current password is incorrect");
    }
    const hashedPassword = await import_bcryptjs.default.hash(newPassword, 10);
    await import_prisma.prisma.users.update({
      where: { id: userId },
      data: { password: hashedPassword }
    });
  }
}
const authService = new AuthService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AuthService,
  authService
});
