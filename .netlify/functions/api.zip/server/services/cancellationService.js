"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cancellationService_exports = {};
__export(cancellationService_exports, {
  cancellationService: () => cancellationService
});
module.exports = __toCommonJS(cancellationService_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
var import_accountingService = require("./accountingService");
const cancellationService = {
  /**
   * Cancel booking and create refund booking
   * - Create refund booking with REFUNDED status (negative amounts)
   * - If invoice exists:
   *   - Cancel invoice
   *   - Add credit note info if invoice was PAID
   * - Change original booking status to CANCELLED
   */
  async cancelBookingWithRefund(bookingId, createdById) {
    console.log("\n\u{1F6AB} \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
    console.log("   BOOKING CANCELLATION PROCESS");
    console.log("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n");
    const originalBooking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId },
      include: {
        customers: true,
        suppliers: true,
        booking_suppliers: {
          include: {
            suppliers: true
          }
        }
      }
    });
    if (!originalBooking) {
      throw new Error("Booking not found");
    }
    if (originalBooking.status === "CANCELLED") {
      throw new Error("Booking is already cancelled");
    }
    console.log(`\u{1F4CB} Original Booking: ${originalBooking.bookingNumber}`);
    console.log(`\u{1F4B0} Sale Amount: ${originalBooking.saleInAED} AED`);
    console.log(`\u{1F4C5} Travel Date: ${originalBooking.travelDate}`);
    const invoice = await import_prisma.prisma.invoices.findFirst({
      where: { bookingId }
    });
    let creditNoteInfo = null;
    if (invoice) {
      console.log(`
\u{1F4C4} Invoice Found: ${invoice.invoiceNumber}`);
      console.log(`   Status: ${invoice.status}`);
      console.log(`   Amount: ${invoice.totalAmount} AED`);
      if (invoice.status === "PAID") {
        console.log("\n\u{1F4B3} Invoice is PAID - Credit Note info will be added");
        creditNoteInfo = {
          amount: invoice.totalAmount,
          reason: `Cancellation of booking ${originalBooking.bookingNumber}`,
          customerId: invoice.customerId,
          invoiceNumber: invoice.invoiceNumber
        };
        await import_prisma.prisma.invoices.update({
          where: { id: invoice.id },
          data: {
            status: "CANCELLED",
            notes: `${invoice.notes || ""}

\u26A0\uFE0F CREDIT NOTE: ${invoice.totalAmount} AED issued due to cancellation.
Customer credit balance: ${invoice.totalAmount} AED
Original booking: ${originalBooking.bookingNumber}`,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        console.log(`\u2705 Credit Note Info Added to Invoice`);
        console.log(`   Amount: ${invoice.totalAmount} AED`);
      } else {
        await import_prisma.prisma.invoices.update({
          where: { id: invoice.id },
          data: {
            status: "CANCELLED",
            notes: `${invoice.notes || ""}

Cancelled due to booking cancellation: ${originalBooking.bookingNumber}`,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
      }
      console.log(`\u2705 Invoice Cancelled: ${invoice.invoiceNumber}`);
    }
    console.log("\n\u{1F504} Creating Refund Booking...");
    const lastBooking = await import_prisma.prisma.bookings.findFirst({
      orderBy: { createdAt: "desc" }
    });
    const prefix = "REFUND";
    const nextSequence = lastBooking ? parseInt(lastBooking.bookingNumber.split("-").pop() || "0") + 1 : 1;
    const refundBookingNumber = `${prefix}-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(nextSequence).padStart(6, "0")}`;
    const refundBooking = await import_prisma.prisma.bookings.create({
      data: {
        id: (0, import_crypto.randomUUID)(),
        bookingNumber: refundBookingNumber,
        customerId: originalBooking.customerId,
        supplierId: originalBooking.supplierId,
        serviceType: originalBooking.serviceType,
        // Negative amounts for refund
        costAmount: -originalBooking.costAmount,
        costCurrency: originalBooking.costCurrency,
        costInAED: -originalBooking.costInAED,
        saleAmount: -originalBooking.saleAmount,
        saleCurrency: originalBooking.saleCurrency,
        saleInAED: -originalBooking.saleInAED,
        grossProfit: -originalBooking.grossProfit,
        netProfit: -originalBooking.netProfit,
        netBeforeVAT: -originalBooking.netBeforeVAT,
        vatAmount: -originalBooking.vatAmount,
        totalWithVAT: -originalBooking.totalWithVAT,
        isUAEBooking: originalBooking.isUAEBooking,
        vatApplicable: originalBooking.vatApplicable,
        // Commission (negative)
        bookingAgentId: originalBooking.bookingAgentId,
        agentCommissionRate: originalBooking.agentCommissionRate,
        agentCommissionAmount: originalBooking.agentCommissionAmount ? -originalBooking.agentCommissionAmount : 0,
        customerServiceId: originalBooking.customerServiceId,
        csCommissionRate: originalBooking.csCommissionRate,
        csCommissionAmount: originalBooking.csCommissionAmount ? -originalBooking.csCommissionAmount : 0,
        totalCommission: originalBooking.totalCommission ? -originalBooking.totalCommission : 0,
        // Service details
        serviceDetails: originalBooking.serviceDetails,
        travelDate: originalBooking.travelDate,
        returnDate: originalBooking.returnDate,
        notes: `\u{1F534} REFUND for cancelled booking ${originalBooking.bookingNumber}
${creditNoteInfo ? `
\u{1F4B3} Credit Note issued: ${creditNoteInfo.amount} AED` : ""}

Original Notes:
${originalBooking.notes || "N/A"}`,
        internalNotes: `System generated refund. Original booking: ${originalBooking.bookingNumber}${creditNoteInfo ? `
Credit note amount: ${creditNoteInfo.amount} AED` : ""}`,
        status: "REFUNDED",
        createdById,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    console.log(`\u2705 Refund Booking Created: ${refundBookingNumber}`);
    console.log(`   Sale Amount (Negative): ${refundBooking.saleInAED} AED`);
    console.log("\n\u{1F4D2} Creating Reverse Journal Entries for Refund...");
    try {
      await import_accountingService.accountingService.createRefundJournalEntries(originalBooking);
      console.log("\u2705 Reverse journal entries created successfully");
    } catch (error) {
      console.error("\u26A0\uFE0F  Failed to create reverse journal entries:", error.message);
    }
    if (originalBooking.booking_suppliers && originalBooking.booking_suppliers.length > 0) {
      console.log(`
\u{1F4E6} Creating Refund for ${originalBooking.booking_suppliers.length} Additional Suppliers...`);
      for (const supplier of originalBooking.booking_suppliers) {
        await import_prisma.prisma.booking_suppliers.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            bookingId: refundBooking.id,
            supplierId: supplier.supplierId,
            serviceType: supplier.serviceType,
            costAmount: -supplier.costAmount,
            costCurrency: supplier.costCurrency,
            costInAED: -supplier.costInAED,
            description: `\u{1F534} REFUND: ${supplier.description || ""}`,
            createdAt: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        console.log(`   \u2705 Refund supplier: ${supplier.suppliers?.companyName}`);
      }
    }
    await import_prisma.prisma.bookings.update({
      where: { id: bookingId },
      data: {
        status: "CANCELLED",
        internalNotes: `${originalBooking.internalNotes || ""}

\u{1F6AB} CANCELLED - Refund booking: ${refundBookingNumber}${creditNoteInfo ? `
Credit note: ${creditNoteInfo.amount} AED` : ""}`,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    console.log(`
\u2705 Original Booking Status Updated: CANCELLED`);
    console.log("\n\u{1F4B3} Auto-Generating Credit Note Invoice...");
    let creditNoteInvoice = null;
    if (invoice && invoice.status === "PAID") {
      try {
        const { invoiceService } = await import("./invoiceService");
        const lastInvoice = await import_prisma.prisma.invoices.findFirst({
          orderBy: { createdAt: "desc" }
        });
        const settings = await import_prisma.prisma.company_settings.findFirst();
        const prefix2 = "CN";
        const nextSequence2 = lastInvoice ? parseInt(lastInvoice.invoiceNumber.split("-").pop() || "0") + 1 : 1;
        const creditNoteNumber = `${prefix2}-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(nextSequence2).padStart(6, "0")}`;
        creditNoteInvoice = await import_prisma.prisma.invoices.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            invoiceNumber: creditNoteNumber,
            bookingId: refundBooking.id,
            customerId: refundBooking.customerId,
            subtotal: -invoice.subtotal,
            // Negative amounts
            vatAmount: -invoice.vatAmount,
            totalAmount: -invoice.totalAmount,
            currency: "AED",
            notes: `\u{1F4B3} CREDIT NOTE for cancelled invoice ${invoice.invoiceNumber}

Original Booking: ${originalBooking.bookingNumber}
Refund Amount: ${invoice.totalAmount} AED`,
            termsConditions: settings?.invoiceTerms || void 0,
            createdById,
            status: "PAID",
            // Credit note is automatically "paid" (refunded)
            paidDate: /* @__PURE__ */ new Date(),
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            bookings: {
              include: {
                suppliers: true
              }
            },
            customers: true
          }
        });
        const { accountingService: accountingService2 } = await import("./accountingService");
        await accountingService2.createInvoiceJournalEntry(creditNoteInvoice);
        console.log(`\u2705 Credit Note Invoice Created: ${creditNoteNumber}`);
        console.log(`   Amount: ${creditNoteInvoice.totalAmount} AED`);
      } catch (error) {
        console.error("\u26A0\uFE0F Failed to create credit note invoice:", error.message);
      }
    }
    console.log("\n\u{1F389} \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
    console.log("   CANCELLATION COMPLETED SUCCESSFULLY");
    console.log("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n");
    return {
      originalBooking,
      refundBooking,
      invoice,
      creditNoteInvoice,
      creditNoteInfo,
      message: "Booking cancelled successfully with refund booking and credit note created"
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cancellationService
});
