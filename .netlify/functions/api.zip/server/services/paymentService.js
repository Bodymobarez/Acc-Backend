"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var paymentService_exports = {};
__export(paymentService_exports, {
  paymentService: () => paymentService
});
module.exports = __toCommonJS(paymentService_exports);
var import_prisma = require("../lib/prisma");
const paymentService = {
  async generatePaymentNumber() {
    const lastPayment = await import_prisma.prisma.payments.findFirst({
      orderBy: { createdAt: "desc" },
      select: { paymentNumber: true }
    });
    if (!lastPayment) {
      return "PAY-2025-0001";
    }
    const lastNumber = parseInt(lastPayment.paymentNumber.split("-")[2]);
    const newNumber = lastNumber + 1;
    const year = (/* @__PURE__ */ new Date()).getFullYear();
    return `PAY-${year}-${newNumber.toString().padStart(4, "0")}`;
  },
  async create(input) {
    const paymentNumber = await this.generatePaymentNumber();
    const payment = await import_prisma.prisma.payments.create({
      data: {
        id: `payment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        paymentNumber,
        supplierId: input.supplierId,
        amount: input.amount,
        paymentMethod: input.paymentMethod,
        bankAccountId: input.bankAccountId,
        checkNumber: input.checkNumber,
        reference: input.reference,
        category: input.category,
        paymentDate: input.paymentDate || /* @__PURE__ */ new Date(),
        notes: input.notes,
        status: input.status || "COMPLETED",
        createdById: input.createdById,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        supplier: true,
        bankAccount: true,
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      }
    });
    if (input.bankAccountId && input.paymentMethod === "BANK") {
      await import_prisma.prisma.bank_accounts.update({
        where: { id: input.bankAccountId },
        data: {
          balance: {
            decrement: input.amount
          }
        }
      });
    }
    return payment;
  },
  async getAll(filters) {
    const where = {};
    if (filters) {
      if (filters.supplierId) where.supplierId = filters.supplierId;
      if (filters.category) where.category = filters.category;
      if (filters.paymentMethod) where.paymentMethod = filters.paymentMethod;
      if (filters.status) where.status = filters.status;
      if (filters.startDate || filters.endDate) {
        where.paymentDate = {};
        if (filters.startDate) where.paymentDate.gte = filters.startDate;
        if (filters.endDate) where.paymentDate.lte = filters.endDate;
      }
      if (filters.minAmount || filters.maxAmount) {
        where.amount = {};
        if (filters.minAmount) where.amount.gte = filters.minAmount;
        if (filters.maxAmount) where.amount.lte = filters.maxAmount;
      }
    }
    const payments = await import_prisma.prisma.payments.findMany({
      where,
      include: {
        supplier: true,
        bankAccount: true,
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      },
      orderBy: { createdAt: "desc" }
    });
    return payments;
  },
  async getById(id) {
    const payment = await import_prisma.prisma.payments.findUnique({
      where: { id },
      include: {
        supplier: true,
        bankAccount: true,
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      }
    });
    if (!payment) {
      throw new Error("Payment not found");
    }
    return payment;
  },
  async update(id, input) {
    const existingPayment = await this.getById(id);
    if (existingPayment.bankAccountId && existingPayment.paymentMethod === "BANK") {
      await import_prisma.prisma.bank_accounts.update({
        where: { id: existingPayment.bankAccountId },
        data: {
          balance: {
            increment: existingPayment.amount
          }
        }
      });
    }
    const payment = await import_prisma.prisma.payments.update({
      where: { id },
      data: {
        ...input,
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        supplier: true,
        bankAccount: true,
        createdBy: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true
          }
        }
      }
    });
    if (input.bankAccountId && input.paymentMethod === "BANK") {
      await import_prisma.prisma.bank_accounts.update({
        where: { id: input.bankAccountId },
        data: {
          balance: {
            decrement: input.amount || existingPayment.amount
          }
        }
      });
    }
    return payment;
  },
  async delete(id) {
    const payment = await this.getById(id);
    if (payment.bankAccountId && payment.paymentMethod === "BANK") {
      await import_prisma.prisma.bank_accounts.update({
        where: { id: payment.bankAccountId },
        data: {
          balance: {
            increment: payment.amount
          }
        }
      });
    }
    await import_prisma.prisma.payments.delete({
      where: { id }
    });
    return { message: "Payment deleted successfully" };
  },
  async getStatistics(filters) {
    const where = {};
    if (filters) {
      if (filters.supplierId) where.supplierId = filters.supplierId;
      if (filters.category) where.category = filters.category;
      if (filters.paymentMethod) where.paymentMethod = filters.paymentMethod;
      if (filters.status) where.status = filters.status;
      if (filters.startDate || filters.endDate) {
        where.paymentDate = {};
        if (filters.startDate) where.paymentDate.gte = filters.startDate;
        if (filters.endDate) where.paymentDate.lte = filters.endDate;
      }
    }
    const [totalPayments, totalAmount, byMethod, byCategory] = await Promise.all([
      import_prisma.prisma.payments.count({ where }),
      import_prisma.prisma.payments.aggregate({
        where,
        _sum: { amount: true }
      }),
      import_prisma.prisma.payments.groupBy({
        by: ["paymentMethod"],
        where,
        _sum: { amount: true },
        _count: true
      }),
      import_prisma.prisma.payments.groupBy({
        by: ["category"],
        where,
        _sum: { amount: true },
        _count: true
      })
    ]);
    return {
      totalPayments,
      totalAmount: totalAmount._sum.amount || 0,
      byPaymentMethod: byMethod,
      byCategory
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  paymentService
});
