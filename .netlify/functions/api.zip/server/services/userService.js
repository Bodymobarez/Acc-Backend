"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var userService_exports = {};
__export(userService_exports, {
  userService: () => userService
});
module.exports = __toCommonJS(userService_exports);
var import_bcryptjs = __toESM(require("bcryptjs"));
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
class UserService {
  async getAllUsers() {
    const users = await import_prisma.prisma.users.findMany({
      select: {
        id: true,
        username: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        avatar: true,
        role: true,
        department: true,
        isActive: true,
        salesTarget: true,
        commissionRate: true,
        joinedDate: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true,
        employees: {
          select: {
            id: true,
            employeeCode: true,
            department: true,
            defaultCommissionRate: true,
            isActive: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    });
    return users;
  }
  async getUserById(id) {
    const user = await import_prisma.prisma.users.findUnique({
      where: { id },
      select: {
        id: true,
        username: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        avatar: true,
        role: true,
        department: true,
        isActive: true,
        salesTarget: true,
        commissionRate: true,
        joinedDate: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true
      }
    });
    if (!user) {
      throw new Error("User not found");
    }
    return user;
  }
  async createUser(input) {
    return await import_prisma.prisma.$transaction(async (tx) => {
      const existingUser = await tx.users.findFirst({
        where: {
          OR: [
            { username: input.username.toLowerCase() },
            { email: input.email.toLowerCase() }
          ]
        }
      });
      if (existingUser) {
        throw new Error("Username or email already exists");
      }
      const hashedPassword = await import_bcryptjs.default.hash(input.password, 10);
      const allEmployees = await tx.employees.findMany({
        select: { employeeCode: true }
      });
      let nextNumber = 1;
      if (allEmployees && allEmployees.length > 0) {
        const numbers = allEmployees.map((emp) => {
          const match = emp.employeeCode?.match(/EMP-(\d+)/);
          return match ? parseInt(match[1]) : 0;
        }).filter((num) => num > 0);
        if (numbers.length > 0) {
          nextNumber = Math.max(...numbers) + 1;
        }
      }
      const employeeCode = `EMP-${String(nextNumber).padStart(3, "0")}`;
      const now = /* @__PURE__ */ new Date();
      const user = await tx.users.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          username: input.username.toLowerCase(),
          email: input.email.toLowerCase(),
          password: hashedPassword,
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
          role: input.role,
          department: input.department,
          salesTarget: input.salesTarget || 0,
          commissionRate: input.commissionRate || 0,
          isActive: input.isActive !== void 0 ? input.isActive : true,
          createdAt: now,
          updatedAt: now,
          employees: {
            create: {
              id: (0, import_crypto.randomUUID)(),
              employeeCode,
              department: input.department || "BOOKING",
              defaultCommissionRate: input.commissionRate || 0,
              isActive: true,
              createdAt: now,
              updatedAt: now
            }
          }
        },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          phone: true,
          avatar: true,
          role: true,
          department: true,
          isActive: true,
          salesTarget: true,
          commissionRate: true,
          joinedDate: true,
          lastLogin: true,
          createdAt: true,
          updatedAt: true,
          employees: {
            select: {
              id: true,
              employeeCode: true,
              department: true,
              defaultCommissionRate: true,
              isActive: true
            }
          }
        }
      });
      return user;
    });
  }
  async updateUser(id, input) {
    const existingUser = await import_prisma.prisma.users.findUnique({
      where: { id },
      include: { employees: true }
    });
    if (!existingUser) {
      throw new Error("User not found");
    }
    if (input.username || input.email) {
      const conflict = await import_prisma.prisma.users.findFirst({
        where: {
          AND: [
            { id: { not: id } },
            {
              OR: [
                input.username ? { username: input.username.toLowerCase() } : {},
                input.email ? { email: input.email.toLowerCase() } : {}
              ].filter((obj) => Object.keys(obj).length > 0)
            }
          ]
        }
      });
      if (conflict) {
        throw new Error("Username or email already exists");
      }
    }
    const updateData = {
      ...input,
      updatedAt: /* @__PURE__ */ new Date()
    };
    if (input.password) {
      updateData.password = await import_bcryptjs.default.hash(input.password, 10);
    }
    if (input.username) {
      updateData.username = input.username.toLowerCase();
    }
    if (input.email) {
      updateData.email = input.email.toLowerCase();
    }
    if (existingUser.employees && (input.commissionRate !== void 0 || input.department !== void 0)) {
      await import_prisma.prisma.employees.update({
        where: { id: existingUser.employees.id },
        data: {
          ...input.department && { department: input.department },
          ...input.commissionRate !== void 0 && { defaultCommissionRate: input.commissionRate }
        }
      });
    }
    const user = await import_prisma.prisma.users.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        username: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        avatar: true,
        role: true,
        department: true,
        isActive: true,
        salesTarget: true,
        commissionRate: true,
        joinedDate: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true,
        employees: {
          select: {
            id: true,
            employeeCode: true,
            department: true,
            defaultCommissionRate: true,
            isActive: true
          }
        }
      }
    });
    return user;
  }
  async deleteUser(id) {
    const existingUser = await import_prisma.prisma.users.findUnique({
      where: { id }
    });
    if (!existingUser) {
      throw new Error("User not found");
    }
    await import_prisma.prisma.users.delete({
      where: { id }
    });
    return { message: "User deleted successfully" };
  }
  async toggleUserStatus(id) {
    const user = await import_prisma.prisma.users.findUnique({
      where: { id }
    });
    if (!user) {
      throw new Error("User not found");
    }
    const updatedUser = await import_prisma.prisma.users.update({
      where: { id },
      data: {
        isActive: !user.isActive,
        updatedAt: /* @__PURE__ */ new Date()
      },
      select: {
        id: true,
        username: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        avatar: true,
        role: true,
        department: true,
        isActive: true,
        salesTarget: true,
        commissionRate: true,
        joinedDate: true,
        lastLogin: true,
        createdAt: true,
        updatedAt: true
      }
    });
    return updatedUser;
  }
  async updateLastLogin(id) {
    await import_prisma.prisma.users.update({
      where: { id },
      data: {
        lastLogin: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  async getUserStats() {
    const total = await import_prisma.prisma.users.count();
    const active = await import_prisma.prisma.users.count({
      where: { isActive: true }
    });
    const inactive = await import_prisma.prisma.users.count({
      where: { isActive: false }
    });
    const management = await import_prisma.prisma.users.count({
      where: {
        role: {
          in: ["ADMIN", "CEO", "MANAGER"]
        }
      }
    });
    const finance = await import_prisma.prisma.users.count({
      where: {
        role: {
          in: ["ACCOUNTANT", "FINANCIAL_CONTROLLER", "AUDITOR"]
        }
      }
    });
    const sales = await import_prisma.prisma.users.count({
      where: {
        role: {
          in: ["SALES_MANAGER", "SALES_AGENT", "BUSINESS_DEV"]
        }
      }
    });
    const operations = await import_prisma.prisma.users.count({
      where: {
        role: {
          in: ["BOOKING_AGENT", "CUSTOMER_SERVICE", "OPERATIONS_MANAGER"]
        }
      }
    });
    return {
      total,
      active,
      inactive,
      management,
      finance,
      sales,
      operations
    };
  }
}
const userService = new UserService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  userService
});
