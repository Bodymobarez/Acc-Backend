"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var fileService_exports = {};
__export(fileService_exports, {
  FileService: () => FileService,
  fileService: () => fileService
});
module.exports = __toCommonJS(fileService_exports);
var import_crypto = require("crypto");
var import_calculations = require("../utils/calculations");
var import_prisma = require("../lib/prisma");
class FileService {
  /**
   * Create file from booking
   */
  async createFile(input) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: input.bookingId },
      include: {
        customers: true,
        employees_bookings_bookingAgentIdToemployees: true,
        employees_bookings_customerServiceIdToemployees: true
      }
    });
    if (!booking) {
      throw new Error("Booking not found");
    }
    const user = await import_prisma.prisma.users.findUnique({
      where: { id: input.createdById }
    });
    if (!user) {
      const createdUser = await import_prisma.prisma.users.create({
        data: {
          id: input.createdById,
          username: "system_user",
          email: "system@example.com",
          password: "temp_password",
          firstName: "System",
          lastName: "User",
          role: "admin",
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    const file = await import_prisma.prisma.files.create({
      data: {
        id: (0, import_crypto.randomUUID)(),
        fileNumber: (0, import_calculations.generateFileNumber)("FILE", Date.now()),
        bookingId: input.bookingId,
        customerId: booking.customerId,
        status: "pending",
        createdById: input.createdById,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    const companySettings = await import_prisma.prisma.company_settings.findFirst();
    if (!companySettings) {
      throw new Error("Company settings not found");
    }
    return file;
  }
  /**
   * Get file by ID
   */
  async getFileById(id) {
    return await import_prisma.prisma.files.findUnique({
      where: { id },
      include: {
        bookings: {
          include: {
            customers: true
          }
        },
        users: true
      }
    });
  }
  /**
   * Get all files with filters
   */
  async getFiles(filters) {
    return await import_prisma.prisma.files.findMany({
      where: {
        ...filters.status && { status: filters.status },
        ...filters.customerId && { customerId: filters.customerId },
        ...filters.startDate && filters.endDate && {
          generatedDate: {
            gte: filters.startDate,
            lte: filters.endDate
          }
        }
      },
      include: {
        customers: true,
        bookings: true
      },
      orderBy: {
        generatedDate: "desc"
      }
    });
  }
  /**
   * Update file status
   */
  async updateFileStatus(id, status) {
    return await import_prisma.prisma.files.update({
      where: { id },
      data: { status }
    });
  }
  /**
   * Delete file
   */
  async deleteFile(id) {
    return await import_prisma.prisma.files.delete({
      where: { id }
    });
  }
}
const fileService = new FileService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  FileService,
  fileService
});
