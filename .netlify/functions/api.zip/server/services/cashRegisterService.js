"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cashRegisterService_exports = {};
__export(cashRegisterService_exports, {
  cashRegisterService: () => cashRegisterService
});
module.exports = __toCommonJS(cashRegisterService_exports);
var import_prisma = require("../lib/prisma");
const cashRegisterService = {
  async create(data) {
    const existing = await import_prisma.prisma.cash_registers.findFirst({
      where: {
        name: data.name,
        currency: data.currency
      }
    });
    if (existing) {
      throw new Error("Cash register with this name and currency already exists");
    }
    const cashRegister = await import_prisma.prisma.cash_registers.create({
      data: {
        id: require("crypto").randomUUID(),
        name: data.name,
        location: data.location || null,
        currency: data.currency || "AED",
        balance: data.balance || 0,
        notes: data.notes || null,
        isActive: data.isActive !== false,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return cashRegister;
  },
  async getAll(filters = {}) {
    const where = {};
    if (filters.currency) {
      where.currency = filters.currency;
    }
    if (filters.isActive !== void 0) {
      where.isActive = filters.isActive;
    }
    const cashRegisters = await import_prisma.prisma.cash_registers.findMany({
      where,
      orderBy: { createdAt: "desc" }
    });
    return cashRegisters;
  },
  async getById(id) {
    const cashRegister = await import_prisma.prisma.cash_registers.findUnique({
      where: { id }
    });
    if (!cashRegister) {
      throw new Error("Cash register not found");
    }
    return cashRegister;
  },
  async update(id, data) {
    if (data.name || data.currency) {
      const existing = await import_prisma.prisma.cash_registers.findFirst({
        where: {
          name: data.name,
          currency: data.currency,
          id: { not: id }
        }
      });
      if (existing) {
        throw new Error("Cash register with this name and currency already exists");
      }
    }
    const cashRegister = await import_prisma.prisma.cash_registers.update({
      where: { id },
      data: {
        ...data.name && { name: data.name },
        ...data.location !== void 0 && { location: data.location },
        ...data.currency && { currency: data.currency },
        ...data.balance !== void 0 && { balance: data.balance },
        ...data.notes !== void 0 && { notes: data.notes },
        ...data.isActive !== void 0 && { isActive: data.isActive },
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return cashRegister;
  },
  async delete(id) {
    const cashRegister = await import_prisma.prisma.cash_registers.findUnique({
      where: { id }
    });
    if (!cashRegister) {
      throw new Error("Cash register not found");
    }
    await import_prisma.prisma.cash_registers.delete({
      where: { id }
    });
    return { message: "Cash register deleted successfully" };
  },
  async updateBalance(id, amount, operation) {
    const cashRegister = await import_prisma.prisma.cash_registers.findUnique({
      where: { id }
    });
    if (!cashRegister) {
      throw new Error("Cash register not found");
    }
    const newBalance = operation === "add" ? cashRegister.balance + amount : cashRegister.balance - amount;
    const updated = await import_prisma.prisma.cash_registers.update({
      where: { id },
      data: {
        balance: newBalance,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return updated;
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  cashRegisterService
});
