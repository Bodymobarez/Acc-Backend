"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bankAccountService_exports = {};
__export(bankAccountService_exports, {
  bankAccountService: () => bankAccountService
});
module.exports = __toCommonJS(bankAccountService_exports);
var import_prisma = require("../lib/prisma");
const bankAccountService = {
  async create(input) {
    const existing = await import_prisma.prisma.bank_accounts.findUnique({
      where: { accountNumber: input.accountNumber }
    });
    if (existing) {
      throw new Error("Account number already exists");
    }
    const bankAccount = await import_prisma.prisma.bank_accounts.create({
      data: {
        id: `bank_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        accountNumber: input.accountNumber,
        accountName: input.accountName,
        bankName: input.bankName,
        currency: input.currency || "AED",
        balance: input.balance || 0,
        accountType: input.accountType || "CURRENT",
        branch: input.branch,
        swiftCode: input.swiftCode,
        iban: input.iban,
        notes: input.notes,
        isActive: input.isActive !== void 0 ? input.isActive : true,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return bankAccount;
  },
  async getAll(filters) {
    const where = {};
    if (filters) {
      if (filters.bankName) where.bankName = { contains: filters.bankName, mode: "insensitive" };
      if (filters.currency) where.currency = filters.currency;
      if (filters.accountType) where.accountType = filters.accountType;
      if (filters.isActive !== void 0) where.isActive = filters.isActive;
    }
    const bankAccounts = await import_prisma.prisma.bank_accounts.findMany({
      where,
      include: {
        _count: {
          select: { payments: true }
        }
      },
      orderBy: { createdAt: "desc" }
    });
    return bankAccounts;
  },
  async getById(id) {
    const bankAccount = await import_prisma.prisma.bank_accounts.findUnique({
      where: { id },
      include: {
        payments: {
          orderBy: { paymentDate: "desc" },
          take: 10
        },
        _count: {
          select: { payments: true }
        }
      }
    });
    if (!bankAccount) {
      throw new Error("Bank account not found");
    }
    return bankAccount;
  },
  async update(id, input) {
    await this.getById(id);
    if (input.accountNumber) {
      const existing = await import_prisma.prisma.bank_accounts.findFirst({
        where: {
          accountNumber: input.accountNumber,
          NOT: { id }
        }
      });
      if (existing) {
        throw new Error("Account number already exists");
      }
    }
    const bankAccount = await import_prisma.prisma.bank_accounts.update({
      where: { id },
      data: {
        ...input,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return bankAccount;
  },
  async delete(id) {
    const bankAccount = await this.getById(id);
    const paymentsCount = await import_prisma.prisma.payments.count({
      where: { bankAccountId: id }
    });
    if (paymentsCount > 0) {
      throw new Error("Cannot delete bank account with existing payments. Please delete or reassign payments first.");
    }
    await import_prisma.prisma.bank_accounts.delete({
      where: { id }
    });
    return { message: "Bank account deleted successfully" };
  },
  async updateBalance(id, amount, operation) {
    const bankAccount = await import_prisma.prisma.bank_accounts.update({
      where: { id },
      data: {
        balance: operation === "add" ? { increment: amount } : { decrement: amount },
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
    return bankAccount;
  },
  async getStatistics(filters) {
    const where = {};
    if (filters) {
      if (filters.bankName) where.bankName = { contains: filters.bankName, mode: "insensitive" };
      if (filters.currency) where.currency = filters.currency;
      if (filters.accountType) where.accountType = filters.accountType;
      if (filters.isActive !== void 0) where.isActive = filters.isActive;
    }
    const [totalAccounts, totalBalance, byCurrency, byType] = await Promise.all([
      import_prisma.prisma.bank_accounts.count({ where }),
      import_prisma.prisma.bank_accounts.aggregate({
        where,
        _sum: { balance: true }
      }),
      import_prisma.prisma.bank_accounts.groupBy({
        by: ["currency"],
        where,
        _sum: { balance: true },
        _count: true
      }),
      import_prisma.prisma.bank_accounts.groupBy({
        by: ["accountType"],
        where,
        _sum: { balance: true },
        _count: true
      })
    ]);
    return {
      totalAccounts,
      totalBalance: totalBalance._sum.balance || 0,
      byCurrency,
      byAccountType: byType
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  bankAccountService
});
