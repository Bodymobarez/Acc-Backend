"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var bookingService_exports = {};
__export(bookingService_exports, {
  BookingService: () => BookingService,
  bookingService: () => bookingService
});
module.exports = __toCommonJS(bookingService_exports);
var import_crypto = require("crypto");
var import_calculations = require("../utils/calculations");
var import_prisma = require("../lib/prisma");
var import_invoiceService = require("./invoiceService");
let accountingServiceInstance = null;
const getAccountingService = async () => {
  try {
    if (!accountingServiceInstance) {
      try {
        const module2 = await import("./accountingService");
        accountingServiceInstance = module2.accountingService;
      } catch (e1) {
        try {
          const module2 = await import("./accountingService.js");
          accountingServiceInstance = module2.accountingService;
        } catch (e2) {
          console.error("\u274C Failed to import accountingService with both paths:", e1.message, e2.message);
          throw e2;
        }
      }
    }
    return accountingServiceInstance;
  } catch (error) {
    console.error("\u274C Failed to load accountingService:", error.message);
    console.error("\u274C Error stack:", error.stack);
    return {
      createBookingJournalEntry: async () => {
        console.warn("\u26A0\uFE0F accountingService not available - skipping journal entry");
      },
      createBookingRevenueJournalEntry: async () => {
        console.warn("\u26A0\uFE0F accountingService not available - skipping journal entry");
      },
      createBookingVATJournalEntry: async () => {
        console.warn("\u26A0\uFE0F accountingService not available - skipping journal entry");
      },
      createCommissionJournalEntry: async () => {
        console.warn("\u26A0\uFE0F accountingService not available - skipping journal entry");
      },
      updateBookingJournalEntries: async () => {
        console.warn("\u26A0\uFE0F accountingService not available - skipping journal entry update");
      }
    };
  }
};
const invoiceService = new import_invoiceService.InvoiceService();
class BookingService {
  /**
   * Helper function to save additional suppliers
   */
  async saveAdditionalSuppliers(bookingId, additionalSuppliers) {
    if (!additionalSuppliers || additionalSuppliers.length === 0) {
      return;
    }
    console.log(`
\u{1F4CB} Adding ${additionalSuppliers.length} additional suppliers...`);
    for (const supplier of additionalSuppliers) {
      const costRate = await this.getExchangeRate(supplier.costCurrency);
      const costInAED = (0, import_calculations.convertToAED)(supplier.costAmount, costRate);
      const saleRate = await this.getExchangeRate(supplier.saleCurrency || "AED");
      const saleInAED = (0, import_calculations.convertToAED)(supplier.saleAmount || 0, saleRate);
      await import_prisma.prisma.booking_suppliers.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          bookingId,
          supplierId: supplier.supplierId,
          serviceType: supplier.serviceType,
          costAmount: supplier.costAmount,
          costCurrency: supplier.costCurrency,
          costInAED,
          saleAmount: supplier.saleAmount || 0,
          saleCurrency: supplier.saleCurrency || "AED",
          saleInAED,
          description: supplier.description,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    console.log("\u2705 Additional suppliers saved successfully");
  }
  /**
   * Create a new booking
   */
  async createBooking(input) {
    if (input.serviceType === "FLIGHT" && input.serviceDetails && typeof input.serviceDetails === "object") {
      const serviceDetails = input.serviceDetails;
      if (serviceDetails.airline && typeof serviceDetails.airline === "string") {
        try {
          let airline = await import_prisma.prisma.airlines.findUnique({
            where: { name: serviceDetails.airline.trim() }
          });
          if (!airline) {
            airline = await import_prisma.prisma.airlines.create({
              data: {
                id: (0, import_crypto.randomUUID)(),
                name: serviceDetails.airline.trim(),
                isActive: true,
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
            console.log(`\u2708\uFE0F  New airline created: ${airline.name}`);
          }
        } catch (error) {
          console.error("Error saving airline:", error);
        }
      }
    }
    const costRate = await this.getExchangeRate(input.costCurrency);
    const saleRate = await this.getExchangeRate(input.saleCurrency);
    let costInAED = (0, import_calculations.convertToAED)(input.costAmount, costRate);
    let saleInAED = (0, import_calculations.convertToAED)(input.saleAmount, saleRate);
    const isRefundBooking = input.bookingStatus === "REFUNDED";
    const vatCalc = input.vatApplicable ? (0, import_calculations.calculateVAT)(saleInAED, costInAED, input.isUAEBooking, 5, input.serviceType) : {
      isUAEBooking: input.isUAEBooking,
      saleAmount: saleInAED,
      costAmount: costInAED,
      netBeforeVAT: saleInAED,
      vatAmount: 0,
      totalWithVAT: saleInAED,
      // For REFUNDED: if cost > sale, it's profit (supplier refunded more)
      grossProfit: isRefundBooking && costInAED > saleInAED ? costInAED - saleInAED : saleInAED - costInAED,
      netProfit: isRefundBooking && costInAED > saleInAED ? costInAED - saleInAED : saleInAED - costInAED
    };
    let agentCommissionRate = input.agentCommissionRate || 0;
    let csCommissionRate = input.csCommissionRate || 0;
    if (!agentCommissionRate && input.bookingAgentId) {
      const bookingAgent = await import_prisma.prisma.employees.findUnique({
        where: { id: input.bookingAgentId }
      });
      agentCommissionRate = bookingAgent?.defaultCommissionRate || 0;
    }
    if (!csCommissionRate && input.customerServiceId) {
      const customerService = await import_prisma.prisma.employees.findUnique({
        where: { id: input.customerServiceId }
      });
      csCommissionRate = customerService?.defaultCommissionRate || 0;
    }
    let commissionBase;
    let finalVatAmount;
    let finalNetProfit;
    if (input.isUAEBooking && input.vatApplicable) {
      if (input.serviceType === "FLIGHT") {
        commissionBase = isRefundBooking ? Math.abs(vatCalc.grossProfit) : vatCalc.grossProfit;
        const commissionCalc = (0, import_calculations.calculateCommissions)(
          commissionBase,
          agentCommissionRate,
          csCommissionRate
        );
        finalVatAmount = (0, import_calculations.calculateVATOnProfit)(Math.abs(commissionCalc.profitAfterCommission));
        finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) - finalVatAmount : commissionCalc.profitAfterCommission - finalVatAmount;
        console.log("\u2708\uFE0F  FLIGHT Booking - VAT 5% on net profit ONLY (not extracted from total)");
        console.log("  Sale Amount:", saleInAED);
        console.log("  Cost Amount:", costInAED);
        console.log("  Gross Profit:", vatCalc.grossProfit);
        console.log("  Commission Base:", commissionBase);
        console.log("  Agent Commission:", commissionCalc.agentCommissionAmount);
        console.log("  Sales Commission:", commissionCalc.csCommissionAmount);
        console.log("  Total Commission:", commissionCalc.totalCommission);
        console.log("  Profit After Commission:", commissionCalc.profitAfterCommission);
        console.log("  VAT Amount (5% of net profit):", finalVatAmount);
        console.log("  Net Profit:", finalNetProfit);
        const prefix = input.bookingStatus === "REFUNDED" ? "RFN" : "BKG";
        const lastBooking = await import_prisma.prisma.bookings.findFirst({
          where: { bookingNumber: { startsWith: prefix } },
          orderBy: { createdAt: "desc" }
        });
        const nextSequence = lastBooking ? parseInt(lastBooking.bookingNumber.split("-").pop() || "0") + 1 : 1;
        const bookingNumber = (0, import_calculations.generateBookingNumber)(prefix, nextSequence);
        const booking = await import_prisma.prisma.bookings.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            bookingNumber,
            customerId: input.customerId,
            supplierId: input.supplierId,
            serviceType: input.serviceType,
            bookingAgentId: input.bookingAgentId,
            customerServiceId: input.customerServiceId,
            costAmount: input.costAmount,
            costCurrency: input.costCurrency,
            costInAED,
            saleAmount: input.saleAmount,
            saleCurrency: input.saleCurrency,
            saleInAED,
            isUAEBooking: input.isUAEBooking,
            vatApplicable: input.vatApplicable,
            netBeforeVAT: saleInAED,
            vatAmount: finalVatAmount,
            totalWithVAT: saleInAED,
            grossProfit: vatCalc.grossProfit,
            netProfit: finalNetProfit,
            agentCommissionRate,
            agentCommissionAmount: commissionCalc.agentCommissionAmount,
            csCommissionRate,
            csCommissionAmount: commissionCalc.csCommissionAmount,
            totalCommission: commissionCalc.totalCommission,
            serviceDetails: JSON.stringify(input.serviceDetails),
            travelDate: input.travelDate,
            returnDate: input.returnDate,
            bookingDate: input.bookingDate || /* @__PURE__ */ new Date(),
            notes: input.notes,
            internalNotes: input.internalNotes,
            createdById: input.createdById,
            status: "CONFIRMED",
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            suppliers: true,
            users: true
          }
        });
        const accountingService = await getAccountingService();
        await accountingService.createBookingJournalEntry(booking);
        await accountingService.createBookingRevenueJournalEntry(booking);
        await accountingService.createBookingVATJournalEntry(booking);
        if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
          await accountingService.createCommissionJournalEntry(booking, "AGENT");
        }
        if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
          await accountingService.createCommissionJournalEntry(booking, "CS");
        }
        console.log("\u{1F4C4} Auto-generating invoice for booking:", booking.bookingNumber);
        try {
          await invoiceService.createInvoice({
            bookingId: booking.id,
            createdById: input.createdById,
            dueDate: input.travelDate ? new Date(new Date(input.travelDate).getTime() - 3 * 24 * 60 * 60 * 1e3) : void 0
          });
          console.log("\u2705 Invoice auto-generated successfully");
        } catch (error) {
          console.error("\u26A0\uFE0F  Invoice auto-generation failed:", error.message);
        }
        await this.saveAdditionalSuppliers(booking.id, input.additionalSuppliers || []);
        return booking;
      } else {
        commissionBase = isRefundBooking ? Math.abs(vatCalc.grossProfit) : vatCalc.grossProfit;
        const commissionCalc = (0, import_calculations.calculateCommissions)(
          commissionBase,
          agentCommissionRate,
          csCommissionRate
        );
        finalVatAmount = vatCalc.vatAmount;
        finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) : commissionCalc.profitAfterCommission;
        console.log("\u2705 Non-FLIGHT UAE Booking - Commission from profit AFTER VAT deduction");
        console.log("  Net Before VAT:", vatCalc.netBeforeVAT);
        console.log("  VAT Amount:", finalVatAmount);
        console.log("  Gross Profit (after VAT):", vatCalc.grossProfit);
        console.log("  Commission Base:", commissionBase);
        console.log("  Agent Commission:", commissionCalc.agentCommissionAmount);
        console.log("  Sales Commission:", commissionCalc.csCommissionAmount);
        console.log("  Total Commission:", commissionCalc.totalCommission);
        console.log("  Net Profit:", finalNetProfit);
        const isRefunded2 = input.bookingStatus === "REFUNDED";
        const prefix2 = (0, import_calculations.getBookingPrefix)(input.serviceType, isRefunded2);
        const lastBooking2 = await import_prisma.prisma.bookings.findFirst({
          where: { bookingNumber: { startsWith: prefix2 } },
          orderBy: { createdAt: "desc" }
        });
        const nextSequence2 = lastBooking2 ? parseInt(lastBooking2.bookingNumber.split("-").pop() || "0") + 1 : 1;
        const bookingNumber = (0, import_calculations.generateBookingNumber)(prefix2, nextSequence2);
        const booking = await import_prisma.prisma.bookings.create({
          data: {
            id: (0, import_crypto.randomUUID)(),
            bookingNumber,
            customerId: input.customerId,
            supplierId: input.supplierId,
            serviceType: input.serviceType,
            bookingAgentId: input.bookingAgentId,
            customerServiceId: input.customerServiceId,
            costAmount: input.costAmount,
            costCurrency: input.costCurrency,
            costInAED,
            saleAmount: input.saleAmount,
            saleCurrency: input.saleCurrency,
            saleInAED,
            isUAEBooking: input.isUAEBooking,
            vatApplicable: input.vatApplicable,
            netBeforeVAT: vatCalc.netBeforeVAT,
            vatAmount: finalVatAmount,
            totalWithVAT: saleInAED,
            grossProfit: vatCalc.grossProfit,
            netProfit: finalNetProfit,
            agentCommissionRate,
            agentCommissionAmount: commissionCalc.agentCommissionAmount,
            csCommissionRate,
            csCommissionAmount: commissionCalc.csCommissionAmount,
            totalCommission: commissionCalc.totalCommission,
            serviceDetails: JSON.stringify(input.serviceDetails),
            travelDate: input.travelDate,
            returnDate: input.returnDate,
            bookingDate: input.bookingDate || /* @__PURE__ */ new Date(),
            notes: input.notes,
            internalNotes: input.internalNotes,
            createdById: input.createdById,
            status: "CONFIRMED",
            updatedAt: /* @__PURE__ */ new Date()
          },
          include: {
            customers: true,
            suppliers: true,
            users: true
          }
        });
        const accountingService = await getAccountingService();
        await accountingService.createBookingJournalEntry(booking);
        await accountingService.createBookingRevenueJournalEntry(booking);
        await accountingService.createBookingVATJournalEntry(booking);
        if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
          await accountingService.createCommissionJournalEntry(booking, "AGENT");
        }
        if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
          await accountingService.createCommissionJournalEntry(booking, "CS");
        }
        console.log("\u{1F4C4} Auto-generating invoice for booking:", booking.bookingNumber);
        try {
          await invoiceService.createInvoice({
            bookingId: booking.id,
            createdById: input.createdById,
            dueDate: input.travelDate ? new Date(new Date(input.travelDate).getTime() - 3 * 24 * 60 * 60 * 1e3) : void 0
          });
          console.log("\u2705 Invoice auto-generated successfully");
        } catch (error) {
          console.error("\u26A0\uFE0F  Invoice auto-generation failed:", error.message);
        }
        await this.saveAdditionalSuppliers(booking.id, input.additionalSuppliers || []);
        return booking;
      }
    } else {
      commissionBase = isRefundBooking ? Math.abs(vatCalc.grossProfit) : vatCalc.grossProfit;
      const commissionCalc = (0, import_calculations.calculateCommissions)(
        commissionBase,
        agentCommissionRate,
        csCommissionRate
      );
      finalVatAmount = input.vatApplicable ? (0, import_calculations.calculateVATOnProfit)(Math.abs(commissionCalc.profitAfterCommission)) : 0;
      finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) - finalVatAmount : commissionCalc.profitAfterCommission - finalVatAmount;
      console.log("\u2705 Non-UAE Booking - Commission from gross profit BEFORE VAT");
      console.log("  Gross Profit:", vatCalc.grossProfit);
      console.log("  Commission Base:", commissionBase);
      console.log("  Agent Commission:", commissionCalc.agentCommissionAmount);
      console.log("  Sales Commission:", commissionCalc.csCommissionAmount);
      console.log("  Total Commission:", commissionCalc.totalCommission);
      console.log("  Profit After Commission:", commissionCalc.profitAfterCommission);
      console.log("  VAT Amount:", finalVatAmount);
      console.log("  Net Profit:", finalNetProfit);
      const isRefunded = input.bookingStatus === "REFUNDED";
      const prefix = (0, import_calculations.getBookingPrefix)(input.serviceType, isRefunded);
      const lastBooking = await import_prisma.prisma.bookings.findFirst({
        where: { bookingNumber: { startsWith: prefix } },
        orderBy: { createdAt: "desc" }
      });
      const nextSequence = lastBooking ? parseInt(lastBooking.bookingNumber.split("-").pop() || "0") + 1 : 1;
      const bookingNumber = (0, import_calculations.generateBookingNumber)(prefix, nextSequence);
      const booking = await import_prisma.prisma.bookings.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          bookingNumber,
          customerId: input.customerId,
          supplierId: input.supplierId,
          serviceType: input.serviceType,
          bookingAgentId: input.bookingAgentId,
          customerServiceId: input.customerServiceId,
          costAmount: input.costAmount,
          costCurrency: input.costCurrency,
          costInAED,
          saleAmount: input.saleAmount,
          saleCurrency: input.saleCurrency,
          saleInAED,
          isUAEBooking: input.isUAEBooking,
          vatApplicable: input.vatApplicable,
          netBeforeVAT: saleInAED,
          vatAmount: finalVatAmount,
          totalWithVAT: saleInAED,
          // VAT calculated on profit, not added to customer total
          grossProfit: vatCalc.grossProfit,
          netProfit: finalNetProfit,
          agentCommissionRate,
          agentCommissionAmount: commissionCalc.agentCommissionAmount,
          csCommissionRate,
          csCommissionAmount: commissionCalc.csCommissionAmount,
          totalCommission: commissionCalc.totalCommission,
          serviceDetails: JSON.stringify(input.serviceDetails),
          travelDate: input.travelDate,
          returnDate: input.returnDate,
          bookingDate: input.bookingDate || /* @__PURE__ */ new Date(),
          notes: input.notes,
          internalNotes: input.internalNotes,
          createdById: input.createdById,
          status: "CONFIRMED",
          updatedAt: /* @__PURE__ */ new Date()
        },
        include: {
          customers: true,
          suppliers: true,
          users: true
        }
      });
      const accountingService = await getAccountingService();
      await accountingService.createBookingJournalEntry(booking);
      await accountingService.createBookingRevenueJournalEntry(booking);
      await accountingService.createBookingVATJournalEntry(booking);
      if (booking.agentCommissionAmount && booking.agentCommissionAmount > 0) {
        await accountingService.createCommissionJournalEntry(booking, "AGENT");
      }
      if (booking.csCommissionAmount && booking.csCommissionAmount > 0) {
        await accountingService.createCommissionJournalEntry(booking, "CS");
      }
      console.log("\u{1F4C4} Auto-generating invoice for booking:", booking.bookingNumber);
      try {
        await invoiceService.createInvoice({
          bookingId: booking.id,
          createdById: input.createdById,
          dueDate: input.travelDate ? new Date(new Date(input.travelDate).getTime() - 3 * 24 * 60 * 60 * 1e3) : void 0
        });
        console.log("\u2705 Invoice auto-generated successfully");
      } catch (error) {
        console.error("\u26A0\uFE0F  Invoice auto-generation failed:", error.message);
      }
      await this.saveAdditionalSuppliers(booking.id, input.additionalSuppliers || []);
      return booking;
    }
  }
  /**
   * Update booking commissions (typically by accountant during review)
   */
  async updateCommissions(bookingId, input) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId }
    });
    if (!booking) {
      throw new Error("Booking not found");
    }
    let commissionBase;
    let finalVatAmount;
    let finalNetProfit;
    let commissionCalc;
    if (booking.isUAEBooking && booking.vatApplicable) {
      commissionBase = booking.grossProfit || 0;
      commissionCalc = (0, import_calculations.calculateCommissions)(
        commissionBase,
        input.agentCommissionRate || 0,
        input.csCommissionRate || 0
      );
      finalVatAmount = booking.vatAmount || 0;
      finalNetProfit = commissionCalc.profitAfterCommission;
      console.log("\u2705 UAE Booking - Commission from profit AFTER VAT deduction");
      console.log("  Gross Profit (after VAT):", booking.grossProfit);
      console.log("  Commission Base:", commissionBase);
      console.log("  New Total Commission:", commissionCalc.totalCommission);
      console.log("  Net Profit:", finalNetProfit);
    } else {
      const grossProfit = booking.grossProfit || 0;
      commissionBase = grossProfit;
      commissionCalc = (0, import_calculations.calculateCommissions)(
        commissionBase,
        input.agentCommissionRate || 0,
        input.csCommissionRate || 0
      );
      finalVatAmount = booking.vatApplicable ? (0, import_calculations.calculateVATOnProfit)(commissionCalc.profitAfterCommission) : 0;
      finalNetProfit = commissionCalc.profitAfterCommission - finalVatAmount;
      console.log("\u2705 Non-UAE Booking - Commission from gross profit BEFORE VAT");
      console.log("  Gross Profit:", grossProfit);
      console.log("  Commission Base:", commissionBase);
      console.log("  New Total Commission:", commissionCalc.totalCommission);
      console.log("  Profit After Commission:", commissionCalc.profitAfterCommission);
      console.log("  VAT Amount:", finalVatAmount);
      console.log("  Net Profit:", finalNetProfit);
    }
    const updated = await import_prisma.prisma.bookings.update({
      where: { id: bookingId },
      data: {
        agentCommissionRate: input.agentCommissionRate,
        agentCommissionAmount: commissionCalc.agentCommissionAmount,
        csCommissionRate: input.csCommissionRate,
        csCommissionAmount: commissionCalc.csCommissionAmount,
        totalCommission: commissionCalc.totalCommission,
        vatAmount: finalVatAmount,
        // Update VAT amount
        netProfit: finalNetProfit,
        // Update net profit
        status: "PENDING_REVIEW",
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        customers: true,
        suppliers: true
      }
    });
    (async () => {
      try {
        console.log("\n\u{1F4D2} Updating journal entries for commission changes (background)...");
        const accountingService = await getAccountingService();
        await accountingService.updateBookingJournalEntries(bookingId);
        console.log("\u2705 Journal entries updated successfully");
      } catch (error) {
        console.error("\u26A0\uFE0F Failed to update journal entries:", error.message);
      }
    })();
    return updated;
  }
  /**
   * Approve booking (change status to confirmed)
   */
  async approveBooking(bookingId) {
    return await import_prisma.prisma.bookings.update({
      where: { id: bookingId },
      data: {
        status: "CONFIRMED",
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  /**
   * Get exchange rate for currency (defaults to 1 if not found or if AED)
   */
  async getExchangeRate(currencyCode) {
    if (currencyCode === "AED") return 1;
    const currency = await import_prisma.prisma.currencies.findUnique({
      where: { code: currencyCode }
    });
    return currency?.exchangeRateToAED || 1;
  }
  /**
   * Get all bookings with filters and RBAC
   */
  async getBookings(filters, rbacFilter) {
    const where = {
      ...filters.status && { status: filters.status },
      ...filters.serviceType && { serviceType: filters.serviceType },
      ...filters.customerId && { customerId: filters.customerId },
      ...filters.supplierId && { supplierId: filters.supplierId },
      ...filters.startDate && filters.endDate && {
        bookingDate: {
          gte: filters.startDate,
          lte: filters.endDate
        }
      }
    };
    if (rbacFilter !== null) {
      Object.assign(where, rbacFilter);
    }
    const bookings2 = await import_prisma.prisma.bookings.findMany({
      where,
      include: {
        customers: true,
        suppliers: true,
        booking_suppliers: {
          include: {
            suppliers: true
          }
        },
        employees_bookings_bookingAgentIdToemployees: {
          include: {
            users: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        employees_bookings_customerServiceIdToemployees: {
          include: {
            users: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        users: true,
        invoices: {
          select: {
            id: true,
            invoiceNumber: true,
            status: true
          }
        }
      },
      orderBy: {
        createdAt: "desc"
      }
    });
    if (bookings2.length > 0) {
      console.log("\n\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
      console.log("\u{1F4E6} BOOKINGS WITH CUSTOMER DATA:");
      console.log("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550");
      bookings2.slice(0, 5).forEach((b, i) => {
        console.log(`
[${i + 1}] ${b.bookingNumber}:`);
        console.log("   Customer ID:", b.customerId);
        console.log("   Customers Data:", b.customers ? {
          id: b.customers.id,
          type: b.customers.type,
          firstName: b.customers.firstName,
          lastName: b.customers.lastName,
          companyName: b.customers.companyName
        } : "NULL");
      });
      console.log("\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n");
    }
    return bookings2;
  }
  /**
   * Get booking by ID or bookingNumber
   */
  async getBookingById(id) {
    let booking = await import_prisma.prisma.bookings.findUnique({
      where: { id },
      include: {
        customers: true,
        suppliers: true,
        booking_suppliers: {
          include: {
            suppliers: true
          }
        },
        employees_bookings_bookingAgentIdToemployees: {
          include: {
            users: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        employees_bookings_customerServiceIdToemployees: {
          include: {
            users: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true
              }
            }
          }
        },
        users: true,
        invoices: true,
        files: true
      }
    });
    if (!booking) {
      booking = await import_prisma.prisma.bookings.findFirst({
        where: { bookingNumber: id },
        include: {
          customers: true,
          suppliers: true,
          booking_suppliers: {
            include: {
              suppliers: true
            }
          },
          employees_bookings_bookingAgentIdToemployees: {
            include: {
              users: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true
                }
              }
            }
          },
          employees_bookings_customerServiceIdToemployees: {
            include: {
              users: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true
                }
              }
            }
          },
          users: true,
          invoices: true,
          files: true
        }
      });
    }
    return booking;
  }
  /**
   * Update booking
   */
  async updateBooking(id, data) {
    try {
      console.log(`\u{1F504} Updating booking ${id}:`, data);
      console.log(`\u{1F4CA} Commission Rates Received:`, {
        agentCommissionRate: data.agentCommissionRate,
        csCommissionRate: data.csCommissionRate,
        agentCommissionType: data.agentCommissionType,
        salesCommissionType: data.salesCommissionType
      });
      const updateData = { ...data };
      if (data.serviceDetails && typeof data.serviceDetails === "object") {
        updateData.serviceDetails = JSON.stringify(data.serviceDetails);
        console.log("\u{1F3E8} Hotel details being saved:", data.serviceDetails.hotelName);
      }
      if (data.additionalSuppliers && Array.isArray(data.additionalSuppliers)) {
        console.log("\u{1F4E6} Updating multi-supplier data:", data.additionalSuppliers.length, "suppliers");
        await import_prisma.prisma.booking_suppliers.deleteMany({
          where: { bookingId: id }
        });
        for (const supplier of data.additionalSuppliers) {
          if (!supplier.supplierId) continue;
          const costRate = await this.getExchangeRate(supplier.costCurrency || "AED");
          const costInAED = (0, import_calculations.convertToAED)(supplier.costAmount || 0, costRate);
          const saleRate = await this.getExchangeRate(supplier.saleCurrency || "AED");
          const saleInAED = (0, import_calculations.convertToAED)(supplier.saleAmount || 0, saleRate);
          await import_prisma.prisma.booking_suppliers.create({
            data: {
              id: (0, import_crypto.randomUUID)(),
              bookingId: id,
              supplierId: supplier.supplierId,
              serviceType: supplier.serviceType || data.serviceType || "FLIGHT",
              costAmount: supplier.costAmount || 0,
              costCurrency: supplier.costCurrency || "AED",
              // Keep original currency
              costInAED,
              saleAmount: supplier.saleAmount || 0,
              saleCurrency: supplier.saleCurrency || "AED",
              // Keep original currency
              saleInAED,
              description: supplier.description || "",
              updatedAt: /* @__PURE__ */ new Date()
            }
          });
          console.log(`  \u2705 Added supplier ${supplier.supplierId} with ${supplier.costAmount} ${supplier.costCurrency}`);
        }
      }
      if (data.costAmount || data.saleAmount || data.costCurrency || data.saleCurrency || data.agentCommissionRate !== void 0 || data.csCommissionRate !== void 0) {
        const existing = await this.getBookingById(id);
        if (!existing) throw new Error("Booking not found");
        const costCurrency = data.costCurrency || existing.costCurrency;
        const saleCurrency = data.saleCurrency || existing.saleCurrency;
        const costAmount = data.costAmount || existing.costAmount;
        const saleAmount = data.saleAmount || existing.saleAmount;
        const costRate = await this.getExchangeRate(costCurrency);
        const saleRate = await this.getExchangeRate(saleCurrency);
        const costInAED = (0, import_calculations.convertToAED)(costAmount, costRate);
        const saleInAED = (0, import_calculations.convertToAED)(saleAmount, saleRate);
        const isUAEBooking = data.isUAEBooking !== void 0 ? data.isUAEBooking : existing.isUAEBooking;
        const vatApplicable = data.vatApplicable !== void 0 ? data.vatApplicable : existing.vatApplicable;
        const isRefundBooking = existing.status === "REFUNDED" || data.bookingStatus === "REFUNDED";
        const vatCalc = vatApplicable ? (0, import_calculations.calculateVAT)(saleInAED, costInAED, isUAEBooking) : {
          isUAEBooking,
          saleAmount: saleInAED,
          costAmount: costInAED,
          netBeforeVAT: saleInAED,
          vatAmount: 0,
          totalWithVAT: saleInAED,
          // For REFUNDED: if cost > sale, it's profit (supplier refunded more)
          grossProfit: isRefundBooking && costInAED > saleInAED ? costInAED - saleInAED : saleInAED - costInAED,
          netProfit: isRefundBooking && costInAED > saleInAED ? costInAED - saleInAED : saleInAED - costInAED
        };
        const agentCommissionRate = data.agentCommissionRate !== void 0 ? data.agentCommissionRate : existing.agentCommissionRate || 0;
        const csCommissionRate = data.csCommissionRate !== void 0 ? data.csCommissionRate : existing.csCommissionRate || 0;
        console.log(`\u{1F4C8} Commission Rates Processing:`, {
          receivedAgentRate: data.agentCommissionRate,
          receivedCsRate: data.csCommissionRate,
          finalAgentRate: agentCommissionRate,
          finalCsRate: csCommissionRate,
          existingAgentRate: existing.agentCommissionRate,
          existingCsRate: existing.csCommissionRate
        });
        const commissionCalc = (0, import_calculations.calculateCommissions)(
          vatCalc.grossProfit,
          agentCommissionRate,
          csCommissionRate
        );
        let finalVatAmount;
        let finalNetProfit;
        if (isUAEBooking && vatApplicable) {
          finalVatAmount = vatCalc.vatAmount;
          finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) : commissionCalc.profitAfterCommission;
        } else if (!isUAEBooking && vatApplicable) {
          finalVatAmount = (0, import_calculations.calculateVATOnProfit)(Math.abs(commissionCalc.profitAfterCommission));
          finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) - finalVatAmount : commissionCalc.profitAfterCommission - finalVatAmount;
        } else {
          finalVatAmount = 0;
          finalNetProfit = isRefundBooking && costInAED > saleInAED ? Math.abs(commissionCalc.profitAfterCommission) : commissionCalc.profitAfterCommission;
        }
        const updatedBooking = await import_prisma.prisma.bookings.update({
          where: { id },
          data: {
            costInAED,
            saleInAED,
            netBeforeVAT: isUAEBooking ? vatCalc.netBeforeVAT : saleInAED,
            vatAmount: finalVatAmount,
            totalWithVAT: saleInAED,
            // VAT calculated on profit, not added to customer total
            grossProfit: vatCalc.grossProfit,
            netProfit: finalNetProfit,
            agentCommissionAmount: commissionCalc.agentCommissionAmount,
            csCommissionAmount: commissionCalc.csCommissionAmount,
            totalCommission: commissionCalc.totalCommission,
            // Save commission rates if provided
            ...data.agentCommissionRate !== void 0 && { agentCommissionRate: data.agentCommissionRate },
            ...data.csCommissionRate !== void 0 && { csCommissionRate: data.csCommissionRate },
            ...updateData.customerId && { customerId: updateData.customerId },
            ...updateData.supplierId && { supplierId: updateData.supplierId },
            ...updateData.costAmount !== void 0 && { costAmount: updateData.costAmount },
            ...updateData.costCurrency && { costCurrency: updateData.costCurrency },
            ...updateData.saleAmount !== void 0 && { saleAmount: updateData.saleAmount },
            ...updateData.saleCurrency && { saleCurrency: updateData.saleCurrency },
            ...updateData.isUAEBooking !== void 0 && { isUAEBooking: updateData.isUAEBooking },
            ...updateData.vatApplicable !== void 0 && { vatApplicable: updateData.vatApplicable },
            ...updateData.serviceDetails && { serviceDetails: updateData.serviceDetails },
            ...updateData.serviceType && { serviceType: updateData.serviceType },
            ...updateData.notes !== void 0 && { notes: updateData.notes },
            ...updateData.travelDate && { travelDate: updateData.travelDate },
            ...updateData.returnDate && { returnDate: updateData.returnDate },
            ...updateData.bookingDate && { bookingDate: updateData.bookingDate },
            ...updateData.bookingAgentId !== void 0 && { bookingAgentId: updateData.bookingAgentId },
            ...updateData.customerServiceId !== void 0 && { customerServiceId: updateData.customerServiceId },
            ...data.bookingStatus && { status: data.bookingStatus },
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        (async () => {
          try {
            console.log("\n\u{1F4D2} Updating journal entries for booking changes (background)...");
            const accountingService = await getAccountingService();
            await accountingService.updateBookingJournalEntries(id);
            console.log("\u2705 Journal entries updated successfully");
          } catch (error) {
            console.error("\u26A0\uFE0F Failed to update journal entries:", error.message);
          }
        })();
        try {
          console.log("\n\u{1F4DD} Checking for existing invoice to update...");
          const existingInvoice = await import_prisma.prisma.invoices.findUnique({
            where: { bookingId: id }
          });
          if (existingInvoice) {
            console.log(`\u{1F4C4} Found invoice ${existingInvoice.invoiceNumber}, updating...`);
            const { invoiceService: invoiceService2 } = await import("./invoiceService");
            await invoiceService2.updateInvoiceFromBooking(existingInvoice.id, updatedBooking);
            console.log("\u2705 Invoice updated successfully");
          } else {
            console.log("\u2139\uFE0F No invoice found for this booking");
          }
        } catch (error) {
          console.error("\u26A0\uFE0F Failed to update invoice:", error.message);
        }
        return updatedBooking;
      }
      console.log("\u{1F4E6} Simple update with data:", updateData);
      const finalUpdateData = { ...updateData };
      if (data.agentCommissionRate !== void 0) {
        finalUpdateData.agentCommissionRate = data.agentCommissionRate;
      }
      if (data.csCommissionRate !== void 0) {
        finalUpdateData.csCommissionRate = data.csCommissionRate;
      }
      if (data.bookingStatus) {
        finalUpdateData.status = data.bookingStatus;
        delete finalUpdateData.bookingStatus;
      }
      const updated = await import_prisma.prisma.bookings.update({
        where: { id },
        data: {
          ...finalUpdateData,
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
      console.log("\u2705 Booking updated successfully:", updated.status);
      console.log("\u{1F4BE} ServiceDetails saved:", updated.serviceDetails?.substring(0, 100));
      console.log("\u{1F3AF} Final Commission Rates Saved:", {
        agentCommissionRate: updated.agentCommissionRate,
        csCommissionRate: updated.csCommissionRate
      });
      return updated;
    } catch (error) {
      console.error("\u274C Error updating booking:", error);
      throw error;
    }
  }
  /**
   * Delete booking
   * Also deletes related journal entries and invoice
   */
  async deleteBooking(id) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id },
      include: {
        invoices: true,
        journal_entries: true
      }
    });
    if (!booking) {
      throw new Error("Booking not found");
    }
    console.log(`\u{1F5D1}\uFE0F  Deleting booking ${id}...`);
    console.log(`   - Found ${booking.journal_entries?.length || 0} journal entries to delete`);
    console.log(`   - Found ${booking.invoices?.length || 0} invoices to delete`);
    if (booking.journal_entries && booking.journal_entries.length > 0) {
      const deletedJournals = await import_prisma.prisma.journal_entries.deleteMany({
        where: { bookingId: id }
      });
      console.log(`   \u2705 Deleted ${deletedJournals.count} journal entries for booking`);
    }
    if (booking.invoices && booking.invoices.length > 0) {
      for (const invoice of booking.invoices) {
        const deletedInvoiceJournals = await import_prisma.prisma.journal_entries.deleteMany({
          where: { invoiceId: invoice.id }
        });
        console.log(`   \u2705 Deleted ${deletedInvoiceJournals.count} journal entries for invoice ${invoice.invoiceNumber}`);
        await import_prisma.prisma.invoices.delete({
          where: { id: invoice.id }
        });
        console.log(`   \u2705 Deleted invoice ${invoice.invoiceNumber}`);
      }
    }
    const deletedBooking = await import_prisma.prisma.bookings.delete({
      where: { id }
    });
    console.log(`   \u2705 Booking deleted successfully`);
    return deletedBooking;
  }
  /**
   * Add supplier to booking
   */
  async addBookingSupplier(bookingId, supplierId, serviceType, costAmount, costCurrency, description) {
    const rate = await this.getExchangeRate(costCurrency);
    const costInAED = (0, import_calculations.convertToAED)(costAmount, rate);
    const bookingSupplier = await import_prisma.prisma.booking_suppliers.create({
      data: {
        id: (0, import_crypto.randomUUID)(),
        bookingId,
        supplierId,
        serviceType,
        costAmount,
        costCurrency,
        costInAED,
        description,
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        suppliers: true
      }
    });
    await this.recalculateBookingCosts(bookingId);
    return bookingSupplier;
  }
  /**
   * Get booking suppliers
   */
  async getBookingSuppliers(bookingId) {
    return await import_prisma.prisma.booking_suppliers.findMany({
      where: { bookingId },
      include: {
        suppliers: true
      },
      orderBy: { createdAt: "asc" }
    });
  }
  /**
   * Remove supplier from booking
   */
  async removeBookingSupplier(id) {
    const bookingSupplier = await import_prisma.prisma.booking_suppliers.findUnique({
      where: { id }
    });
    if (!bookingSupplier) {
      throw new Error("Booking supplier not found");
    }
    await import_prisma.prisma.booking_suppliers.delete({
      where: { id }
    });
    await this.recalculateBookingCosts(bookingSupplier.bookingId);
  }
  /**
   * Recalculate booking costs after supplier changes
   */
  async recalculateBookingCosts(bookingId) {
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId },
      include: {
        booking_suppliers: true
      }
    });
    if (!booking) return;
    const totalCostInAED = booking.booking_suppliers.reduce(
      (sum, supplier) => sum + supplier.costInAED,
      booking.costInAED
      // Include main supplier cost
    );
    const saleInAED = booking.saleInAED;
    const grossProfit = saleInAED - totalCostInAED;
    const vatCalc = booking.vatApplicable ? (0, import_calculations.calculateVAT)(saleInAED, totalCostInAED, booking.isUAEBooking) : {
      isUAEBooking: booking.isUAEBooking,
      saleAmount: saleInAED,
      costAmount: totalCostInAED,
      netBeforeVAT: saleInAED,
      vatAmount: 0,
      totalWithVAT: saleInAED,
      grossProfit,
      netProfit: grossProfit
    };
    const commissionBase = booking.isUAEBooking && booking.vatApplicable ? vatCalc.grossProfit : grossProfit;
    const commissionCalc = (0, import_calculations.calculateCommissions)(
      commissionBase,
      booking.agentCommissionRate || 0,
      booking.csCommissionRate || 0
    );
    const finalVatAmount = booking.isUAEBooking && booking.vatApplicable ? vatCalc.vatAmount : booking.vatApplicable ? (0, import_calculations.calculateVATOnProfit)(commissionCalc.profitAfterCommission) : 0;
    const finalNetProfit = booking.isUAEBooking && booking.vatApplicable ? commissionCalc.profitAfterCommission : commissionCalc.profitAfterCommission - finalVatAmount;
    await import_prisma.prisma.bookings.update({
      where: { id: bookingId },
      data: {
        grossProfit,
        netBeforeVAT: vatCalc.netBeforeVAT,
        vatAmount: finalVatAmount,
        totalWithVAT: saleInAED,
        agentCommissionAmount: commissionCalc.agentCommissionAmount,
        csCommissionAmount: commissionCalc.csCommissionAmount,
        totalCommission: commissionCalc.totalCommission,
        netProfit: finalNetProfit,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
}
const bookingService = new BookingService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BookingService,
  bookingService
});
