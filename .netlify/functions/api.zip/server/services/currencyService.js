"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var currencyService_exports = {};
__export(currencyService_exports, {
  currencyService: () => currencyService
});
module.exports = __toCommonJS(currencyService_exports);
var import_axios = __toESM(require("axios"));
var import_prisma = require("../lib/prisma");
const EXCHANGE_API_URL = "https://api.exchangerate-api.com/v4/latest/AED";
class CurrencyService {
  /**
   * Get all currencies
   */
  async getAllCurrencies() {
    const currencies = await import_prisma.prisma.currencies.findMany({
      orderBy: {
        code: "asc"
      }
    });
    return currencies;
  }
  /**
   * Get active currencies only
   */
  async getActiveCurrencies() {
    const currencies = await import_prisma.prisma.currencies.findMany({
      where: {
        isActive: true
      },
      orderBy: {
        code: "asc"
      }
    });
    return currencies;
  }
  /**
   * Get currency by code
   */
  async getCurrencyByCode(code) {
    const currency = await import_prisma.prisma.currencies.findUnique({
      where: { code: code.toUpperCase() }
    });
    return currency;
  }
  /**
   * Create or update currency
   */
  async upsertCurrency(code, name, symbol, exchangeRateToAED) {
    const currency = await import_prisma.prisma.currencies.upsert({
      where: { code: code.toUpperCase() },
      update: {
        name,
        symbol,
        exchangeRateToAED,
        lastUpdated: /* @__PURE__ */ new Date()
      },
      create: {
        id: `currency-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        code: code.toUpperCase(),
        name,
        symbol,
        exchangeRateToAED,
        isActive: true,
        lastUpdated: /* @__PURE__ */ new Date()
      }
    });
    return currency;
  }
  /**
   * Update currency exchange rate
   */
  async updateExchangeRate(code, rate) {
    const currency = await import_prisma.prisma.currencies.update({
      where: { code: code.toUpperCase() },
      data: {
        exchangeRateToAED: rate,
        lastUpdated: /* @__PURE__ */ new Date()
      }
    });
    return currency;
  }
  /**
   * Fetch latest exchange rates from API
   */
  async fetchExchangeRates() {
    try {
      console.log("\u{1F30D} Fetching latest exchange rates from API...");
      const response = await import_axios.default.get(EXCHANGE_API_URL, {
        timeout: 1e4
        // 10 second timeout
      });
      if (response.data && response.data.rates) {
        console.log("\u2705 Exchange rates fetched successfully");
        return response.data.rates;
      }
      throw new Error("Invalid API response format");
    } catch (error) {
      console.error("\u274C Error fetching exchange rates:", error.message);
      throw new Error(`Failed to fetch exchange rates: ${error.message}`);
    }
  }
  /**
   * Update all currency rates from API
   */
  async updateAllRates() {
    try {
      console.log("\u{1F4B1} Starting daily currency rate update...");
      const rates = await this.fetchExchangeRates();
      const currencies = await import_prisma.prisma.currencies.findMany({
        where: { isActive: true }
      });
      let updated = 0;
      const errors = [];
      for (const currency of currencies) {
        try {
          if (currency.code === "AED") {
            await this.updateExchangeRate("AED", 1);
            updated++;
          } else if (rates[currency.code]) {
            const rateFromAED = rates[currency.code];
            const rateToAED = 1 / rateFromAED;
            await this.updateExchangeRate(currency.code, rateToAED);
            updated++;
            console.log(`  \u2705 ${currency.code}: 1 ${currency.code} = ${rateToAED.toFixed(4)} AED`);
          } else {
            errors.push(`Rate not found for ${currency.code}`);
            console.warn(`  \u26A0\uFE0F  ${currency.code}: Rate not available`);
          }
        } catch (error) {
          errors.push(`Error updating ${currency.code}: ${error.message}`);
          console.error(`  \u274C ${currency.code}: ${error.message}`);
        }
      }
      console.log(`\u2705 Currency update complete: ${updated} updated, ${errors.length} errors`);
      return {
        success: true,
        updated,
        errors
      };
    } catch (error) {
      console.error("\u274C Currency update failed:", error.message);
      return {
        success: false,
        updated: 0,
        errors: [error.message]
      };
    }
  }
  /**
   * Convert amount from one currency to another
   */
  async convertCurrency(amount, fromCurrency, toCurrency) {
    if (fromCurrency === toCurrency) {
      return amount;
    }
    const [from, to] = await Promise.all([
      import_prisma.prisma.currencies.findUnique({ where: { code: fromCurrency.toUpperCase() } }),
      import_prisma.prisma.currencies.findUnique({ where: { code: toCurrency.toUpperCase() } })
    ]);
    if (!from || !to) {
      throw new Error(`Currency not found: ${!from ? fromCurrency : toCurrency}`);
    }
    const result = amount * (from.exchangeRateToAED / to.exchangeRateToAED);
    return Math.round(result * 100) / 100;
  }
  /**
   * Convert any currency to AED (base currency)
   */
  async convertToAED(amount, fromCurrency) {
    if (fromCurrency === "AED") {
      return amount;
    }
    const currency = await import_prisma.prisma.currencies.findUnique({
      where: { code: fromCurrency.toUpperCase() }
    });
    if (!currency) {
      throw new Error(`Currency not found: ${fromCurrency}`);
    }
    const result = amount * currency.exchangeRateToAED;
    return Math.round(result * 100) / 100;
  }
  /**
   * Toggle currency active status
   */
  async toggleCurrencyStatus(code) {
    const currency = await import_prisma.prisma.currencies.findUnique({
      where: { code: code.toUpperCase() }
    });
    if (!currency) {
      throw new Error(`Currency not found: ${code}`);
    }
    const updated = await import_prisma.prisma.currencies.update({
      where: { code: code.toUpperCase() },
      data: {
        isActive: !currency.isActive
      }
    });
    return updated;
  }
  /**
   * Initialize default currencies
   */
  async initializeDefaultCurrencies() {
    const defaultCurrencies = [
      // Base Currency
      { code: "AED", name: "UAE Dirham", symbol: "\u062F.\u0625", rate: 1 },
      // Major World Currencies
      { code: "USD", name: "US Dollar", symbol: "$", rate: 3.67 },
      { code: "EUR", name: "Euro", symbol: "\u20AC", rate: 4.02 },
      { code: "GBP", name: "British Pound", symbol: "\xA3", rate: 4.68 },
      { code: "JPY", name: "Japanese Yen", symbol: "\xA5", rate: 0.025 },
      { code: "CHF", name: "Swiss Franc", symbol: "Fr", rate: 4.15 },
      { code: "CAD", name: "Canadian Dollar", symbol: "C$", rate: 2.71 },
      { code: "AUD", name: "Australian Dollar", symbol: "A$", rate: 2.42 },
      { code: "CNY", name: "Chinese Yuan", symbol: "\xA5", rate: 0.51 },
      { code: "INR", name: "Indian Rupee", symbol: "\u20B9", rate: 0.044 },
      // GCC Currencies
      { code: "SAR", name: "Saudi Riyal", symbol: "\u0631.\u0633", rate: 0.98 },
      { code: "QAR", name: "Qatari Riyal", symbol: "\u0631.\u0642", rate: 1.01 },
      { code: "KWD", name: "Kuwaiti Dinar", symbol: "\u062F.\u0643", rate: 12 },
      { code: "OMR", name: "Omani Rial", symbol: "\u0631.\u0639", rate: 9.53 },
      { code: "BHD", name: "Bahraini Dinar", symbol: "\u062F.\u0628", rate: 9.75 },
      // Middle East & Africa
      { code: "EGP", name: "Egyptian Pound", symbol: "\u062C.\u0645", rate: 0.075 },
      { code: "JOD", name: "Jordanian Dinar", symbol: "\u062F.\u0627", rate: 5.17 },
      { code: "LBP", name: "Lebanese Pound", symbol: "\u0644.\u0644", rate: 24e-4 },
      { code: "TRY", name: "Turkish Lira", symbol: "\u20BA", rate: 0.136 },
      { code: "ZAR", name: "South African Rand", symbol: "R", rate: 0.2 },
      { code: "MAD", name: "Moroccan Dirham", symbol: "\u062F.\u0645", rate: 0.37 },
      // Asia Pacific
      { code: "SGD", name: "Singapore Dollar", symbol: "S$", rate: 2.73 },
      { code: "HKD", name: "Hong Kong Dollar", symbol: "HK$", rate: 0.47 },
      { code: "MYR", name: "Malaysian Ringgit", symbol: "RM", rate: 0.82 },
      { code: "THB", name: "Thai Baht", symbol: "\u0E3F", rate: 0.107 },
      { code: "IDR", name: "Indonesian Rupiah", symbol: "Rp", rate: 23e-5 },
      { code: "PHP", name: "Philippine Peso", symbol: "\u20B1", rate: 0.064 },
      { code: "PKR", name: "Pakistani Rupee", symbol: "\u20A8", rate: 0.013 },
      { code: "BDT", name: "Bangladeshi Taka", symbol: "\u09F3", rate: 0.034 },
      { code: "LKR", name: "Sri Lankan Rupee", symbol: "Rs", rate: 0.012 },
      { code: "KRW", name: "South Korean Won", symbol: "\u20A9", rate: 27e-4 },
      // Europe
      { code: "SEK", name: "Swedish Krona", symbol: "kr", rate: 0.35 },
      { code: "NOK", name: "Norwegian Krone", symbol: "kr", rate: 0.34 },
      { code: "DKK", name: "Danish Krone", symbol: "kr", rate: 0.54 },
      { code: "PLN", name: "Polish Zloty", symbol: "z\u0142", rate: 0.93 },
      { code: "CZK", name: "Czech Koruna", symbol: "K\u010D", rate: 0.162 },
      { code: "HUF", name: "Hungarian Forint", symbol: "Ft", rate: 0.01 },
      { code: "RUB", name: "Russian Ruble", symbol: "\u20BD", rate: 0.039 },
      // Americas
      { code: "MXN", name: "Mexican Peso", symbol: "Mex$", rate: 0.21 },
      { code: "BRL", name: "Brazilian Real", symbol: "R$", rate: 0.73 },
      { code: "ARS", name: "Argentine Peso", symbol: "$", rate: 37e-4 },
      { code: "CLP", name: "Chilean Peso", symbol: "$", rate: 38e-4 },
      { code: "COP", name: "Colombian Peso", symbol: "$", rate: 93e-5 },
      // Others
      { code: "NZD", name: "New Zealand Dollar", symbol: "NZ$", rate: 2.23 },
      { code: "ILS", name: "Israeli Shekel", symbol: "\u20AA", rate: 0.99 }
    ];
    console.log("\u{1F4B1} Initializing default currencies...");
    for (const curr of defaultCurrencies) {
      try {
        await this.upsertCurrency(curr.code, curr.name, curr.symbol, curr.rate);
        console.log(`  \u2705 ${curr.code} - ${curr.name}`);
      } catch (error) {
        console.error(`  \u274C ${curr.code}: ${error.message}`);
      }
    }
    console.log(`\u2705 ${defaultCurrencies.length} default currencies initialized`);
  }
}
const currencyService = new CurrencyService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  currencyService
});
