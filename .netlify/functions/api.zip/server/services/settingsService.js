"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var settingsService_exports = {};
__export(settingsService_exports, {
  settingsService: () => settingsService
});
module.exports = __toCommonJS(settingsService_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
class SettingsService {
  // Company Settings Methods
  async getCompanySettings() {
    const settings = await import_prisma.prisma.company_settings.findFirst();
    if (!settings) {
      return await import_prisma.prisma.company_settings.create({
        data: {
          id: (0, import_crypto.randomUUID)(),
          companyName: "Tourism Accounting System",
          companyNameArabic: "\u0646\u0638\u0627\u0645 \u0627\u0644\u0645\u062D\u0627\u0633\u0628\u0629 \u0627\u0644\u0633\u064A\u0627\u062D\u064A\u0629",
          addressLine1: "Dubai, UAE",
          city: "Dubai",
          country: "United Arab Emirates",
          phone: "+971 XX XXX XXXX",
          email: "info@company.com",
          defaultCurrency: "AED",
          vatRate: 5,
          vatEnabled: true,
          invoicePrefix: "INV",
          filePrefix: "FILE",
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    return settings;
  }
  async updateCompanySettings(id, data) {
    return await import_prisma.prisma.company_settings.update({
      where: { id },
      data: {
        ...data,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  // System Settings Methods
  async getAllSystemSettings() {
    return await import_prisma.prisma.system_settings.findMany({
      orderBy: {
        key: "asc"
      }
    });
  }
  async getSystemSetting(key) {
    const setting = await import_prisma.prisma.system_settings.findUnique({
      where: { key }
    });
    return setting;
  }
  async upsertSystemSetting(data) {
    return await import_prisma.prisma.system_settings.upsert({
      where: { key: data.key },
      create: {
        id: (0, import_crypto.randomUUID)(),
        key: data.key,
        value: data.value,
        description: data.description,
        updatedAt: /* @__PURE__ */ new Date()
      },
      update: {
        value: data.value,
        description: data.description,
        updatedAt: /* @__PURE__ */ new Date()
      }
    });
  }
  async deleteSystemSetting(key) {
    return await import_prisma.prisma.system_settings.delete({
      where: { key }
    });
  }
  // Print Settings (stored in system settings as JSON)
  async getPrintSettings() {
    const setting = await this.getSystemSetting("print_settings");
    if (!setting) {
      return {
        logoPath: null,
        sealPath: null
      };
    }
    try {
      return JSON.parse(setting.value);
    } catch (e) {
      return {
        logoPath: null,
        sealPath: null
      };
    }
  }
  async updatePrintSettings(data) {
    return await this.upsertSystemSetting({
      key: "print_settings",
      value: JSON.stringify(data),
      description: "Print settings for invoices and documents"
    });
  }
}
const settingsService = new SettingsService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  settingsService
});
