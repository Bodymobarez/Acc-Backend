"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var receiptService_exports = {};
__export(receiptService_exports, {
  receiptService: () => receiptService
});
module.exports = __toCommonJS(receiptService_exports);
var import_crypto = require("crypto");
var import_accountingService = require("./accountingService");
var import_prisma = require("../lib/prisma");
const receiptService = {
  // Create new receipt
  async createReceipt(input) {
    console.log("\u{1F9FE} Creating receipt:", JSON.stringify(input, null, 2));
    if (input.invoiceId) {
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: input.invoiceId },
        select: { totalAmount: true, invoiceNumber: true }
      });
      if (!invoice) {
        throw new Error("Invoice not found");
      }
      const existingReceipts = await import_prisma.prisma.receipts.findMany({
        where: {
          invoiceId: input.invoiceId,
          status: { not: "CANCELLED" }
        },
        select: { amount: true, receiptNumber: true }
      });
      const totalAlreadyPaid = existingReceipts.reduce((sum, r) => sum + r.amount, 0);
      const remainingAmount = invoice.totalAmount - totalAlreadyPaid;
      const epsilon = 0.01;
      if (remainingAmount <= epsilon) {
        throw new Error(`Invoice ${invoice.invoiceNumber} is already fully paid. Total: ${invoice.totalAmount}, Already Paid: ${totalAlreadyPaid}`);
      }
      if (input.amount > remainingAmount + epsilon) {
        throw new Error(`Receipt amount (${input.amount}) exceeds remaining invoice balance (${remainingAmount.toFixed(2)}). Invoice ${invoice.invoiceNumber} total: ${invoice.totalAmount}, already paid: ${totalAlreadyPaid.toFixed(2)}`);
      }
    }
    const receipt = await import_prisma.prisma.receipts.create({
      data: {
        id: (0, import_crypto.randomUUID)(),
        receiptNumber: input.receiptNumber,
        customerId: input.customerId,
        invoiceId: input.invoiceId || null,
        amount: input.amount,
        paymentMethod: input.paymentMethod.toUpperCase(),
        bankAccountId: input.bankAccountId || null,
        supplierId: input.supplierId || null,
        checkNumber: input.checkNumber || null,
        reference: input.reference || null,
        receiptDate: input.receiptDate ? new Date(input.receiptDate) : /* @__PURE__ */ new Date(),
        notes: input.notes || null,
        status: "COMPLETED",
        matchingStatus: input.matchingStatus || "NOT_MATCHED",
        // Add matching status
        matchedAmount: input.matchedAmount || 0,
        // Add matched amount
        createdById: input.createdById || null,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      },
      include: {
        customers: {
          select: {
            id: true,
            customerCode: true,
            firstName: true,
            lastName: true,
            companyName: true,
            email: true
          }
        }
      }
    });
    await import_accountingService.accountingService.createReceiptJournalEntry(receipt);
    if (input.invoiceId) {
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: input.invoiceId },
        select: {
          totalAmount: true,
          bookingId: true
        }
      });
      if (invoice) {
        const allReceipts = await import_prisma.prisma.receipts.findMany({
          where: {
            invoiceId: input.invoiceId,
            status: { not: "CANCELLED" }
          },
          select: { amount: true }
        });
        const totalPaid = allReceipts.reduce((sum, r) => sum + r.amount, 0);
        const epsilon = 0.01;
        const difference = invoice.totalAmount - totalPaid;
        let newStatus = "UNPAID";
        if (Math.abs(difference) < epsilon || totalPaid >= invoice.totalAmount) {
          newStatus = "PAID";
        } else if (totalPaid > 0) {
          newStatus = "PARTIALLY_PAID";
        }
        console.log(`\u2705 Auto-updating invoice status:`);
        console.log(`   Invoice Amount: ${invoice.totalAmount}`);
        console.log(`   Payment Amount: ${input.amount}`);
        console.log(`   Total Paid: ${totalPaid}`);
        console.log(`   Difference: ${difference}`);
        console.log(`   New Status: ${newStatus}`);
        await import_prisma.prisma.invoices.update({
          where: { id: input.invoiceId },
          data: {
            status: newStatus,
            updatedAt: /* @__PURE__ */ new Date()
          }
        });
        if (newStatus === "PAID" && invoice.bookingId) {
          await import_prisma.prisma.bookings.update({
            where: { id: invoice.bookingId },
            data: {
              status: "COMPLETE",
              updatedAt: /* @__PURE__ */ new Date()
            }
          });
          console.log(`\u2705 Booking status updated to COMPLETE`);
        }
      }
    }
    return receipt;
  },
  // Get all receipts
  async getAllReceipts(filters) {
    const where = {};
    if (filters?.customerId) {
      where.customerId = filters.customerId;
    }
    if (filters?.status) {
      where.status = filters.status;
    }
    if (filters?.paymentMethod) {
      where.paymentMethod = filters.paymentMethod;
    }
    if (filters?.startDate || filters?.endDate) {
      where.receiptDate = {};
      if (filters.startDate) {
        where.receiptDate.gte = new Date(filters.startDate);
      }
      if (filters.endDate) {
        where.receiptDate.lte = new Date(filters.endDate);
      }
    }
    const receipts = await import_prisma.prisma.receipts.findMany({
      where,
      include: {
        customers: {
          select: {
            id: true,
            customerCode: true,
            firstName: true,
            lastName: true,
            companyName: true,
            email: true
          }
        }
      },
      orderBy: {
        receiptDate: "desc"
      }
    });
    return receipts;
  },
  // Get receipt by ID
  async getReceiptById(id) {
    const receipt = await import_prisma.prisma.receipts.findUnique({
      where: { id },
      include: {
        customers: {
          select: {
            id: true,
            customerCode: true,
            firstName: true,
            lastName: true,
            companyName: true,
            email: true,
            phone: true
          }
        }
      }
    });
    if (!receipt) {
      throw new Error("Receipt not found");
    }
    return receipt;
  },
  // Update receipt
  async updateReceipt(id, input) {
    if (input.invoiceId) {
      const invoiceId = input.invoiceId;
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: invoiceId },
        select: { totalAmount: true, invoiceNumber: true }
      });
      if (!invoice) {
        throw new Error("Invoice not found");
      }
      const existingReceipts = await import_prisma.prisma.receipts.findMany({
        where: {
          invoiceId,
          id: { not: id },
          // Exclude current receipt
          status: { not: "CANCELLED" }
        },
        select: { amount: true }
      });
      const totalAlreadyPaid = existingReceipts.reduce((sum, r) => sum + r.amount, 0);
      const remainingAmount = invoice.totalAmount - totalAlreadyPaid;
      const epsilon = 0.01;
      const currentReceipt = await import_prisma.prisma.receipts.findUnique({
        where: { id },
        select: { amount: true }
      });
      const receiptAmount = input.amount !== void 0 ? input.amount : currentReceipt?.amount || 0;
      if (receiptAmount > remainingAmount + epsilon) {
        throw new Error(`Receipt amount (${receiptAmount}) exceeds remaining invoice balance (${remainingAmount.toFixed(2)}). Invoice ${invoice.invoiceNumber} total: ${invoice.totalAmount}, already paid: ${totalAlreadyPaid.toFixed(2)}`);
      }
    }
    const receipt = await import_prisma.prisma.receipts.update({
      where: { id },
      data: {
        ...input.amount !== void 0 && { amount: input.amount },
        ...input.paymentMethod && { paymentMethod: input.paymentMethod.toUpperCase() },
        ...input.bankAccountId !== void 0 && { bankAccountId: input.bankAccountId },
        ...input.checkNumber !== void 0 && { checkNumber: input.checkNumber },
        ...input.reference !== void 0 && { reference: input.reference },
        ...input.receiptDate && { receiptDate: new Date(input.receiptDate) },
        ...input.notes !== void 0 && { notes: input.notes },
        ...input.status && { status: input.status.toUpperCase() },
        ...input.matchingStatus && { matchingStatus: input.matchingStatus },
        ...input.matchedAmount !== void 0 && { matchedAmount: input.matchedAmount },
        ...input.invoiceId !== void 0 && { invoiceId: input.invoiceId }
      },
      include: {
        customers: {
          select: {
            id: true,
            customerCode: true,
            firstName: true,
            lastName: true,
            companyName: true,
            email: true
          }
        }
      }
    });
    if (input.invoiceId) {
      const invoiceId = input.invoiceId;
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: invoiceId },
        select: { totalAmount: true }
      });
      if (invoice) {
        const allReceipts = await import_prisma.prisma.receipts.findMany({
          where: {
            invoiceId,
            status: { not: "CANCELLED" }
          }
        });
        const totalPaid = allReceipts.reduce((sum, r) => sum + r.amount, 0);
        const epsilon = 0.01;
        const difference = invoice.totalAmount - totalPaid;
        let newStatus = "UNPAID";
        if (Math.abs(difference) < epsilon || totalPaid >= invoice.totalAmount) {
          newStatus = "PAID";
        } else if (totalPaid > 0) {
          newStatus = "PARTIALLY_PAID";
        }
        console.log(`\u2705 Auto-updating invoice status:`);
        console.log(`   Invoice Amount: ${invoice.totalAmount}`);
        console.log(`   Total Paid: ${totalPaid}`);
        console.log(`   Difference: ${difference}`);
        console.log(`   New Status: ${newStatus}`);
        await import_prisma.prisma.invoices.update({
          where: { id: invoiceId },
          data: { status: newStatus }
        });
        if (newStatus === "PAID") {
          const invoiceWithBooking = await import_prisma.prisma.invoices.findUnique({
            where: { id: invoiceId },
            select: { bookingId: true }
          });
          if (invoiceWithBooking?.bookingId) {
            await import_prisma.prisma.bookings.update({
              where: { id: invoiceWithBooking.bookingId },
              data: {
                status: "COMPLETE",
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
            console.log(`\u2705 Booking status updated to COMPLETE`);
          }
        }
      }
    }
    return receipt;
  },
  // Delete receipt
  async deleteReceipt(id) {
    const receipt = await import_prisma.prisma.receipts.findUnique({
      where: { id },
      select: { invoiceId: true, amount: true }
    });
    if (!receipt) {
      throw new Error("Receipt not found");
    }
    await import_prisma.prisma.receipts.delete({
      where: { id }
    });
    if (receipt.invoiceId) {
      const invoice = await import_prisma.prisma.invoices.findUnique({
        where: { id: receipt.invoiceId },
        select: { totalAmount: true }
      });
      if (invoice) {
        const remainingReceipts = await import_prisma.prisma.receipts.findMany({
          where: {
            invoiceId: receipt.invoiceId,
            status: { not: "CANCELLED" }
          }
        });
        const totalPaid = remainingReceipts.reduce((sum, r) => sum + r.amount, 0);
        const epsilon = 0.01;
        const difference = invoice.totalAmount - totalPaid;
        let newStatus = "UNPAID";
        if (Math.abs(difference) < epsilon || totalPaid >= invoice.totalAmount) {
          newStatus = "PAID";
        } else if (totalPaid > 0) {
          newStatus = "PARTIALLY_PAID";
        }
        await import_prisma.prisma.invoices.update({
          where: { id: receipt.invoiceId },
          data: { status: newStatus }
        });
        if (newStatus !== "PAID") {
          const invoiceWithBooking = await import_prisma.prisma.invoices.findUnique({
            where: { id: receipt.invoiceId },
            select: { bookingId: true }
          });
          if (invoiceWithBooking?.bookingId) {
            const booking = await import_prisma.prisma.bookings.findUnique({
              where: { id: invoiceWithBooking.bookingId },
              select: { status: true }
            });
            if (booking?.status === "COMPLETE") {
              await import_prisma.prisma.bookings.update({
                where: { id: invoiceWithBooking.bookingId },
                data: {
                  status: "CONFIRMED",
                  updatedAt: /* @__PURE__ */ new Date()
                }
              });
              console.log(`\u26A0\uFE0F Booking status reverted to CONFIRMED (receipt deleted)`);
            }
          }
        }
      }
    }
    return {
      success: true,
      message: "Receipt deleted successfully",
      invoiceReverted: !!receipt.invoiceId
    };
  },
  // Get receipts by customer
  async getReceiptsByCustomer(customerId) {
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: { customerId },
      orderBy: {
        receiptDate: "desc"
      }
    });
    return receipts;
  },
  // Get receipts by invoice
  async getReceiptsByInvoice(invoiceId) {
    const receipts = await import_prisma.prisma.receipts.findMany({
      where: { invoiceId },
      orderBy: {
        receiptDate: "desc"
      }
    });
    return receipts;
  },
  // Generate receipt number
  async generateReceiptNumber() {
    const year = (/* @__PURE__ */ new Date()).getFullYear();
    const count = await import_prisma.prisma.receipts.count({
      where: {
        receiptNumber: {
          startsWith: `REC-${year}`
        }
      }
    });
    return `REC-${year}-${String(count + 1).padStart(4, "0")}`;
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  receiptService
});
