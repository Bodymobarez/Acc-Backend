"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var activityTracker_exports = {};
__export(activityTracker_exports, {
  activityTrackerMiddleware: () => activityTrackerMiddleware,
  default: () => activityTracker_default,
  trackActivity: () => trackActivity,
  trackLogin: () => trackLogin
});
module.exports = __toCommonJS(activityTracker_exports);
var import_nanoid = require("nanoid");
var import_prisma = require("../lib/prisma");
const trackActivity = async (req, activityData) => {
  try {
    if (!req.user) return;
    const { action, entityType, entityId, description, changes, targetUserId, metadata } = activityData;
    await import_prisma.prisma.activity_logs.create({
      data: {
        id: (0, import_nanoid.nanoid)(),
        userId: req.user.id,
        action,
        entityType,
        entityId,
        description,
        ipAddress: req.ip || req.connection.remoteAddress,
        userAgent: req.headers["user-agent"],
        changes: changes ? JSON.stringify(changes) : null,
        targetUserId,
        metadata: JSON.stringify(metadata || {}),
        createdAt: /* @__PURE__ */ new Date()
      }
    });
    if (shouldNotifyAdmins(action, entityType)) {
      await createAdminNotifications(req, activityData);
    }
  } catch (error) {
    console.error("Activity tracking error:", error);
  }
};
function shouldNotifyAdmins(action, entityType) {
  const criticalActions = [
    "CREATE",
    "UPDATE",
    "DELETE",
    "APPROVE",
    "REJECT",
    "CANCEL",
    "EXPORT",
    "IMPORT"
  ];
  const criticalEntities = [
    "BOOKING",
    "INVOICE",
    "RECEIPT",
    "JOURNAL_ENTRY",
    "CUSTOMER",
    "SUPPLIER",
    "USER",
    "ACCOUNT"
  ];
  return criticalActions.includes(action) && criticalEntities.includes(entityType);
}
async function createAdminNotifications(req, activityData) {
  try {
    const adminUsers = await import_prisma.prisma.users.findMany({
      where: {
        role: { in: ["ADMIN", "SUPER_ADMIN", "ACCOUNTING"] },
        isActive: true,
        id: { not: req.user.id }
        // Don't notify the user who performed the action
      },
      select: { id: true }
    });
    if (adminUsers.length === 0) return;
    const notifications = adminUsers.map((admin) => ({
      id: (0, import_nanoid.nanoid)(),
      userId: admin.id,
      type: `${activityData.entityType}_${activityData.action}`,
      title: getNotificationTitle(activityData),
      message: activityData.description,
      actionType: activityData.action,
      actionBy: req.user.id,
      entityType: activityData.entityType,
      entityId: activityData.entityId,
      metadata: JSON.stringify({
        userName: `${req.user.firstName} ${req.user.lastName}`,
        userEmail: req.user.email,
        userRole: req.user.role,
        ...activityData.metadata
      }),
      isRead: false,
      createdAt: /* @__PURE__ */ new Date()
    }));
    await import_prisma.prisma.notifications.createMany({
      data: notifications
    });
  } catch (error) {
    console.error("Error creating admin notifications:", error);
  }
}
function getNotificationTitle(activityData) {
  const { action, entityType } = activityData;
  const actionMap = {
    CREATE: "Created",
    UPDATE: "Updated",
    DELETE: "Deleted",
    APPROVE: "Approved",
    REJECT: "Rejected",
    CANCEL: "Cancelled",
    EXPORT: "Exported",
    IMPORT: "Imported",
    LOGIN: "Logged In",
    LOGOUT: "Logged Out"
  };
  const entityMap = {
    BOOKING: "Booking",
    INVOICE: "Invoice",
    RECEIPT: "Receipt",
    CUSTOMER: "Customer",
    SUPPLIER: "Supplier",
    USER: "User",
    ACCOUNT: "Account",
    JOURNAL_ENTRY: "Journal Entry",
    FILE: "File"
  };
  const actionText = actionMap[action] || action;
  const entityText = entityMap[entityType] || entityType;
  return `${entityText} ${actionText}`;
}
const activityTrackerMiddleware = (entityType, getEntityId) => {
  return async (req, res, next) => {
    const originalJson = res.json.bind(res);
    res.json = function(data) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const action = getActionFromMethod(req.method);
        const entityId = getEntityId ? getEntityId(req) : req.params.id;
        setImmediate(() => {
          trackActivity(req, {
            action,
            entityType,
            entityId,
            description: generateDescription(req, action, entityType, data),
            changes: getChanges(req, action),
            metadata: {
              method: req.method,
              path: req.path,
              query: req.query,
              body: sanitizeBody(req.body)
            }
          });
        });
      }
      return originalJson(data);
    };
    next();
  };
};
function getActionFromMethod(method) {
  const methodMap = {
    GET: "VIEW",
    POST: "CREATE",
    PUT: "UPDATE",
    PATCH: "UPDATE",
    DELETE: "DELETE"
  };
  return methodMap[method] || method;
}
function generateDescription(req, action, entityType, responseData) {
  const userName = req.user ? `${req.user.firstName} ${req.user.lastName}` : "Unknown";
  const entityName = entityType.toLowerCase();
  switch (action) {
    case "CREATE":
      return `${userName} created a new ${entityName}`;
    case "UPDATE":
      return `${userName} updated ${entityName} details`;
    case "DELETE":
      return `${userName} deleted a ${entityName}`;
    case "VIEW":
      return `${userName} viewed ${entityName} details`;
    default:
      return `${userName} performed ${action} on ${entityName}`;
  }
}
function getChanges(req, action) {
  if (action === "UPDATE" && req.body) {
    return {
      before: req.params.id ? { id: req.params.id } : null,
      after: sanitizeBody(req.body)
    };
  }
  if (action === "CREATE" && req.body) {
    return {
      created: sanitizeBody(req.body)
    };
  }
  return null;
}
function sanitizeBody(body) {
  if (!body || typeof body !== "object") return body;
  const sanitized = { ...body };
  const sensitiveFields = ["password", "token", "apiKey", "secret"];
  sensitiveFields.forEach((field) => {
    if (field in sanitized) {
      sanitized[field] = "***REDACTED***";
    }
  });
  return sanitized;
}
const trackLogin = async (userId, email, ipAddress, userAgent, success) => {
  try {
    await import_prisma.prisma.activity_logs.create({
      data: {
        id: (0, import_nanoid.nanoid)(),
        userId,
        action: success ? "LOGIN" : "LOGIN_FAILED",
        entityType: "USER",
        entityId: userId,
        description: success ? `User ${email} logged in successfully` : `Failed login attempt for ${email}`,
        ipAddress,
        userAgent,
        metadata: JSON.stringify({ success, timestamp: /* @__PURE__ */ new Date() }),
        createdAt: /* @__PURE__ */ new Date()
      }
    });
    if (success) {
      const user = await import_prisma.prisma.users.findUnique({
        where: { id: userId },
        select: { firstName: true, lastName: true, role: true }
      });
      if (user) {
        await createSystemNotification({
          type: "USER_LOGIN",
          title: "User Login",
          message: `${user.firstName} ${user.lastName} (${user.role}) logged in`,
          actionType: "LOGIN",
          actionBy: userId,
          entityType: "USER",
          entityId: userId,
          metadata: { ipAddress, timestamp: /* @__PURE__ */ new Date() }
        });
      }
    }
  } catch (error) {
    console.error("Login tracking error:", error);
  }
};
async function createSystemNotification(data) {
  try {
    const adminUsers = await import_prisma.prisma.users.findMany({
      where: {
        role: { in: ["ADMIN", "SUPER_ADMIN", "ACCOUNTING"] },
        isActive: true,
        id: data.actionBy ? { not: data.actionBy } : void 0
      },
      select: { id: true }
    });
    if (adminUsers.length === 0) return;
    const notifications = adminUsers.map((admin) => ({
      id: (0, import_nanoid.nanoid)(),
      userId: admin.id,
      type: data.type,
      title: data.title,
      message: data.message,
      actionType: data.actionType,
      actionBy: data.actionBy,
      entityType: data.entityType,
      entityId: data.entityId,
      metadata: JSON.stringify(data.metadata || {}),
      isRead: false,
      createdAt: /* @__PURE__ */ new Date()
    }));
    await import_prisma.prisma.notifications.createMany({
      data: notifications
    });
  } catch (error) {
    console.error("Error creating system notification:", error);
  }
}
var activityTracker_default = {
  trackActivity,
  activityTrackerMiddleware,
  trackLogin
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  activityTrackerMiddleware,
  trackActivity,
  trackLogin
});
