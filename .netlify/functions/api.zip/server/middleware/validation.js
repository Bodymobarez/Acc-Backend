"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var validation_exports = {};
__export(validation_exports, {
  validate: () => validate
});
module.exports = __toCommonJS(validation_exports);
var import_express_validator = require("express-validator");
const validate = (validations) => {
  return async (req, res, next) => {
    await Promise.all(validations.map((validation) => validation.run(req)));
    const errors = (0, import_express_validator.validationResult)(req);
    if (!errors.isEmpty()) {
      const errorDetails = {
        path: req.path,
        method: req.method,
        body: req.body,
        errors: errors.array()
      };
      console.error("[Validation Error]", JSON.stringify(errorDetails, null, 2));
      res.status(400).json({
        success: false,
        error: "Validation failed",
        details: process.env.NODE_ENV === "development" ? errorDetails : void 0,
        errors: errors.array().map((err) => ({
          field: err.type === "field" ? err.path : "unknown",
          message: err.msg,
          value: err.type === "field" ? err.value : void 0
        }))
      });
      return;
    }
    next();
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  validate
});
