"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rbac_exports = {};
__export(rbac_exports, {
  applyBookingFilter: () => applyBookingFilter,
  applyCustomerFilter: () => applyCustomerFilter,
  applyInvoiceFilter: () => applyInvoiceFilter,
  assignCustomerToUser: () => assignCustomerToUser,
  canAccessBooking: () => canAccessBooking,
  canAccessCustomer: () => canAccessCustomer,
  canAccessInvoice: () => canAccessInvoice,
  getUserAccessibleBookingIds: () => getUserAccessibleBookingIds,
  getUserAccessibleInvoiceIds: () => getUserAccessibleInvoiceIds,
  getUserAccessibleSupplierIds: () => getUserAccessibleSupplierIds,
  getUserAssignedCustomerIds: () => getUserAssignedCustomerIds,
  getUserAssignmentInfo: () => getUserAssignmentInfo,
  isAdminUser: () => isAdminUser,
  unassignCustomerFromUser: () => unassignCustomerFromUser
});
module.exports = __toCommonJS(rbac_exports);
var import_crypto = require("crypto");
var import_prisma = require("../lib/prisma");
async function getUserAssignedCustomerIds(userId) {
  try {
    const assignments = await import_prisma.prisma.customer_assignments.findMany({
      where: {
        userId,
        isActive: true
      },
      select: {
        customerId: true
      }
    });
    return assignments.map((a) => a.customerId);
  } catch (error) {
    console.error("Error fetching user customer assignments:", error);
    return [];
  }
}
async function getUserAccessibleSupplierIds(userId) {
  try {
    const customerIds = await getUserAssignedCustomerIds(userId);
    if (customerIds.length === 0) {
      return [];
    }
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        customerId: { in: customerIds }
      },
      select: {
        supplierId: true
      },
      distinct: ["supplierId"]
    });
    return [...new Set(bookings.map((b) => b.supplierId))];
  } catch (error) {
    console.error("Error fetching user accessible suppliers:", error);
    return [];
  }
}
async function getUserAccessibleBookingIds(userId) {
  try {
    const customerIds = await getUserAssignedCustomerIds(userId);
    if (customerIds.length === 0) {
      return [];
    }
    const bookings = await import_prisma.prisma.bookings.findMany({
      where: {
        customerId: { in: customerIds }
      },
      select: {
        id: true
      }
    });
    return bookings.map((b) => b.id);
  } catch (error) {
    console.error("Error fetching user accessible bookings:", error);
    return [];
  }
}
async function getUserAccessibleInvoiceIds(userId) {
  try {
    const bookingIds = await getUserAccessibleBookingIds(userId);
    if (bookingIds.length === 0) {
      return [];
    }
    const invoices = await import_prisma.prisma.invoices.findMany({
      where: {
        bookingId: { in: bookingIds }
      },
      select: {
        id: true
      }
    });
    return invoices.map((i) => i.id);
  } catch (error) {
    console.error("Error fetching user accessible invoices:", error);
    return [];
  }
}
function isAdminUser(user) {
  return user?.role === "ADMIN" || user?.role === "SUPER_ADMIN" || user?.role === "ACCOUNTANT" || user?.role === "FINANCIAL_CONTROLLER";
}
const applyCustomerFilter = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      req.customerFilter = null;
      next();
      return;
    }
    const customerIds = await getUserAssignedCustomerIds(req.user.id);
    if (customerIds.length === 0) {
      req.customerFilter = { id: { in: [] } };
      console.log(`User ${req.user.email} has no customer assignments`);
    } else {
      req.customerFilter = { id: { in: customerIds } };
      console.log(`User ${req.user.email} has access to ${customerIds.length} customers`);
    }
    next();
  } catch (error) {
    console.error("Error applying customer filter:", error);
    res.status(500).json({ error: "Error applying access control" });
  }
};
const applyBookingFilter = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      req.bookingFilter = null;
      next();
      return;
    }
    const customerIds = await getUserAssignedCustomerIds(req.user.id);
    if (customerIds.length === 0) {
      req.bookingFilter = { id: { in: [] } };
      console.log(`User ${req.user.email} has no accessible bookings`);
    } else {
      req.bookingFilter = { customerId: { in: customerIds } };
      console.log(`User ${req.user.email} can access bookings for ${customerIds.length} customers`);
    }
    next();
  } catch (error) {
    console.error("Error applying booking filter:", error);
    res.status(500).json({ error: "Error applying access control" });
  }
};
const applyInvoiceFilter = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      req.invoiceFilter = null;
      next();
      return;
    }
    const customerIds = await getUserAssignedCustomerIds(req.user.id);
    if (customerIds.length === 0) {
      req.invoiceFilter = { id: { in: [] } };
      console.log(`User ${req.user.email} has no accessible invoices`);
    } else {
      req.invoiceFilter = {
        booking: {
          customerId: { in: customerIds }
        }
      };
      console.log(`User ${req.user.email} can access invoices for ${customerIds.length} customers`);
    }
    next();
  } catch (error) {
    console.error("Error applying invoice filter:", error);
    res.status(500).json({ error: "Error applying access control" });
  }
};
const canAccessCustomer = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      next();
      return;
    }
    const customerId = req.params.id || req.body.customerId;
    if (!customerId) {
      res.status(400).json({ error: "Customer ID required" });
      return;
    }
    const assignedCustomerIds = await getUserAssignedCustomerIds(req.user.id);
    if (!assignedCustomerIds.includes(customerId)) {
      console.log(`Access denied: User ${req.user.email} cannot access customer ${customerId}`);
      res.status(403).json({ error: "Access denied to this customer" });
      return;
    }
    next();
  } catch (error) {
    console.error("Error checking customer access:", error);
    res.status(500).json({ error: "Error checking access" });
  }
};
const canAccessBooking = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      next();
      return;
    }
    const bookingId = req.params.id || req.body.bookingId;
    if (!bookingId) {
      res.status(400).json({ error: "Booking ID required" });
      return;
    }
    const booking = await import_prisma.prisma.bookings.findUnique({
      where: { id: bookingId },
      select: { customerId: true }
    });
    if (!booking) {
      res.status(404).json({ error: "Booking not found" });
      return;
    }
    const assignedCustomerIds = await getUserAssignedCustomerIds(req.user.id);
    if (!assignedCustomerIds.includes(booking.customerId)) {
      console.log(`Access denied: User ${req.user.email} cannot access booking ${bookingId}`);
      res.status(403).json({ error: "Access denied to this booking" });
      return;
    }
    next();
  } catch (error) {
    console.error("Error checking booking access:", error);
    res.status(500).json({ error: "Error checking access" });
  }
};
const canAccessInvoice = async (req, res, next) => {
  try {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (isAdminUser(req.user)) {
      next();
      return;
    }
    const invoiceId = req.params.id || req.body.invoiceId;
    if (!invoiceId) {
      res.status(400).json({ error: "Invoice ID required" });
      return;
    }
    const invoice = await import_prisma.prisma.invoices.findUnique({
      where: { id: invoiceId },
      include: {
        bookings: {
          select: { customerId: true }
        }
      }
    });
    if (!invoice) {
      res.status(404).json({ error: "Invoice not found" });
      return;
    }
    const assignedCustomerIds = await getUserAssignedCustomerIds(req.user.id);
    if (!assignedCustomerIds.includes(invoice.bookings.customerId)) {
      console.log(`Access denied: User ${req.user.email} cannot access invoice ${invoiceId}`);
      res.status(403).json({ error: "Access denied to this invoice" });
      return;
    }
    next();
  } catch (error) {
    console.error("Error checking invoice access:", error);
    res.status(500).json({ error: "Error checking access" });
  }
};
async function getUserAssignmentInfo(userId) {
  try {
    const assignments = await import_prisma.prisma.customer_assignments.findMany({
      where: {
        userId,
        isActive: true
      },
      include: {
        customers: {
          select: {
            id: true,
            companyName: true,
            customerCode: true
          }
        }
      }
    });
    return {
      totalAssignments: assignments.length,
      customers: assignments.map((a) => ({
        id: a.customers.id,
        name: a.customers.companyName,
        code: a.customers.customerCode,
        role: a.assignedRole,
        assignedDate: a.assignedDate
      }))
    };
  } catch (error) {
    console.error("Error fetching user assignment info:", error);
    return {
      totalAssignments: 0,
      customers: []
    };
  }
}
async function assignCustomerToUser(customerId, userId, assignedRole = "SALES", commissionRates) {
  try {
    const assignment = await import_prisma.prisma.customer_assignments.upsert({
      where: {
        customerId_userId_assignedRole: {
          customerId,
          userId,
          assignedRole
        }
      },
      update: {
        isActive: true,
        updatedAt: /* @__PURE__ */ new Date(),
        ...commissionRates
      },
      create: {
        id: (0, import_crypto.randomUUID)(),
        customerId,
        userId,
        assignedRole,
        isActive: true,
        updatedAt: /* @__PURE__ */ new Date(),
        ...commissionRates
      }
    });
    console.log(`\u2705 Assigned customer ${customerId} to user ${userId} (${assignedRole})`);
    return assignment;
  } catch (error) {
    console.error("Error assigning customer to user:", error);
    throw error;
  }
}
async function unassignCustomerFromUser(customerId, userId, assignedRole = "SALES") {
  try {
    await import_prisma.prisma.customer_assignments.update({
      where: {
        customerId_userId_assignedRole: {
          customerId,
          userId,
          assignedRole
        }
      },
      data: {
        isActive: false
      }
    });
    console.log(`\u2705 Unassigned customer ${customerId} from user ${userId} (${assignedRole})`);
  } catch (error) {
    console.error("Error unassigning customer from user:", error);
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  applyBookingFilter,
  applyCustomerFilter,
  applyInvoiceFilter,
  assignCustomerToUser,
  canAccessBooking,
  canAccessCustomer,
  canAccessInvoice,
  getUserAccessibleBookingIds,
  getUserAccessibleInvoiceIds,
  getUserAccessibleSupplierIds,
  getUserAssignedCustomerIds,
  getUserAssignmentInfo,
  isAdminUser,
  unassignCustomerFromUser
});
