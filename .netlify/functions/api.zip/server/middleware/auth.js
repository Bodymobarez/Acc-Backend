"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_exports = {};
__export(auth_exports, {
  authenticate: () => authenticate,
  authenticateToken: () => authenticateToken,
  generateToken: () => generateToken,
  requirePermission: () => requirePermission,
  requireRole: () => requireRole
});
module.exports = __toCommonJS(auth_exports);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"));
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const authenticate = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "No token provided" });
      return;
    }
    const token = authHeader.substring(7);
    try {
      const decoded = import_jsonwebtoken.default.verify(token, JWT_SECRET);
      req.user = {
        ...decoded,
        permissions: typeof decoded.permissions === "string" ? JSON.parse(decoded.permissions) : decoded.permissions
      };
      next();
    } catch (error) {
      res.status(401).json({ error: "Invalid or expired token" });
      return;
    }
  } catch (error) {
    res.status(500).json({ error: "Authentication error" });
    return;
  }
};
const requirePermission = (permission) => {
  return (req, res, next) => {
    console.log("Checking permission:", permission);
    console.log("User:", req.user?.email);
    console.log("User role:", req.user?.role);
    console.log("User permissions:", req.user?.permissions);
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (req.user.role === "ADMIN" || req.user.role === "SUPER_ADMIN" || req.user.role === "FINANCIAL_CONTROLLER") {
      console.log("\u2705 Access granted: User has admin-level role");
      next();
      return;
    }
    if (!req.user.permissions[permission]) {
      console.log("\u274C Permission denied for:", permission);
      res.status(403).json({ error: "Insufficient permissions" });
      return;
    }
    console.log("\u2705 Permission granted");
    next();
  };
};
const requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: "Insufficient role permissions" });
      return;
    }
    next();
  };
};
const generateToken = (user) => {
  return import_jsonwebtoken.default.sign(user, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d"
  });
};
const authenticateToken = authenticate;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  authenticate,
  authenticateToken,
  generateToken,
  requirePermission,
  requireRole
});
