"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var calculations_exports = {};
__export(calculations_exports, {
  calculateCommissions: () => calculateCommissions,
  calculateVAT: () => calculateVAT,
  calculateVATForNonUAE: () => calculateVATForNonUAE,
  calculateVATForUAE: () => calculateVATForUAE,
  calculateVATOnProfit: () => calculateVATOnProfit,
  convertToAED: () => convertToAED,
  generateBookingNumber: () => generateBookingNumber,
  generateFileNumber: () => generateFileNumber,
  generateInvoiceNumber: () => generateInvoiceNumber,
  getBookingPrefix: () => getBookingPrefix
});
module.exports = __toCommonJS(calculations_exports);
function calculateVATForUAE(saleAmount, costAmount, vatRate = 5, serviceType) {
  if (serviceType === "FLIGHT") {
    const grossProfit2 = saleAmount - costAmount;
    return {
      isUAEBooking: true,
      saleAmount,
      costAmount,
      netBeforeVAT: saleAmount,
      vatAmount: 0,
      // Will be calculated later on net profit
      totalWithVAT: saleAmount,
      grossProfit: parseFloat(grossProfit2.toFixed(2)),
      netProfit: parseFloat(grossProfit2.toFixed(2))
    };
  }
  const divisor = 1 + vatRate / 100;
  const netBeforeVAT = saleAmount / divisor;
  const vatAmount = saleAmount - netBeforeVAT;
  const totalWithVAT = saleAmount;
  const grossProfit = netBeforeVAT - costAmount;
  const netProfit = grossProfit;
  return {
    isUAEBooking: true,
    saleAmount,
    costAmount,
    netBeforeVAT: parseFloat(netBeforeVAT.toFixed(2)),
    vatAmount: parseFloat(vatAmount.toFixed(2)),
    totalWithVAT: parseFloat(totalWithVAT.toFixed(2)),
    grossProfit: parseFloat(grossProfit.toFixed(2)),
    netProfit: parseFloat(netProfit.toFixed(2))
  };
}
function calculateVATForNonUAE(saleAmount, costAmount, vatRate = 5) {
  const grossProfit = saleAmount - costAmount;
  const vatAmount = grossProfit * vatRate / 100;
  const netBeforeVAT = saleAmount;
  const totalWithVAT = saleAmount + vatAmount;
  const netProfit = grossProfit;
  return {
    isUAEBooking: false,
    saleAmount,
    costAmount,
    netBeforeVAT: parseFloat(netBeforeVAT.toFixed(2)),
    vatAmount: parseFloat(vatAmount.toFixed(2)),
    totalWithVAT: parseFloat(totalWithVAT.toFixed(2)),
    grossProfit: parseFloat(grossProfit.toFixed(2)),
    netProfit: parseFloat(netProfit.toFixed(2))
  };
}
function calculateVAT(saleAmount, costAmount, isUAEBooking, vatRate = 5, serviceType) {
  if (isUAEBooking) {
    return calculateVATForUAE(saleAmount, costAmount, vatRate, serviceType);
  } else {
    return calculateVATForNonUAE(saleAmount, costAmount, vatRate);
  }
}
function calculateVATOnProfit(profitAfterCommission, vatRate = 5) {
  if (profitAfterCommission <= 0) {
    return 0;
  }
  return parseFloat((profitAfterCommission * vatRate / 100).toFixed(2));
}
function calculateCommissions(grossProfit, agentCommissionRate = 0, csCommissionRate = 0) {
  const agentCommissionAmount = grossProfit * agentCommissionRate / 100;
  const csCommissionAmount = grossProfit * csCommissionRate / 100;
  const totalCommission = agentCommissionAmount + csCommissionAmount;
  const profitAfterCommission = grossProfit - totalCommission;
  return {
    netProfit: parseFloat(grossProfit.toFixed(2)),
    // Kept for compatibility - represents gross profit
    agentCommissionRate,
    agentCommissionAmount: parseFloat(agentCommissionAmount.toFixed(2)),
    csCommissionRate,
    csCommissionAmount: parseFloat(csCommissionAmount.toFixed(2)),
    totalCommission: parseFloat(totalCommission.toFixed(2)),
    profitAfterCommission: parseFloat(profitAfterCommission.toFixed(2))
  };
}
function convertToAED(amount, exchangeRate) {
  return parseFloat((amount * exchangeRate).toFixed(2));
}
function getBookingPrefix(serviceType, isRefunded = false) {
  if (isRefunded) return "RFN";
  const prefixMap = {
    "HOTEL": "HTL",
    "FLIGHT": "AIR",
    "TRANSFER": "TR",
    "RENT_CAR": "RNT",
    "RENTCAR": "RNT",
    "RENTAL_CAR": "RNT",
    "CAR_RENTAL": "RNT",
    "VISA": "VISA",
    "ACTIVITY": "ACT",
    "CRUISE": "CRU",
    "TRAIN": "TRN",
    "OTHER": "OTH"
  };
  return prefixMap[serviceType?.toUpperCase()] || "BKG";
}
function generateBookingNumber(prefix = "BKG", sequence) {
  const paddedSequence = sequence.toString().padStart(6, "0");
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  return `${prefix}-${year}-${paddedSequence}`;
}
function generateInvoiceNumber(prefix = "INV", sequence) {
  const paddedSequence = sequence.toString().padStart(6, "0");
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  return `${prefix}-${year}-${paddedSequence}`;
}
function generateFileNumber(prefix = "FILE", sequence) {
  const paddedSequence = sequence.toString().padStart(6, "0");
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  return `${prefix}-${year}-${paddedSequence}`;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  calculateCommissions,
  calculateVAT,
  calculateVATForNonUAE,
  calculateVATForUAE,
  calculateVATOnProfit,
  convertToAED,
  generateBookingNumber,
  generateFileNumber,
  generateInvoiceNumber,
  getBookingPrefix
});
