"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var currencyUpdateCron_exports = {};
__export(currencyUpdateCron_exports, {
  startCurrencyUpdateCron: () => startCurrencyUpdateCron,
  stopCurrencyUpdateCron: () => stopCurrencyUpdateCron,
  triggerManualUpdate: () => triggerManualUpdate
});
module.exports = __toCommonJS(currencyUpdateCron_exports);
var import_currencyService = require("../services/currencyService");
let cronJob = null;
function startCurrencyUpdateCron() {
  console.log("\u2139\uFE0F  Currency automatic updates DISABLED");
  console.log('   Updates will only occur when manually triggered via "Update Rates Online" button');
  if (cronJob) {
    cronJob.stop();
    cronJob = null;
  }
}
function stopCurrencyUpdateCron() {
  if (cronJob) {
    cronJob.stop();
    console.log("\u{1F6D1} Currency update cron job stopped");
  }
}
async function runInitialUpdate() {
  console.log("\u2139\uFE0F  Initial currency update DISABLED");
  console.log('   Use "Update Rates Online" button to update rates manually');
}
async function triggerManualUpdate() {
  console.log("\u{1F527} Manual currency update triggered");
  return await import_currencyService.currencyService.updateAllRates();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  startCurrencyUpdateCron,
  stopCurrencyUpdateCron,
  triggerManualUpdate
});
